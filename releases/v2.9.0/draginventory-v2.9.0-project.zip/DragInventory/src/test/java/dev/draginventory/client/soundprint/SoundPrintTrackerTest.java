package dev.draginventory.client.soundprint;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import org.junit.jupiter.api.Test;

class SoundPrintTrackerTest {
   private static final float RADIUS = 20.0F;
   private static final float ATTACK = 18.0F;
   private static final float RELEASE = 7.0F;
   private static final long HOLD = 650L;

   private static void step(SoundPrintTracker tracker, long t) {
      tracker.tick(t, 0.0, 1.62, 0.0, RADIUS, 0.2F, true, ATTACK, RELEASE, HOLD);
   }

   @Test
   void footstepsAtHumanCadenceNeverFlicker() {
      SoundPrintTracker tracker = new SoundPrintTracker();
      // 450 ms cadence, hold 650 ms -> after the attack ramp the energy must
      // never sag between steps (the first two frames are the spring ramp-up)
      float minEnergy = 1.0F;
      for (int i = 0; i < 20; i++) {
         long t = i * 450L;
         tracker.offer(new SoundSample(0.0, 0.0, 5.0, SoundPrintType.FOOTSTEP, 0.6F, t, "test:step"));
         step(tracker, t);
         if (i >= 2) {
            minEnergy = Math.min(minEnergy, lastDisplayEnergy(tracker, t));
         }
      }
      assertTrue(minEnergy > 0.5F, "energy dipped to " + minEnergy + " during continuous walking");
   }

   @Test
   void motionTickRenewsAndSlidesSource() {
      SoundPrintTracker tracker = new SoundPrintTracker();
      tracker.offer(new SoundSample(0.0, 0.0, 5.0, SoundPrintType.FOOTSTEP, 0.6F, 0L, "test:step"));
      step(tracker, 0L);
      assertTrue(tracker.activeCount() == 1);

      // walker keeps moving every 450 ms; no sound events at all after the first
      for (int i = 1; i <= 8; i++) {
         long t = i * 450L;
         double z = 5.0 + i * 0.3;
         tracker.motionTick(t, List.of(new SoundPrintTracker.Mover(0.0, 0.0, z, 0.15)));
         step(tracker, t);
         assertEquals(1, tracker.activeCount(), "walking source must stay alive (renewal), tick " + i);
         assertTrue(lastDisplayEnergy(tracker, t) > 0.2F, "walking source went dark at tick " + i);
      }
   }

   @Test
   void ownPositionMoverKeepsOwnFootstepLit() {
      // the v2.9.0 fix: local player is fed into motionTick when ignore_own is off
      SoundPrintTracker tracker = new SoundPrintTracker();
      tracker.offer(new SoundSample(0.0, 0.0, 0.0, SoundPrintType.FOOTSTEP, 0.6F, 0L, "test:own"));
      step(tracker, 0L);

      for (int i = 1; i <= 10; i++) {
         long t = i * 450L;
         tracker.motionTick(t, List.of(new SoundPrintTracker.Mover(0.0, 0.0, 0.0, 0.12)));
         step(tracker, t);
         assertEquals(1, tracker.activeCount(), "own footstep source must survive while walking, tick " + i);
      }
   }

   @Test
   void sourceExpiresAfterQuiet() {
      SoundPrintTracker tracker = new SoundPrintTracker();
      tracker.offer(new SoundSample(0.0, 0.0, 5.0, SoundPrintType.FOOTSTEP, 0.6F, 0L, "test:step"));
      step(tracker, 0L);
      // keep ticking far past hold + fade without any sound or motion
      for (long t = 450L; t <= 8000L; t += 450L) {
         step(tracker, t);
      }
      assertEquals(0, tracker.activeCount(), "source should have expired after quiet period");
   }

   @Test
   void gunshotIsNotRenewedByMotion() {
      SoundPrintTracker tracker = new SoundPrintTracker();
      tracker.offer(new SoundSample(0.0, 1.6, 5.0, SoundPrintType.GUNSHOT, 1.0F, 0L, "test:shot"));
      step(tracker, 0L);
      // movers at the gunshot position must NOT renew the GUNSHOT source
      // (they may legitimately spawn their own footstep source, so we assert
      // on the gunshot specifically, not on activeCount)
      for (int i = 1; i <= 12; i++) {
         long t = i * 450L;
         tracker.motionTick(t, List.of(new SoundPrintTracker.Mover(0.0, 1.6, 5.0, 0.15)));
         step(tracker, t);
      }
      for (SoundPrintAggregator.Hit h : tracker.frameHits(0.0, 1.62, 0.0, false)) {
         if (h.type() == SoundPrintType.GUNSHOT) {
            throw new AssertionError("gunshot must fade even with motion at its position");
         }
      }
   }

   @Test
   void frameHitsCarryBearingEnergyAndDistance() {
      SoundPrintTracker tracker = new SoundPrintTracker();
      tracker.offer(new SoundSample(10.0, 0.0, 0.0, SoundPrintType.GUNSHOT, 1.0F, 0L, "test:shot"));
      step(tracker, 0L);
      step(tracker, 50L);
      List<SoundPrintAggregator.Hit> hits = tracker.frameHits(0.0, 1.62, 0.0, true);
      assertEquals(1, hits.size());
      assertEquals(90.0F, hits.get(0).bearing(), 0.5F); // due east
      assertTrue(hits.get(0).energy() > 0.0F);
      assertTrue(hits.get(0).distance() > 8.0F);
   }

   @Test
   void springStepConvergesToTarget() {
      float v = 0.0F;
      for (int i = 0; i < 200; i++) {
         v = SoundPrintTracker.springStep(v, 1.0F, 0.05F, 18.0F);
      }
      assertEquals(1.0F, v, 0.001F);
   }

   private static float lastDisplayEnergy(SoundPrintTracker tracker, long t) {
      List<SoundPrintAggregator.Hit> hits = tracker.frameHits(0.0, 1.62, 0.0, false);
      float best = 0.0F;
      for (SoundPrintAggregator.Hit h : hits) {
         if (h.type() == SoundPrintType.FOOTSTEP) {
            best = Math.max(best, h.energy());
         }
      }
      return best;
   }
}
