package dev.draginventory.client.map;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.config.ModConfigEvent;
import net.neoforged.fml.loading.FMLPaths;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 战术地图配置的 MOD 总线事件：与 FML 配置系统的加载/重载/卸载对账。
 *
 * <p>关键背景（保存竞态）：{@code SPEC.save()} 写盘后，FML 的文件监视线程会
 * 异步重读文件并<b>整体替换</b>内存配置映射。若用户在“落盘 → 监视线程重载完成”
 * 的窗口内继续修改配置，新值会被旧文件内容覆盖，表现为设置界面
 * “开关点了没反应 / 滤镜跳过去又跳回来”。</p>
 *
 * <p>对策见 {@link MapConfig#onConfigReloaded}：写前 journal + 重载对账重放。
 * 注意 Reloading 事件可能出现在两个时机：save() 内同步触发（主线程）与
 * 监视线程异步触发——对账逻辑对两者都幂等。</p>
 */
@EventBusSubscriber(modid = "draginventory", value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class MapConfigEvents {
    private static final Logger LOGGER = LoggerFactory.getLogger("DragInventory/MapConfig");

    private MapConfigEvents() {}

    @SubscribeEvent
    public static void onConfigLoading(ModConfigEvent.Loading event) {
        if (isMapConfig(event)) {
            migrateLegacyConfig();
            MapConfig.onConfigReloaded();
        }
    }

    @SubscribeEvent
    public static void onConfigReloading(ModConfigEvent.Reloading event) {
        if (isMapConfig(event)) {
            MapConfig.onConfigReloaded();
        }
    }

    @SubscribeEvent
    public static void onConfigUnloading(ModConfigEvent.Unloading event) {
        if (isMapConfig(event)) {
            MapConfig.onConfigUnloaded();
        }
    }

    private static boolean isMapConfig(ModConfigEvent event) {
        return MapConfig.fileName().equals(event.getConfig().getFileName());
    }

    /**
     * v2.4.0 → v2.5.0 配置迁移（一次性，仅在 Loading 事件触发）。
     *
     * <p><b>背景</b>：v2.4.0 的 {@code general.enabled} 是"存了不用"的占位配置——
     * {@code /map off} 或设置界面会把它写入 TOML，但对 M 键 / 地图毫无效果。
     * v2.5.0 将 enabled 接线为总开关后，老玩家配置文件里残留的 {@code enabled = false}
     * 会突然生效：M 键失灵、小地图消失，且没有任何提示，表现为"模组所有 UI 失效"。</p>
     *
     * <p><b>迁移规则</b>：检测到配置文件仍是 v2.4.0 结构（含已删除的 {@code contrast}
     * 滤镜滑条键，且没有 v2.5.0 新增的 {@code [minimap]} 段）时，视为升级安装——
     * 旧结构的 enabled 不代表用户在 v2.5.0 下的真实意愿，复位为默认开启。
     * v2.5.0 及之后生成的配置（已含 {@code [minimap]} 段）不迁移，
     * 尊重用户主动执行的 {@code /map off}。迁移随下一次落盘自动清理全部旧键
     * （NeoForge 保存时只写当前 spec 定义的键）。</p>
     */
    private static void migrateLegacyConfig() {
        try {
            Path file = FMLPaths.CONFIGDIR.get().resolve(MapConfig.fileName());
            if (!Files.isRegularFile(file)) return; // 全新安装：默认值即开启，无需迁移
            List<String> lines = Files.readAllLines(file);
            boolean hasLegacyContrast = false, hasMinimapSection = false;
            for (String line : lines) {
                String t = line.trim();
                if (t.startsWith("contrast")) hasLegacyContrast = true;
                if (t.startsWith("[minimap]")) hasMinimapSection = true;
            }
            if (hasLegacyContrast && !hasMinimapSection && !MapConfig.ENABLED.get()) {
                MapConfig.set(MapConfig.ENABLED, true);
                MapConfig.flush();
                LOGGER.info("Migrated legacy v2.4.0 map config: enabled reset to true "
                        + "(stale 'enabled = false' from the pre-wiring era would have silently "
                        + "disabled the M key and minimap)");
            }
        } catch (Exception e) {
            LOGGER.warn("Map config legacy migration check failed (ignored); file: {}", MapConfig.fileName(), e);
        }
    }
}
