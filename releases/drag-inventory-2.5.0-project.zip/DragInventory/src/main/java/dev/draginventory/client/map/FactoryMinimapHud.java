package dev.draginventory.client.map;

import static dev.draginventory.client.map.FactoryMapUI.*;

import dev.draginventory.client.TacticalMarkerManager;
import java.util.List;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw;
import net.minecraft.util.Mth;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 左上角常驻方形小地图（反馈⑨，Xaero / 三角洲风格）。
 *
 * <p><b>渲染管线</b>（复用大地图的瓦片渲染器，零新增采样逻辑）：
 * <ul>
 *   <li>楼层：缓存玩家所在楼层（{@code resolvePlayerFloor}），仅当玩家所在方块坐标
 *       变化或每 20 帧才重算，避免每帧方块查询；</li>
 *   <li>视图：合成活动层（{@link MinimapView}）——把玩家楼层包装成单层目录喂给
 *       {@link FactoryMapTiles}，<b>不做任何 discover / 目录扫描</b>（catalog 为空 →
 *       渲染器不画上下叠加层，小地图只显示当前层，零 discover 开销）；</li>
 *   <li>瓦片：独立静态 {@link FactoryMapTiles} 实例（独立 LRU 池，与大地图屏幕互不
 *       干扰）。tiles 自带换世界失效（draw 首检 lastWorld），静态常驻无需显式关闭；</li>
 *   <li>标点：{@code markers.visible} 开启时按楼层 ±3 过滤，画 5×5 类型色方块 +
 *       中心 1×1 深色点（不画序号/距离，小地图保持干净）；</li>
 *   <li>玩家箭头始终居中指向朝向；顶部中央 "N" 北向指示；四角 3px ACCENT 角标
 *       （战术感）；下方一行对局计时（{@link MapMatchTimer}）。</li>
 * </ul></p>
 *
 * <p>守卫：F1（hideGui）、任意界面打开（含大地图/设置界面/聊天）、旁观模式、
 * {@code general.enabled} 或 {@code minimap.enabled} 关闭时全部隐藏。
 * 注册见 {@link FactoryMapHudRegistration}（registerAboveAll）。</p>
 */
final class FactoryMinimapHud implements LayeredDraw.Layer {
    /** 错误修正：NeoForge 的 LayeredDraw 对层渲染无异常保护，任何一层抛异常会中断
     * 整条 HUD 渲染链并崩溃游戏。小地图是每帧执行的常驻层，必须自保：首次异常
     * 记日志并停用本会话的小地图，游戏本体与其余 HUD 不受影响。 */
    private static final Logger LOGGER = LoggerFactory.getLogger("DragInventory/MinimapHud");
    /** 渲染安全网熔断标志（本会话内首次异常后置位，不再尝试渲染）。 */
    private static boolean broken;

    /** 小地图独立瓦片池（静态常驻：换世界自动失效重烤，见类注释）。 */
    private static final FactoryMapTiles TILES = new FactoryMapTiles();

    // ==================== 楼层缓存（避免每帧方块查询） ====================

    /** 缓存的玩家楼层 Y（NO_FLOOR = 尚未计算，首帧触发）。 */
    private static int lastFloor = FactoryMapLayerResolver.NO_FLOOR;
    private static int lastBlockX, lastBlockY, lastBlockZ;
    private static int frameCount;

    /** 小地图到渲染器的最小视图：合成活动层 + 空目录（无叠加层，无 discover）。 */
    private record MinimapView(FactoryMapLayerResolver.Layer layer) implements FactoryMapView {
        @Override public FactoryMapLayerResolver.Layer activeLayer() { return layer; }
        @Override public FactoryMapLayerResolver.LayerCatalog catalog() {
            return FactoryMapLayerResolver.LayerCatalog.empty();
        }
    }

    @Override
    public void render(GuiGraphics g, DeltaTracker dt) {
        if (broken) return;
        try {
            renderInner(g, dt);
        } catch (Exception e) {
            broken = true;
            LOGGER.error("Factory minimap HUD failed to render; minimap is disabled for the rest of "
                    + "this session to protect the HUD pipeline. Root cause:", e);
        }
    }

    private void renderInner(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.player.isSpectator()) return;
        if (mc.options.hideGui || mc.screen != null || mc.getOverlay() != null) return;
        if (!MapConfig.ENABLED.get() || !MapConfig.MINIMAP_ENABLED.get()) return;

        // 楼层缓存：所在方块坐标变化，或每 20 帧（方块被放置/破坏不需移动也会改楼层）。
        frameCount++;
        int bx = Mth.floor(mc.player.getX()), by = Mth.floor(mc.player.getY()), bz = Mth.floor(mc.player.getZ());
        if (lastFloor == FactoryMapLayerResolver.NO_FLOOR
                || bx != lastBlockX || by != lastBlockY || bz != lastBlockZ
                || frameCount % 20 == 0) {
            lastBlockX = bx;
            lastBlockY = by;
            lastBlockZ = bz;
            lastFloor = FactoryMapLayerResolver.resolvePlayerFloor(mc.level, mc.player);
        }

        int size = MapConfig.MINIMAP_SIZE.get();
        int x = 6, y = 6;
        // 底幕：近实心深色，保证未加载区域的标点/箭头可读。
        g.fill(x - 1, y - 1, x + size + 1, y + size + 1, 0xE609151B);
        var t = new MapCoordinateTransform(mc.player.getX(), mc.player.getZ(),
                MapConfig.MINIMAP_ZOOM.get(), x, y, size, size);
        var view = new MinimapView(new FactoryMapLayerResolver.Layer(
                0, lastFloor, 0, 0, 0, 0, 1, List.of()));
        g.enableScissor(x, y, x + size, y + size);
        TILES.draw(g, mc, t, view);
        if (MapConfig.MARKERS_VISIBLE.get()) {
            float partial = dt.getGameTimeDeltaPartialTick(true);
            for (var marker : TacticalMarkerManager.snapshot(partial)) {
                var pos = marker.position(partial);
                if (Math.abs(pos.y - 1 - lastFloor) > 3) continue; // 与大地图同口径：楼层 ±3
                int mx = Mth.floor(t.worldToScreenX(pos.x)), my = Mth.floor(t.worldToScreenY(pos.z));
                int color = color(marker.type());
                g.fill(mx - 2, my - 2, mx + 3, my + 3, color); // 5×5 类型色方块
                g.fill(mx, my, mx + 1, my + 1, 0xFF0B171D);    // 中心 1×1 深色点
            }
        }
        player(g, x + size / 2, y + size / 2, mc.player.getYRot());
        g.disableScissor();

        // 边框 + 四角 3px ACCENT 角标（战术感，参考三角洲）。
        box(g, x - 1, y - 1, size + 2, size + 2, 0xFF2D3748);
        corner(g, x - 1, y - 1, 1, 1);          // 左上
        corner(g, x + size, y - 1, -1, 1);      // 右上
        corner(g, x - 1, y + size, 1, -1);      // 左下
        corner(g, x + size, y + size, -1, -1);  // 右下
        // 顶部中央 "N" 北向指示（GREEN）。
        text(g, "N", x + (size - mc.font.width("N")) / 2, y + 1, GREEN);

        // 对局计时（反馈⑨下半句）：小地图下方居中一行；宽度超出 size 时 0.8 缩排。
        String timer = tr("match_timer", MapMatchTimer.format());
        if (mc.font.width(timer) <= size) {
            text(g, timer, x + (size - mc.font.width(timer)) / 2, y + size + 4, TEXT);
        } else {
            smallText(g, timer, x + (size - textWidth(timer, 0.8f)) / 2, y + size + 4, TEXT, 0.8f);
        }
    }

    /** 3px ACCENT 角标：横 3×1 + 竖 1×3 组成的 L 形，盖在边框角上（dx/dy = 向内延伸方向 ±1）。 */
    private static void corner(GuiGraphics g, int cx, int cy, int dx, int dy) {
        int hx = dx > 0 ? cx : cx - 2;
        g.fill(hx, cy, hx + 3, cy + 1, ACCENT);
        int vy = dy > 0 ? cy : cy - 2;
        g.fill(cx, vy, cx + 1, vy + 3, ACCENT);
    }
}
