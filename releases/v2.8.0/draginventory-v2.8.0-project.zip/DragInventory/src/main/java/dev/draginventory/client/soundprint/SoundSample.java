package dev.draginventory.client.soundprint;

/**
 * 一次声音事件的不可变快照（声纹检测的最小数据单元）。
 *
 * <p>由 {@link SoundPrintEvents} 在 PlaySoundEvent 回调里构造、投入并发队列，
 *  由 {@link SoundPrintTracker} 在 client tick 汇入活跃声源表。
 *  全字段原始类型 + 不可变，跨线程传递零共享可变状态。</p>
 *
 * @param x       声源世界坐标 X
 * @param y       声源世界坐标 Y
 * @param z       声源世界坐标 Z
 * @param type    分类结果（脚步 / 枪声），不为 null
 * @param volume  声音实例的原始相对音量（0~1+，未经距离衰减）
 * @param atMillis 事件时刻（毫秒钟）
 * @param soundId 声音资源 id 字符串（调试 / 溯源用）
 */
public record SoundSample(
        double x, double y, double z,
        SoundPrintType type,
        float volume,
        long atMillis,
        String soundId) {

    /** 与另一样本是否指向同一个物理声源（同类型且足够近，用于"重听即刷新"合并）。 */
    public boolean sameSourceAs(SoundSample other, double mergeDistance) {
        if (other == null || type != other.type) return false;
        double dx = x - other.x, dy = y - other.y, dz = z - other.z;
        return dx * dx + dy * dy + dz * dz <= mergeDistance * mergeDistance;
    }
}
