package dev.draginventory.client.soundprint;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.sound.PlaySoundEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 声纹客户端事件（NeoForge 总线）：
 * <ul>
 *   <li>{@link PlaySoundEvent}：声音采集入口——玩家客户端<b>听得到</b>的声音才会
 *       进入事件（天然与服务器授权一致，不引入任何额外网络包 / 探测）；回调只做
 *       “分类 + 过滤 + 快照入队”，重活全部留给主线程 tick。</li>
 *   <li>client tick：驱动配置防抖落盘 + {@link SoundPrintTracker} 步进。</li>
 *   <li>退出世界：配置落盘兜底 + 状态清空。</li>
 *   <li>注册游戏内指令（/herrasoundprint，别名 /soundprint /sp）。</li>
 * </ul>
 * 声音线程安全性：PlaySoundEvent 绝大多数在主线程触发；即便异常路径来自声音线程，
 * 入口也只写并发队列（{@link SoundPrintTracker#offer}），主线程单消费者。</p>
 *
 * <h2>v2.7.1 实机崩溃修复（用户实测：进存档走第一步即崩）</h2>
 * <p>两处叠加缺陷，本次一并修复：</p>
 * <ol>
 *   <li><b>采集 NPE（崩溃根因）</b>：{@code SoundEngine.play} 先发 PlaySoundEvent、
 *       事件返回后才调 {@code resolve()}——回调里
 *       {@code AbstractSoundInstance} 内部的 sound 字段必然为 null，
 *       {@code getVolume()} 在其内部直接解引用，世界内任何命中关键字的声音都会
 *       NPE 炸穿客户端 tick（崩溃堆栈：LocalPlayer.aiStep → playStepSound →
 *       PlaySoundEvent → SoundPrintEvents:97）。修复：先借 SoundManager 幂等补一次
 *       resolve 再读响度，未注册声效（引擎最终只会 warn 不会播）按“听得到才采集”
 *       跳过，任何实现异常一律退回满响度、绝不外溢。</li>
 *   <li><b>自声过滤从未生效</b>：原实现以“眼睛位置”为基准做 3D 距离，而脚步声在
 *       脚部播放——垂直差 1.62m 直接击穿 0.9m 阈值，自己的脚步从来没被过滤过
 *       （正是它触发了上面的 NPE）。修复：改为“声源到玩家碰撞箱的最近距离”
 *       （0.6 宽 × 1.8 高，体内为 0m）——自声全部发自体内，贴脸敌人的碰撞箱
 *       间隙仍有约 0.6m，语义边界清晰。</li>
 * </ol>
 * 此外整个采集体包一层兜底 try-catch：声纹是纯展示功能，任何第三方模组的
 * 非常规 {@link SoundInstance} 实现（本实测环境为 Connector 转换的 Fabric 模组声）
 * 都不允许杀死客户端——同类异常只报一次日志。
 */
@EventBusSubscriber(modid = "draginventory", value = Dist.CLIENT)
public final class SoundPrintEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger("DragInventory/SoundPrint");

    /** 全局唯一追踪器（HUD 渲染与设置界面预览共用真实态；预览走 Widget 合成数据）。 */
    static final SoundPrintTracker TRACKER = new SoundPrintTracker();

    /** 模拟声源（v2.8.0 缺陷⑤测试功能）：指令 / 设置界面可控，会话级不落盘。 */
    static final SoundPrintSimulator SIMULATOR = new SoundPrintSimulator();

    /** 走动续期阈值：水平速度低于该值（米 / tick）不算走动（静步 / 潜行不触发）。
     *  正常行走 ≈ 0.1，疾跑 ≈ 0.28，潜行 ≈ 0.03~0.05。 */
    private static final double WALK_SPEED_MIN = 0.06;

    /** 采集兜底异常的同类只报一次（避免每步刷屏；首次即代表全部）。 */
    private static final AtomicBoolean CAPTURE_FAULT_REPORTED = new AtomicBoolean(false);

    /** 参与声纹的声音类别（脚步 / 实体 / 方块 / 玩家动作）；音乐、唱片、天气、
     *  环境、UI、MASTER 一律不采集。 */
    private static boolean relevantCategory(SoundSource source) {
        return source == SoundSource.NEUTRAL
                || source == SoundSource.HOSTILE
                || source == SoundSource.PLAYERS
                || source == SoundSource.BLOCKS;
    }

    private SoundPrintEvents() {}

    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent event) {
        try {
            capture(event.getSound());
        } catch (RuntimeException e) {
            // v2.7.1：兜底——事件回调里的任何异常都会顺着 EventBus 杀死客户端
            // tick。声纹只是可视化增益，宁可丢一条声纹，绝不崩游戏。
            if (CAPTURE_FAULT_REPORTED.compareAndSet(false, true)) {
                LOGGER.warn("声纹采集异常（同类异常只记录一次，之后静默丢弃）", e);
            }
        }
    }

    private static void capture(SoundInstance sound) {
        if (!SoundPrintConfig.ENABLED.get()) return;
        if (sound == null) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) return;

        // 类别预筛（廉价枚举比较，挡掉音乐 / 环境等绝大多数噪音）。
        if (!relevantCategory(sound.getSource())) return;
        // 相对坐标声（GUI / 音乐引擎）没有世界语义。
        if (sound.isRelative()) return;
        // 循环声（营火、唱片机残响等）不适合事件驱动的声纹（每次 play 触发一次，
        // 循环声会表现为周期重击）；声纹要的是“事件”。
        if (sound.isLooping()) return;

        // 分类（关键字表带配置缓存，热路径零解析）。
        SoundPrintType type = SoundClassifier.classify(
                sound.getLocation().toString(),
                SoundPrintConfig.footstepKeywords(),
                SoundPrintConfig.gunshotKeywords());
        if (type == null) return;
        if (type == SoundPrintType.FOOTSTEP && !SoundPrintConfig.FOOTSTEPS.get()) return;
        if (type == SoundPrintType.GUNSHOT && !SoundPrintConfig.GUNSHOTS.get()) return;

        double x = sound.getX();
        double y = sound.getY();
        double z = sound.getZ();
        double ex = player.getX();
        double ey = player.getEyeY();
        double ez = player.getZ();

        // 玩家自己的声音：脚步 / 落地 / 受伤等全部发自碰撞箱内部（见类注释
        // v2.7.1 修复②）。以脚底坐标重建 0.6×1.8×0.6 碰撞箱，声源到箱体的
        // 最近距离即自声判定（体内 = 0m）。
        boolean own = SoundPrintCaptureRules.isOwnSound(
                player.getX(), player.getY(), player.getZ(), x, y, z);

        // v2.8.0 缺陷①：检测自己的枪声（测试用）。自声枪声若按原坐标采集，
        // dx=dz=0 会使 atan2 恒指北，面朝其他方向时声纹落在视野外——按
        // “枪口在我眼前”的语义投影到视线前方 4m：声纹落在条带正中，俯仰时
        // 垂直偏移联动（4m 摆幅足以触发箭头阈值），距离近能量足。
        if (own && type == SoundPrintType.GUNSHOT && SoundPrintConfig.OWN_GUNSHOTS.get()) {
            Vec3 view = player.getViewVector(1f);
            Vec3 eye = player.getEyePosition(1f);
            double[] ahead = SoundPrintCaptureRules.projectAhead(
                    eye.x, eye.y, eye.z, view.x, view.y, view.z, 4.0);
            x = ahead[0];
            y = ahead[1];
            z = ahead[2];
            own = false;
        }

        if (own && SoundPrintConfig.IGNORE_OWN.get()) {
            return;
        }

        // 半径过滤：检测半径外的声音不产生声纹（听得到的距离由声音引擎决定，
        // 声纹半径是战术意义上的“关注圈”）。
        float dist = SoundPrintTracker.distance(x, y, z, ex, ey, ez);
        if (dist > SoundPrintConfig.RADIUS.get()) return;

        // 响度读取（见类注释 v2.7.1 修复①）：NaN = 引擎最终不会播放，不采集。
        float loudness = loudness(sound, mc.getSoundManager());
        if (Float.isNaN(loudness)) return;

        TRACKER.offer(new SoundSample(x, y, z, type,
                Math.max(0.05f, Math.min(1f, loudness)),
                System.currentTimeMillis(),
                sound.getLocation().toString()));
    }

    /**
     * v2.7.1 修复①适配层（MC 薄适配，决策在 {@link SoundPrintCaptureRules#safeLoudness}
     * 纯 JVM 回归）：响度 NaN = 引擎最终不会播放，不采集。
     */
    static float loudness(SoundInstance sound, SoundManager manager) {
        return SoundPrintCaptureRules.safeLoudness(new SoundPrintCaptureRules.SoundView() {
            @Override
            public Object resolvedSound() {
                return sound.getSound();
            }

            @Override
            public void resolveOnce() {
                sound.resolve(manager); // 幂等：引擎稍后自己还会再 resolve 一次
            }

            @Override
            public boolean isUnplayable(Object resolved) {
                // 未注册声效 / 模组刻意留空的静音声效：SoundEngine 只会 warn 不会排程。
                return resolved == SoundManager.EMPTY_SOUND
                        || resolved == SoundManager.INTENTIONALLY_EMPTY_SOUND;
            }

            @Override
            public float rawVolume() {
                return sound.getVolume(); // 未解析时此处必 NPE，时序由决策层保证
            }
        });
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        SoundPrintConfig.tickSave();
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            // 离开世界：清空（下一世界的残留声源坐标无意义）。
            if (TRACKER.activeCount() > 0) TRACKER.clear();
            SIMULATOR.reset();
            return;
        }
        if (!SoundPrintConfig.ENABLED.get()) return;
        var eye = mc.player.getEyePosition(1f);
        long now = System.currentTimeMillis();

        // v2.8.0 缺陷⑤：模拟声源——与真实声音同路（停留 / 淡出 / 聚合 / 动画）。
        if (SIMULATOR.isEnabled()) {
            for (SoundSample sample : SIMULATOR.tick(now, eye.x, eye.y, eye.z)) {
                TRACKER.offer(sample);
            }
        }

        // v2.8.0 缺陷②：走动续期——半径内正在走动的实体（含玩家与生物，
        // 静步不触发）续期 / 新建脚步源，停走后按 linger 淡出。
        if (SoundPrintConfig.MOTION_PERSIST.get()) {
            TRACKER.motionTick(now, collectMovers(mc, eye,
                    SoundPrintConfig.RADIUS.get().floatValue()));
        }

        TRACKER.tick(now,
                eye.x, eye.y, eye.z,
                SoundPrintConfig.RADIUS.get(),
                SoundPrintConfig.MIN_DECAY.get().floatValue(),
                SoundPrintConfig.DISTANCE_DECAY.get(),
                SoundPrintConfig.ATTACK.get().floatValue(),
                SoundPrintConfig.RELEASE.get().floatValue(),
                SoundPrintConfig.LINGER_MS.get());
    }

    /** 走动实体采集（主线程）：在地面 + 水平速度超阈 + 半径内（以眼睛为基准）。 */
    private static List<SoundPrintTracker.Mover> collectMovers(Minecraft mc, Vec3 eye, float radius) {
        List<SoundPrintTracker.Mover> movers = new ArrayList<>(4);
        double r2 = (double) radius * radius;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity == mc.player || !(entity instanceof LivingEntity living)) continue;
            if (!living.onGround()) continue; // 空中 / 游泳不发脚步声
            var dm = living.getDeltaMovement();
            double h2 = dm.x * dm.x + dm.z * dm.z;
            if (h2 < WALK_SPEED_MIN * WALK_SPEED_MIN) continue; // 静步 / 微抖
            double dx = living.getX() - eye.x;
            double dy = living.getY() - eye.y;
            double dz = living.getZ() - eye.z;
            if (dx * dx + dy * dy + dz * dz > r2) continue;
            movers.add(new SoundPrintTracker.Mover(
                    living.getX(), living.getY(), living.getZ(), Math.sqrt(h2)));
        }
        return movers;
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        SoundPrintConfig.flush();
        TRACKER.clear();
        SIMULATOR.reset();
    }

    @SubscribeEvent
    public static void onRegisterClientCommands(RegisterClientCommandsEvent event) {
        for (var root : SoundPrintCommands.buildRoots()) {
            event.getDispatcher().register(root);
        }
    }

    /** 活跃声源数（指令 / 调试用）。 */
    public static List<String> debugSummary() {
        return List.of("active_sources=" + TRACKER.activeCount());
    }
}
