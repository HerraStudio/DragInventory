package dev.draginventory.client.soundprint;

import java.util.List;
import java.util.Random;

/**
 * 模拟声源（v2.8.0 缺陷⑤：指令菜单可控的测试功能）。
 *
 * <p>在玩家所选固定方位模拟一个脚步 / 枪声源，实时喂给 {@link SoundPrintTracker}
 * 的正常管线（与真实声音完全同路：同样的停留 / 淡出 / 聚合 / 动画），用于
 * 实机校验声纹各形态参数。三种移动模式：</p>
 * <ul>
 *   <li><b>static</b>：固定在所选方位（基础校验）。</li>
 *   <li><b>orbit</b>：方位匀速旋转（18°/s，校验声纹随声源滑移与方位条同步）。</li>
 *   <li><b>random</b>：随机游走——每 1.2~2.4 秒重定方位 ±50°、距离 ±2.5m，
 *       期间指数趋近（校验任意方向的连续跟踪）。</li>
 * </ul>
 *
 * <p>发射节奏：脚步每 420ms 一次（低于默认 linger 650ms，表现连续行走），
 * 枪声每 2200ms 一次（表现一次爆发后的完整淡出曲线）。状态为会话级
 * （不落盘、默认关，重启游戏后归零——避免忘关导致正常游玩出现幻声纹）。</p>
 *
 * <p>纯 JVM（零 MC 依赖），单测直接驱动时间线与位置数学。</p>
 */
public final class SoundPrintSimulator {

    /** 移动模式。 */
    public enum Movement { STATIC, ORBIT, RANDOM }

    /** 模拟样本的 soundId（调试 / 溯源）。 */
    public static final String ID_FOOTSTEP = "draginventory:sim_footstep";
    public static final String ID_GUNSHOT = "draginventory:sim_gunshot";

    /** 脚步发射间隔（毫秒）：略低于默认 linger，走动表现连续。 */
    static final long FOOTSTEP_INTERVAL_MS = 420L;
    /** 枪声发射间隔（毫秒）：完整看完一次爆发与淡出。 */
    static final long GUNSHOT_INTERVAL_MS = 2200L;
    /** orbit 模式角速度（度 / 秒）。 */
    static final float ORBIT_DEG_PER_SEC = 18f;
    /** random 模式：重定目标间隔下限 / 跨度（毫秒）。 */
    static final long RETARGET_MIN_MS = 1200L;
    static final long RETARGET_SPAN_MS = 1200L;
    /** random 模式：方位跳幅半宽（度）与距离抖幅（米）。 */
    static final float RANDOM_BEARING_SWING = 50f;
    static final float RANDOM_DISTANCE_SWING = 2.5f;
    /** random 模式：指数趋近速率（1/s）。 */
    static final float RANDOM_APPROACH_RATE = 3.5f;

    private final Random random;

    private boolean enabled;
    private SoundPrintType type = SoundPrintType.FOOTSTEP;
    private float bearing = 90f;
    private float distance = 12f;
    private Movement movement = Movement.STATIC;

    private long lastEmitMillis = Long.MIN_VALUE;
    private long lastTickMillis = Long.MIN_VALUE;
    private long retargetAtMillis = Long.MIN_VALUE;
    private long retargetIntervalMillis = RETARGET_MIN_MS;
    private float targetBearing = 90f;
    private float targetDistance = 12f;

    public SoundPrintSimulator() {
        this(new Random());
    }

    /** 测试注入确定性随机源。 */
    SoundPrintSimulator(Random random) {
        this.random = random;
    }

    // ==================== 状态访问（GUI / 指令） ====================

    public boolean isEnabled() {
        return enabled;
    }

    /** 开关：开启时重置发射时钟（下一 tick 立即发声，测试反馈即时）。 */
    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        if (enabled) {
            lastEmitMillis = Long.MIN_VALUE;
            lastTickMillis = Long.MIN_VALUE;
            retargetAtMillis = Long.MIN_VALUE;
        }
    }

    public SoundPrintType type() {
        return type;
    }

    public void setType(SoundPrintType type) {
        this.type = type == null ? SoundPrintType.FOOTSTEP : type;
        lastEmitMillis = Long.MIN_VALUE; // 换类型立即发一声
    }

    public float bearing() {
        return bearing;
    }

    public void setBearing(float bearing) {
        this.bearing = wrap360(bearing);
        this.targetBearing = this.bearing;
    }

    public float distance() {
        return distance;
    }

    public void setDistance(float distance) {
        this.distance = clamp(distance, 2f, 20f);
        this.targetDistance = this.distance;
    }

    public Movement movement() {
        return movement;
    }

    public void setMovement(Movement movement) {
        this.movement = movement == null ? Movement.STATIC : movement;
    }

    // ==================== 步进 ====================

    /**
     * client tick 步进：推进移动模式，按节奏发射样本。
     *
     * @param eyeX eyeY eyeZ 玩家眼睛位置（模拟声源的世界锚点）
     * @return 本 tick 应投递的样本（空列表 = 未到发射时刻 / 未启用）
     */
    public List<SoundSample> tick(long nowMillis, double eyeX, double eyeY, double eyeZ) {
        if (!enabled) {
            lastTickMillis = nowMillis;
            return List.of();
        }
        float dt = stepSeconds(nowMillis);
        advanceMovement(nowMillis, dt);

        long interval = type == SoundPrintType.GUNSHOT
                ? GUNSHOT_INTERVAL_MS : FOOTSTEP_INTERVAL_MS;
        if (lastEmitMillis != Long.MIN_VALUE && nowMillis - lastEmitMillis < interval) {
            return List.of();
        }
        lastEmitMillis = nowMillis;

        // 方位 -> 世界坐标（与 bearingFrom 互逆：0°=北=-Z，90°=东=+X）。
        double rad = Math.toRadians(bearing);
        double x = eyeX + Math.sin(rad) * distance;
        double z = eyeZ - Math.cos(rad) * distance;
        // 脚步在地面（眼下 1.62m），枪声在耳高——覆盖垂直偏移两种语义。
        double y = type == SoundPrintType.GUNSHOT ? eyeY : eyeY - 1.62;
        float volume = type == SoundPrintType.GUNSHOT ? 1f : 0.6f;
        return List.of(new SoundSample(x, y, z, type, volume, nowMillis,
                type == SoundPrintType.GUNSHOT ? ID_GUNSHOT : ID_FOOTSTEP));
    }

    private float stepSeconds(long nowMillis) {
        float dt;
        if (lastTickMillis == Long.MIN_VALUE) {
            dt = 0.05f;
        } else {
            dt = Math.min(0.25f, Math.max(0.001f, (nowMillis - lastTickMillis) / 1000f));
        }
        lastTickMillis = nowMillis;
        return dt;
    }

    private void advanceMovement(long nowMillis, float dt) {
        switch (movement) {
            case STATIC -> {
                // 固定方位：无操作。
            }
            case ORBIT -> bearing = wrap360(bearing + ORBIT_DEG_PER_SEC * dt);
            case RANDOM -> {
                if (retargetAtMillis == Long.MIN_VALUE
                        || nowMillis - retargetAtMillis >= retargetIntervalMillis) {
                    retargetAtMillis = nowMillis;
                    retargetIntervalMillis = RETARGET_MIN_MS
                            + (long) (random.nextFloat() * RETARGET_SPAN_MS);
                    targetBearing = wrap360(bearing
                            + (random.nextFloat() - 0.5f) * 2f * RANDOM_BEARING_SWING);
                    targetDistance = clamp(distance
                            + (random.nextFloat() - 0.5f) * 2f * RANDOM_DISTANCE_SWING, 3f, 20f);
                }
                float k = 1f - (float) Math.exp(-RANDOM_APPROACH_RATE * dt);
                bearing = wrap360(bearing + wrapDelta(targetBearing - bearing) * k);
                distance = distance + (targetDistance - distance) * k;
            }
        }
    }

    /** 世界切换：清时钟（参数保留，重进世界继续按原设定模拟）。 */
    public void reset() {
        lastEmitMillis = Long.MIN_VALUE;
        lastTickMillis = Long.MIN_VALUE;
        retargetAtMillis = Long.MIN_VALUE;
    }

    // ==================== 数学 ====================

    static float wrap360(float v) {
        float r = v % 360f;
        return r < 0 ? r + 360f : r;
    }

    /** 圆周最短差（-180..180），随机游走用。 */
    static float wrapDelta(float d) {
        return ((d + 540f) % 360f) - 180f;
    }

    private static float clamp(float v, float min, float max) {
        return v < min ? min : Math.min(max, v);
    }
}
