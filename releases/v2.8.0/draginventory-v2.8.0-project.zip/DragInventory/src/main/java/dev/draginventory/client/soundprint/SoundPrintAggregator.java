package dev.draginventory.client.soundprint;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 声纹聚合器：把本帧的活跃声源命中列表整理为渲染簇。
 *
 * <p>两种模式（用户决策 v2.7.0：默认聚合合并，可切换并排错位）：
 * <ul>
 *   <li><b>merge</b>：按方位排序后线性分组（相邻方位差 ≤ 窗口即同簇），
 *       簇能量 RMS 合成、簇方位能量加权（圆周量向量平均，359° 与 1° 正确合成 0°）、
 *       垂直偏移能量加权、任一枪声即整簇红。同方位两三个脚步 = 一簇明显更高
 *       的白声纹；脚步 + 枪声 = 红声纹（威胁优先）。</li>
 *   <li><b>stagger</b>：同样的分组作为“族”，但成员保持独立声纹、按能量降序在
 *       族中心两侧横向错开（spacing * i），互不重叠、各自保留自己的颜色与
 *       垂直偏移（参考图 3 的多簇并列语言）。</li>
 * </ul>
 * 无论哪种模式都做 <b>去重抑制</b>：同物理声源的重复触发在 Tracker 层已合并；
 * 这里再限制簇总数上限，超限时优先保留能量高的簇（防极端声场把 HUD 铺满）。</p>
 *
 * <p>纯函数（输入只依赖值对象），全部单测覆盖。</p>
 */
public final class SoundPrintAggregator {

    /** 聚合器的输入命中：一个活跃声源在本帧的渲染快照（方位相对世界，非相对玩家）。 */
    public record Hit(float bearing, float energy, SoundPrintType type,
                      float verticalOffset, float distance) {}

    /** 输出簇数量上限（超限按能量降序截断）。 */
    static final int MAX_CLUSTERS = 16;

    private SoundPrintAggregator() {}

    /**
     * 聚合主入口。
     *
     * @param hits            活跃声源命中（任意顺序）
     * @param stagger         true = 并排错位模式；false = 聚合合并模式
     * @param mergeWindowDeg  聚合窗口（度，2~20）
     * @param staggerSpacing  错位间隔（像素，仅 stagger 模式使用）
     */
    public static List<SoundPrintCluster> aggregate(List<Hit> hits,
                                                    boolean stagger,
                                                    float mergeWindowDeg,
                                                    float staggerSpacing) {
        List<SoundPrintCluster> out = new ArrayList<>();
        if (hits.isEmpty()) return out;

        // 按方位排序（0 -> 360），随后线性扫描分组；再补一次首尾 wrap 检查
        //（358° 与 1° 在排序两端但物理同向）。
        List<Hit> sorted = new ArrayList<>(hits);
        sorted.sort(Comparator.comparingDouble(Hit::bearing));

        List<List<Hit>> groups = new ArrayList<>();
        List<Hit> current = new ArrayList<>();
        current.add(sorted.get(0));
        for (int i = 1; i < sorted.size(); i++) {
            Hit hit = sorted.get(i);
            if (hit.bearing() - current.get(current.size() - 1).bearing() <= mergeWindowDeg) {
                current.add(hit);
            } else {
                groups.add(current);
                current = new ArrayList<>();
                current.add(hit);
            }
        }
        groups.add(current);

        // 首尾 wrap 合并（首组最小方位与尾组最大方位的圆周距离 <= 窗口）。
        if (groups.size() > 1) {
            List<Hit> first = groups.get(0);
            List<Hit> last = groups.get(groups.size() - 1);
            float wrapGap = 360f - last.get(last.size() - 1).bearing() + first.get(0).bearing();
            if (wrapGap <= mergeWindowDeg) {
                last.addAll(first);
                groups.remove(0);
            }
        }

        for (List<Hit> group : groups) {
            out.add(stagger ? buildStagger(group, staggerSpacing) : buildMerged(group));
        }

        // 簇上限：按能量降序截断（威胁大的优先保留）。
        if (out.size() > MAX_CLUSTERS) {
            out.sort(Comparator.comparingDouble((SoundPrintCluster c) -> c.energy()).reversed());
            out = new ArrayList<>(out.subList(0, MAX_CLUSTERS));
        }
        return out;
    }

    // ==================== merge：聚合合并 ====================

    private static SoundPrintCluster buildMerged(List<Hit> group) {
        int n = group.size();
        float[] bearings = new float[n];
        float[] energies = new float[n];
        float energy = 0f;
        float verticalWeighted = 0f;
        float energySum = 0f;
        SoundPrintType type = SoundPrintType.FOOTSTEP;
        float nearest = Float.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            Hit hit = group.get(i);
            bearings[i] = hit.bearing();
            energies[i] = hit.energy();
            energy = SoundPrintEnvelope.mergeEnergy(energy, hit.energy());
            verticalWeighted += hit.verticalOffset() * Math.max(0.05f, hit.energy());
            energySum += Math.max(0.05f, hit.energy());
            if (hit.type() == SoundPrintType.GUNSHOT) type = SoundPrintType.GUNSHOT;
            nearest = Math.min(nearest, hit.distance());
        }
        float bearing = SoundPrintEnvelope.weightedBearing(bearings, energies);
        float vertical = energySum > 0f ? verticalWeighted / energySum : 0f;
        return new SoundPrintCluster(bearing, energy, type, vertical, nearest, n, false, List.of());
    }

    // ==================== stagger：并排错位 ====================

    private static SoundPrintCluster buildStagger(List<Hit> group, float staggerSpacing) {
        // 成员按能量降序：最响的居中，其余两侧展开（对称错位更接近参考图 3 的节奏）。
        List<Hit> sorted = new ArrayList<>(group);
        sorted.sort(Comparator.comparingDouble((Hit h) -> h.energy()).reversed());

        int n = sorted.size();
        float[] bearings = new float[n];
        float[] energies = new float[n];
        List<SoundPrintCluster.Member> members = new ArrayList<>(n);
        float maxEnergy = 0f;
        SoundPrintType type = SoundPrintType.FOOTSTEP;
        float nearest = Float.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            Hit hit = sorted.get(i);
            bearings[i] = hit.bearing();
            energies[i] = hit.energy();
            maxEnergy = Math.max(maxEnergy, hit.energy());
            if (hit.type() == SoundPrintType.GUNSHOT) type = SoundPrintType.GUNSHOT;
            nearest = Math.min(nearest, hit.distance());
            // 错位：i=0 居中；此后交替右侧、左侧向外扩（-1,+1,-2,+2 ...）。
            int slot = (i + 1) / 2 * (i % 2 == 0 ? -1 : 1);
            members.add(new SoundPrintCluster.Member(
                    hit.bearing(), hit.energy(), hit.type(),
                    hit.verticalOffset(), hit.distance(), slot * staggerSpacing));
        }
        float bearing = SoundPrintEnvelope.weightedBearing(bearings, energies);
        return new SoundPrintCluster(bearing, maxEnergy, type, 0f, nearest, n, true, List.copyOf(members));
    }
}
