package dev.draginventory.client.soundprint;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;

/**
 * 声纹 HUD 层注册：独立 GUI 层（registerAboveAll，与方位条层同机制），
 * 不触碰任何现有 HUD 类。F1 隐藏 GUI 时与原版层一起隐藏（Gui 渲染入口统一控制）。
 */
@EventBusSubscriber(modid = "draginventory", value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class SoundPrintHudRegistration {

    private static final ResourceLocation LAYER_ID =
            ResourceLocation.fromNamespaceAndPath("draginventory", "soundprint");
    private static final SoundPrintHud LAYER = new SoundPrintHud();

    private SoundPrintHudRegistration() {}

    @SubscribeEvent
    public static void onRegisterGuiLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(LAYER_ID, LAYER);
    }
}
