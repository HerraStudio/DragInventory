package dev.draginventory.client.soundprint;

import java.util.List;
import java.util.Locale;

/**
 * 声音分类器：把声音资源 id 映射为声纹类型（脚步 / 枪声 / 不关心）。
 *
 * <p>判定策略为小写子串匹配，关键字表来自配置
 * （{@link SoundPrintConfig#FOOTSTEP_KEYWORDS} / {@link SoundPrintConfig#GUNSHOT_KEYWORDS}），
 * 默认表覆盖原版实体脚步（{@code entity.<type>.step}）与常见枪械模组命名
 * （gun / shot / shoot / rifle / ...）。GWO 等外部枪械模组的声音 id
 * 无法枚举，用户可通过配置追加关键字，无需发版。</p>
 *
 * <p>核心逻辑为纯函数（注入关键字表），全部单测覆盖；MC 事件层只做取参。</p>
 */
public final class SoundClassifier {

    private SoundClassifier() {}

    /**
     * 分类一个声音 id。
     *
     * @param soundId           声音资源 id（如 "minecraft:entity.zombie.step"），可为 null
     * @param footstepKeywords  脚步关键字表（已小写化）
     * @param gunshotKeywords   枪声关键字表（已小写化）
     * @return 类型；null = 该声音与声纹无关（不显示）
     */
    public static SoundPrintType classify(String soundId,
                                          List<String> footstepKeywords,
                                          List<String> gunshotKeywords) {
        if (soundId == null || soundId.isEmpty()) return null;
        String id = soundId.toLowerCase(Locale.ROOT);
        // 脚步优先：entity.zombie.step 同时含 "step"；某些枪械 id 可能含 "fire"
        //（如 fire_rate），先判脚步再判枪声可避免个别 id 双命中时错归枪声。
        for (String keyword : footstepKeywords) {
            if (keyword != null && !keyword.isEmpty() && id.contains(keyword)) return SoundPrintType.FOOTSTEP;
        }
        for (String keyword : gunshotKeywords) {
            if (keyword != null && !keyword.isEmpty() && id.contains(keyword)) return SoundPrintType.GUNSHOT;
        }
        return null;
    }

    /** 解析逗号分隔的关键字配置为小写列表（空段跳过；保证至少返回空表而非 null）。 */
    public static List<String> parseKeywords(String csv) {
        if (csv == null || csv.isBlank()) return List.of();
        String lower = csv.toLowerCase(Locale.ROOT);
        var out = new java.util.ArrayList<String>();
        for (String part : lower.split(",")) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) out.add(trimmed);
        }
        return out;
    }

    /** 快速预筛：id 是否值得进入分类（含任一关键字才继续），减少热路径字符串操作。 */
    public static boolean mayRelate(String soundId, List<String> footstepKeywords, List<String> gunshotKeywords) {
        if (soundId == null || soundId.isEmpty()) return false;
        return classify(soundId, footstepKeywords, gunshotKeywords) != null;
    }
}
