package dev.draginventory.client.soundprint;

import com.mojang.blaze3d.platform.InputConstants;
import dev.draginventory.client.compass.CompassConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.common.ModConfigSpec;
import org.lwjgl.glfw.GLFW;

/**
 * 声纹设置界面：与 {@code CompassSettingsScreen} 同一套像素战术风视觉语言
 * （三主题 MenuTheme / 行控件 / 实时预览 / 关闭动画），为声纹定制的精简版。
 *
 * <p>与方位条设置界面的差异（设计决策）：
 * <ul>
 *   <li>主题跟随 {@code CompassConfig.MENU_THEME}（HERRA 界面统一观感）。</li>
 *   <li>无全屏拖拽定位：声纹水平几何硬绑定方位条（战术一体），仅暴露与方位条
 *       底边的垂直间距。</li>
 *   <li>实时预览为合成声场（近脚步 / 远脚步 / 枪声 + 上箭头）并自动摆动，
 *       覆盖 merge 与 stagger 两种模式的即时观感。</li>
 * </ul></p>
 */
public final class SoundPrintSettingsScreen extends Screen {

    // ==================== 主题（与 CompassSettingsScreen 同色值） ====================

    private record MenuTheme(int accent, int accentBright, int panelBg, int panelInner, int panelBorder) {}

    private static final MenuTheme AMBER =
            new MenuTheme(0xFFD4A056, 0xFFF1C40F, 0xF61E2326, 0xFF2B3236, 0xFF4A555C);
    private static final MenuTheme TECH =
            new MenuTheme(0xFF2FB8A6, 0xFF5EEAD4, 0xF6161C24, 0xFF212A33, 0xFF41525E);
    private static final MenuTheme CRIMSON =
            new MenuTheme(0xFFCE5454, 0xFFFF7B72, 0xF6201719, 0xFF2B2124, 0xFF564249);

    private static MenuTheme theme() {
        return switch (CompassConfig.MENU_THEME.get()) {
            case "tech" -> TECH;
            case "crimson" -> CRIMSON;
            default -> AMBER;
        };
    }

    // 中性色（与 CompassSettingsScreen 同值）
    private static final int TITLE_TEXT = 0xFFE0E6ED;
    private static final int LABEL_TEXT = 0xFFBDC3C7;
    private static final int VALUE_TEXT = 0xFF7F8C8D;
    private static final int ROW_HOVER = 0x14FFFFFF;
    private static final int CONTROL_BG = 0xFF262D33;
    private static final int CONTROL_BG_HOVER = 0xFF333B42;
    private static final int TRACK_EDGE = 0xFF16191D;
    private static final int KNOB = 0xFFE0E6ED;

    private static final int ROW_H = 17;
    private static final int PAD = 12;

    // ==================== 行控件模型 ====================

    private sealed interface Control permits BoolControl, SliderControl, CyclerControl, ButtonControl {
        String labelKey();

        int height();
    }

    private record BoolControl(String labelKey, Supplier<Boolean> get,
                               Consumer<Boolean> set) implements Control {
        @Override public int height() { return ROW_H; }
    }

    /** 滑杆：[min, max] 整数 / 浮点通用（step 为浮点步长）。 */
    private record SliderControl(String labelKey, float min, float max, float step,
                                 Supplier<Float> get, Consumer<Float> set,
                                 String fmt) implements Control {
        @Override public int height() { return ROW_H; }

        float fraction() {
            return Mth.clamp((get.get() - min) / Math.max(1e-4f, max - min), 0f, 1f);
        }
    }

    /** 循环器：点击在选项间循环。 */
    private record CyclerControl(String labelKey, List<String> options,
                                 Supplier<String> get, Consumer<String> set) implements Control {
        @Override public int height() { return ROW_H; }

        String current() {
            String v = get.get();
            return options.contains(v) ? v : options.get(0);
        }

        void next() {
            int i = (options.indexOf(current()) + 1) % options.size();
            set.accept(options.get(i));
        }
    }

    private record ButtonControl(String labelKey, Runnable action) implements Control {
        @Override public int height() { return ROW_H; }
    }

    // ==================== 状态 ====================

    private final SoundPrintWidget preview = new SoundPrintWidget(true);
    private final List<List<Control>> tabs = new ArrayList<>();
    private final long openTime;
    private final int[] tabScroll = new int[6];
    private int activeTab;
    private boolean swayOn = true;

    private SliderControl draggingSlider;
    private long closeStart;

    private int panelX, panelY, panelW, panelH;
    private int previewBoxY, previewBoxH;
    private int tabBarY;
    private int contentY, contentH;
    private int footerY;

    private int mouseX, mouseY;

    public static SoundPrintSettingsScreen create() {
        return new SoundPrintSettingsScreen();
    }

    private SoundPrintSettingsScreen() {
        super(Component.translatable("draginventory.soundprint.title"));
        this.openTime = System.currentTimeMillis();
        buildTabs();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        SoundPrintConfig.flush();
        if (closeStart == 0) {
            closeStart = System.currentTimeMillis();
        }
    }

    private void forceClose() {
        SoundPrintConfig.flush();
        super.onClose();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (closeStart == 0) {
                onClose();
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    // ==================== 页签内容 ====================

    private void buildTabs() {
        tabs.clear();
        // 1 常规
        tabs.add(List.of(
                new BoolControl("draginventory.soundprint.cfg.enabled",
                        SoundPrintConfig.ENABLED::get,
                        v -> SoundPrintConfig.set(SoundPrintConfig.ENABLED, v)),
                new BoolControl("draginventory.soundprint.cfg.follow_compass",
                        SoundPrintConfig.FOLLOW_COMPASS::get,
                        v -> SoundPrintConfig.set(SoundPrintConfig.FOLLOW_COMPASS, v)),
                new SliderControl("draginventory.soundprint.cfg.spacing", 0, 20, 1,
                        () -> (float) SoundPrintConfig.SPACING.get(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.SPACING, Math.round(v)),
                        "%.0f px"),
                new SliderControl("draginventory.soundprint.cfg.opacity", 0.15f, 1f, 0.05f,
                        () -> SoundPrintConfig.OPACITY.get().floatValue(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.OPACITY, round2(v)),
                        "%.2f"),
                new SliderControl("draginventory.soundprint.cfg.scale", 0.5f, 2f, 0.05f,
                        () -> SoundPrintConfig.SCALE.get().floatValue(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.SCALE, round2(v)),
                        "%.2f")));
        // 2 检测
        tabs.add(List.of(
                new SliderControl("draginventory.soundprint.cfg.radius", 4, 64, 1,
                        () -> (float) SoundPrintConfig.RADIUS.get(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.RADIUS, Math.round(v)),
                        "%.0f m"),
                new BoolControl("draginventory.soundprint.cfg.footsteps",
                        SoundPrintConfig.FOOTSTEPS::get,
                        v -> SoundPrintConfig.set(SoundPrintConfig.FOOTSTEPS, v)),
                new BoolControl("draginventory.soundprint.cfg.gunshots",
                        SoundPrintConfig.GUNSHOTS::get,
                        v -> SoundPrintConfig.set(SoundPrintConfig.GUNSHOTS, v)),
                new BoolControl("draginventory.soundprint.cfg.ignore_own",
                        SoundPrintConfig.IGNORE_OWN::get,
                        v -> SoundPrintConfig.set(SoundPrintConfig.IGNORE_OWN, v)),
                new BoolControl("draginventory.soundprint.cfg.own_gunshots",
                        SoundPrintConfig.OWN_GUNSHOTS::get,
                        v -> SoundPrintConfig.set(SoundPrintConfig.OWN_GUNSHOTS, v)),
                new BoolControl("draginventory.soundprint.cfg.motion_persist",
                        SoundPrintConfig.MOTION_PERSIST::get,
                        v -> SoundPrintConfig.set(SoundPrintConfig.MOTION_PERSIST, v))));
        // 3 多声源
        tabs.add(List.of(
                new CyclerControl("draginventory.soundprint.cfg.mode",
                        List.of("merge", "stagger"),
                        SoundPrintConfig.MODE::get,
                        v -> SoundPrintConfig.set(SoundPrintConfig.MODE, v)),
                new SliderControl("draginventory.soundprint.cfg.merge_window", 2, 20, 1,
                        () -> (float) SoundPrintConfig.MERGE_WINDOW.get(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.MERGE_WINDOW, Math.round(v)),
                        "%.0f°"),
                new SliderControl("draginventory.soundprint.cfg.stagger_spacing", 1, 6, 1,
                        () -> (float) SoundPrintConfig.STAGGER_SPACING.get(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.STAGGER_SPACING, Math.round(v)),
                        "%.0f px")));
        // 4 形态
        tabs.add(List.of(
                new SliderControl("draginventory.soundprint.cfg.bar_count", 5, 21, 2,
                        () -> (float) SoundPrintConfig.BAR_COUNT.get(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.BAR_COUNT, Math.round(v)),
                        "%.0f"),
                new SliderControl("draginventory.soundprint.cfg.bar_width", 1, 4, 1,
                        () -> (float) SoundPrintConfig.BAR_WIDTH.get(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.BAR_WIDTH, Math.round(v)),
                        "%.0f px"),
                new SliderControl("draginventory.soundprint.cfg.bar_gap", 0, 3, 1,
                        () -> (float) SoundPrintConfig.BAR_GAP.get(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.BAR_GAP, Math.round(v)),
                        "%.0f px"),
                new SliderControl("draginventory.soundprint.cfg.max_height", 8, 56, 2,
                        () -> (float) SoundPrintConfig.MAX_HEIGHT.get(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.MAX_HEIGHT, Math.round(v)),
                        "%.0f px"),
                new BoolControl("draginventory.soundprint.cfg.baseline",
                        SoundPrintConfig.BASELINE::get,
                        v -> SoundPrintConfig.set(SoundPrintConfig.BASELINE, v)),
                new BoolControl("draginventory.soundprint.cfg.arrows",
                        SoundPrintConfig.ARROWS::get,
                        v -> SoundPrintConfig.set(SoundPrintConfig.ARROWS, v)),
                new BoolControl("draginventory.soundprint.cfg.vertical_offset",
                        SoundPrintConfig.VERTICAL_OFFSET::get,
                        v -> SoundPrintConfig.set(SoundPrintConfig.VERTICAL_OFFSET, v)),
                new CyclerControl("draginventory.soundprint.cfg.color_footstep",
                        colorOptions(),
                        () -> colorOptionKey(SoundPrintConfig.COLOR_FOOTSTEP.get(),
                                SoundPrintType.FOOTSTEP.defaultRgb()),
                        v -> SoundPrintConfig.set(SoundPrintConfig.COLOR_FOOTSTEP,
                                colorValue(v, SoundPrintType.FOOTSTEP.defaultRgb()))),
                new CyclerControl("draginventory.soundprint.cfg.color_gunshot",
                        colorOptions(),
                        () -> colorOptionKey(SoundPrintConfig.COLOR_GUNSHOT.get(),
                                SoundPrintType.GUNSHOT.defaultRgb()),
                        v -> SoundPrintConfig.set(SoundPrintConfig.COLOR_GUNSHOT,
                                colorValue(v, SoundPrintType.GUNSHOT.defaultRgb())))));
        // 5 动画与检测曲线
        tabs.add(List.of(
                new BoolControl("draginventory.soundprint.cfg.distance_decay",
                        SoundPrintConfig.DISTANCE_DECAY::get,
                        v -> SoundPrintConfig.set(SoundPrintConfig.DISTANCE_DECAY, v)),
                new SliderControl("draginventory.soundprint.cfg.min_decay", 0f, 0.6f, 0.05f,
                        () -> SoundPrintConfig.MIN_DECAY.get().floatValue(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.MIN_DECAY, round2(v)),
                        "%.2f"),
                new SliderControl("draginventory.soundprint.cfg.linger", 300, 1500, 50,
                        () -> (float) SoundPrintConfig.LINGER_MS.get(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.LINGER_MS, Math.round(v)),
                        "%.0f ms"),
                new SliderControl("draginventory.soundprint.cfg.attack", 4f, 40f, 1f,
                        () -> SoundPrintConfig.ATTACK.get().floatValue(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.ATTACK, (double) Math.round(v)),
                        "%.0f"),
                new SliderControl("draginventory.soundprint.cfg.release", 1f, 20f, 0.5f,
                        () -> SoundPrintConfig.RELEASE.get().floatValue(),
                        v -> SoundPrintConfig.set(SoundPrintConfig.RELEASE, round2(v)),
                        "%.1f")));
        // 6 测试（模拟声源，v2.8.0：会话级状态，不落盘）
        tabs.add(List.of(
                new BoolControl("draginventory.soundprint.cfg.sim_enabled",
                        SoundPrintEvents.SIMULATOR::isEnabled,
                        v -> SoundPrintEvents.SIMULATOR.setEnabled(v)),
                new CyclerControl("draginventory.soundprint.cfg.sim_type",
                        List.of("footstep", "gunshot"),
                        () -> SoundPrintEvents.SIMULATOR.type() == SoundPrintType.GUNSHOT
                                ? "gunshot" : "footstep",
                        v -> SoundPrintEvents.SIMULATOR.setType(
                                "gunshot".equals(v) ? SoundPrintType.GUNSHOT : SoundPrintType.FOOTSTEP)),
                new SliderControl("draginventory.soundprint.cfg.sim_bearing", 0, 359, 5,
                        () -> SoundPrintEvents.SIMULATOR.bearing(),
                        v -> SoundPrintEvents.SIMULATOR.setBearing((float) Math.round(v)),
                        "%.0f\u00b0"),
                new SliderControl("draginventory.soundprint.cfg.sim_distance", 2, 20, 1,
                        () -> SoundPrintEvents.SIMULATOR.distance(),
                        v -> SoundPrintEvents.SIMULATOR.setDistance((float) Math.round(v)),
                        "%.0f m"),
                new CyclerControl("draginventory.soundprint.cfg.sim_mode",
                        List.of("static", "orbit", "random"),
                        () -> SoundPrintEvents.SIMULATOR.movement().name().toLowerCase(Locale.ROOT),
                        v -> SoundPrintEvents.SIMULATOR.setMovement(
                                SoundPrintSimulator.Movement.valueOf(v.toUpperCase(Locale.ROOT))))));
    }

    private static double round2(double v) {
        return Math.round(v * 100) / 100.0;
    }

    // ==================== 颜色循环器（默认 / 白 / 红 / 金 / 青 固定档位） ====================

    private static final List<String> COLOR_KEYS = List.of("default", "white", "red", "gold", "cyan");
    private static final List<Integer> COLOR_VALUES = List.of(
            -1, 0xF2F2F2, 0xFF5252, 0xF1C40F, 0x5EEAD4);

    private static List<String> colorOptions() {
        return COLOR_KEYS;
    }

    private static String colorOptionKey(int configured, int defaultRgb) {
        if (configured < 0) return "default";
        int i = COLOR_VALUES.indexOf(configured);
        return i > 0 ? COLOR_KEYS.get(i) : String.format(Locale.ROOT, "0x%06X", configured);
    }

    private static int colorValue(String key, int defaultRgb) {
        int i = COLOR_KEYS.indexOf(key);
        return i >= 0 ? COLOR_VALUES.get(i) : -1;
    }

    // ==================== 布局 ====================

    @Override
    protected void init() {
        panelW = Math.min(336, this.width - 8);
        int rows = 6;
        int idealH = 24 + 58 + 16 + ROW_H * rows + 16 + 22;
        panelH = Math.min(idealH, this.height - 8);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;

        previewBoxY = panelY + 26;
        previewBoxH = 52;
        tabBarY = previewBoxY + previewBoxH + 4;
        contentY = tabBarY + 18;
        footerY = panelY + panelH - 18;
        contentH = footerY - contentY - 4;
        if (activeTab < tabScroll.length) {
            tabScroll[activeTab] = 0;
        }
    }

    // ==================== 渲染 ====================

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.mouseX = mouseX;
        this.mouseY = mouseY;
        long now = System.currentTimeMillis();
        float closeT = closeProgress(now);

        g.pose().pushPose();
        try {
            if (closeT > 0f) {
                float s = 1f - 0.04f * closeT;
                g.pose().translate(panelX + panelW / 2f, panelY + panelH / 2f, 0);
                g.pose().scale(s, s, 1);
                g.pose().translate(-(panelX + panelW / 2f), -(panelY + panelH / 2f), 0);
            }
            super.render(g, mouseX, mouseY, partialTick);
            renderPanel(g, now, closeT);
        } finally {
            g.pose().popPose();
        }

        if (closeT >= 1f) {
            forceClose();
        }
    }

    private float closeProgress(long now) {
        if (closeStart == 0) return 0f;
        return Mth.clamp((now - closeStart) / 130f, 0f, 1f);
    }

    private float openProgress(long now) {
        float p = (now - openTime) / 130f;
        return Mth.clamp(p, 0f, 1f);
    }

    private void renderPanel(GuiGraphics g, long now, float closeT) {
        MenuTheme t = theme();
        float open = openProgress(now);
        int alpha = Math.round((closeT > 0f ? 1f - closeT : open) * 255);

        pixelRect(g, panelX, panelY, panelW, panelH, withAlpha(t.panelBg(), alpha),
                withAlpha(t.panelBorder(), alpha));
        g.fill(panelX + 2, panelY + 2, panelX + panelW - 2, panelY + panelH - 2,
                withAlpha(t.panelInner(), alpha));

        // 标题 + 副标题
        String title = Component.translatable("draginventory.soundprint.title").getString();
        String sub = "SOUNDPRINT";
        g.drawString(font, title, panelX + PAD, panelY + 6, withAlpha(TITLE_TEXT, alpha), false);
        int subW = font.width(sub);
        g.drawString(font, sub, panelX + panelW - PAD - subW, panelY + 8,
                withAlpha(t.accent(), alpha), false);
        g.fill(panelX + PAD, panelY + 22, panelX + panelW - PAD, panelY + 23,
                withAlpha(t.panelBorder(), alpha));

        // 预览盒
        renderPreviewBox(g, now, alpha);
        // 页签
        renderTabBar(g, alpha);
        // 内容
        renderContent(g, alpha);
        // 页脚
        renderFooter(g, alpha);
    }

    private void renderPreviewBox(GuiGraphics g, long now, int alpha) {
        MenuTheme t = theme();
        int x = panelX + PAD;
        int w = panelW - PAD * 2;
        g.fill(x, previewBoxY, x + w, previewBoxY + previewBoxH, withAlpha(0xF6101518, alpha));
        g.fill(x, previewBoxY, x + 1, previewBoxY + previewBoxH, withAlpha(t.panelBorder(), alpha));
        g.fill(x + w - 1, previewBoxY, x + w, previewBoxY + previewBoxH, withAlpha(t.panelBorder(), alpha));
        g.fill(x, previewBoxY, x + w, previewBoxY + 1, withAlpha(t.panelBorder(), alpha));
        g.fill(x, previewBoxY + previewBoxH - 1, x + w, previewBoxY + previewBoxH,
                withAlpha(t.panelBorder(), alpha));

        // 预览绘制：声纹带等比缩进预览盒（宽 = 盒宽 - 16，声纹基准线在盒内上部 1/3 处）。
        float px = x + 8;
        float pw = w - 16;
        float py = previewBoxY + 10;
        preview.setSway(swayOn);
        // v2.8.0：renderStandalone 改绝对坐标（与 HUD 同路径），显式传基准线 Y。
        preview.renderStandalone(g, px, py, pw, now, previewScale(px, pw));

        // 摆动开关（右上角小标）
        String sway = "SWAY";
        int sw = font.width(sway);
        int sx = x + w - sw - 8;
        int sy = previewBoxY + 3;
        boolean swayHot = mouseX >= sx && mouseX < sx + sw + 6 && mouseY >= sy - 2 && mouseY < sy + 10;
        if (swayHot) {
            g.fill(sx - 4, sy - 2, sx + sw + 4, sy + 10, withAlpha(ROW_HOVER, alpha));
        }
        g.drawString(font, sway, sx, sy,
                swayOn ? 0xFFFFFFFF : withAlpha(VALUE_TEXT, alpha), false);
    }

    private float previewScale(float px, float pw) {
        // 等效缩放：把配置 scale 与“预览盒相对方位条条带宽”的收缩合并，
        // 避免大缩放溢出预览盒（对齐 CompassSettingsScreen 的 previewScale 思路）。
        float compassWidth = CompassConfig.BAR_WIDTH.get();
        float fit = Math.min(1f, pw / Math.max(1f, compassWidth));
        return (float) SoundPrintConfig.SCALE.get().doubleValue() * fit;
    }

    private void renderTabBar(GuiGraphics g, int alpha) {
        MenuTheme t = theme();
        String[] names = {"general", "detect", "multi", "shape", "motion", "sim"};
        int x = panelX + PAD;
        for (int i = 0; i < names.length && i < tabs.size(); i++) {
            String label = Component.translatable(
                    "draginventory.soundprint.tab." + names[i]).getString();
            int w = font.width(label) + 10;
            boolean active = i == activeTab;
            if (active) {
                g.fill(x, tabBarY, x + w, tabBarY + 15, withAlpha(t.panelBorder(), alpha));
                g.fill(x + 1, tabBarY + 1, x + w - 1, tabBarY + 14, withAlpha(t.panelInner(), alpha));
            }
            g.drawString(font, label, x + 5, tabBarY + 4,
                    active ? withAlpha(t.accentBright(), alpha) : withAlpha(VALUE_TEXT, alpha), false);
            x += w + 2;
        }
    }

    private void renderContent(GuiGraphics g, int alpha) {
        MenuTheme t = theme();
        List<Control> tab = tabs.get(activeTab);
        int clipTop = contentY;
        int clipBottom = contentY + contentH;
        int y = clipTop - tabScroll[activeTab];
        // 面板裁剪：内容超出内容区时用 scissor（fill 直接判区间也可以，但文本需要裁）。
        for (int i = 0; i < tab.size(); i++) {
            Control control = tab.get(i);
            if (y + control.height() < clipTop || y > clipBottom) {
                y += control.height() + 1;
                continue;
            }
            boolean hot = !dragging()
                    && mouseX >= panelX + PAD && mouseX < panelX + panelW - PAD
                    && mouseY >= y && mouseY < y + control.height();
            renderControl(g, control, panelX + PAD, y, panelW - PAD * 2, hot, alpha, t);
            y += control.height() + 1;
        }
    }

    private boolean dragging() {
        return draggingSlider != null;
    }

    private void renderControl(GuiGraphics g, Control control, int x, int y, int w,
                               boolean hot, int alpha, MenuTheme t) {
        String label = Component.translatable(control.labelKey()).getString();
        if (hot) {
            g.fill(x, y, x + w, y + control.height(), withAlpha(ROW_HOVER, alpha));
        }
        g.drawString(font, label, x, y + 5, withAlpha(LABEL_TEXT, alpha), false);
        int cw = Math.min(132, w / 2);
        int cx = x + w - cw;
        if (control instanceof BoolControl c) {
            renderToggle(g, cx, y, cw, c.get.get(), hot, alpha);
        } else if (control instanceof SliderControl c) {
            renderSlider(g, cx, y, cw, c, alpha);
        } else if (control instanceof CyclerControl c) {
            renderCycler(g, cx, y, cw, c, hot, alpha);
        } else if (control instanceof ButtonControl c) {
            renderSmallButton(g, cx, y, cw, Component.translatable(c.labelKey()).getString(),
                    hot, alpha, t, c.action());
        }
    }

    private void renderToggle(GuiGraphics g, int x, int y, int w, boolean on,
                              boolean hot, int alpha) {
        int tx = x + w - 30;
        int ty = y + 3;
        g.fill(tx, ty, tx + 28, ty + 11, withAlpha(TRACK_EDGE, alpha));
        g.fill(tx + 1, ty + 1, tx + 27, ty + 10,
                withAlpha(on ? 0xFF2E7D32 : CONTROL_BG, alpha));
        if (hot) {
            g.fill(tx + 1, ty + 1, tx + 27, ty + 10, withAlpha(CONTROL_BG_HOVER, alpha));
        }
        int kx = on ? tx + 18 : tx + 3;
        g.fill(kx, ty + 2, kx + 8, ty + 9, on ? 0xFFFFFFFF : KNOB);
    }

    private void renderSlider(GuiGraphics g, int x, int y, int w, SliderControl c, int alpha) {
        int tx = x + 4;
        int tw = w - 8;
        int ty = y + 7;
        g.fill(tx, ty, tx + tw, ty + 4, withAlpha(TRACK_EDGE, alpha));
        float frac = c.fraction();
        g.fill(tx, ty, tx + Math.round(tw * frac), ty + 4,
                withAlpha(theme().accent(), alpha));
        int kx = tx + Math.round((tw - 6) * frac);
        int ky = ty - 2;
        g.fill(kx, ky, kx + 6, ky + 8, KNOB);
        g.fill(kx, ky, kx + 6, ky + 1, 0xFFFFFFFF);
        // 值文本（标签右侧、轨道左上方）
        String value = String.format(Locale.ROOT, c.fmt(), (Object) c.get.get());
        int vw = font.width(value);
        g.drawString(font, value, x + w - vw - 4, y + 4, withAlpha(VALUE_TEXT, alpha), false);
        // 避免值与轨道重叠：值画在轨道行上方右侧，标签左，二者错开。
    }

    private void renderCycler(GuiGraphics g, int x, int y, int w, CyclerControl c,
                              boolean hot, int alpha) {
        String value = c.current();
        int vw = font.width(value) + 12;
        int cx = x + w - vw - 4;
        int cy = y + 2;
        g.fill(cx, cy, cx + vw, cy + 12, withAlpha(hot ? CONTROL_BG_HOVER : CONTROL_BG, alpha));
        g.fill(cx, cy, cx + vw, cy + 1, withAlpha(TRACK_EDGE, alpha));
        g.drawString(font, value, cx + 6, cy + 2, withAlpha(LABEL_TEXT, alpha), false);
        // 前后尖括号提示可点击循环
        g.drawString(font, "<", cx, cy + 2, withAlpha(VALUE_TEXT, alpha), false);
        g.drawString(font, ">", cx + vw - 5, cy + 2, withAlpha(VALUE_TEXT, alpha), false);
    }

    private void renderSmallButton(GuiGraphics g, int x, int y, int w, String label,
                                   boolean hot, int alpha, MenuTheme t, Runnable action) {
        int bh = 12;
        g.fill(x, y + 2, x + w, y + 2 + bh, withAlpha(hot ? CONTROL_BG_HOVER : CONTROL_BG, alpha));
        g.fill(x, y + 2, x + w, y + 3, withAlpha(TRACK_EDGE, alpha));
        int lw = font.width(label);
        g.drawString(font, label, x + (w - lw) / 2, y + 5, withAlpha(LABEL_TEXT, alpha), false);
    }

    private void renderFooter(GuiGraphics g, int alpha) {
        MenuTheme t = theme();
        String reset = Component.translatable("draginventory.soundprint.cfg.reset").getString();
        int rw = font.width(reset) + 12;
        int rx = panelX + PAD;
        boolean rHot = !dragging() && mouseX >= rx && mouseX < rx + rw
                && mouseY >= footerY && mouseY < footerY + 13;
        g.fill(rx, footerY, rx + rw, footerY + 13,
                withAlpha(rHot ? 0xFF46393C : CONTROL_BG, alpha));
        g.drawString(font, reset, rx + 6, footerY + 3,
                rHot ? 0xFFE08585 : withAlpha(VALUE_TEXT, alpha), false);

        String done = Component.translatable("draginventory.soundprint.cfg.done").getString();
        int dw = font.width(done) + 14;
        int dx = panelX + panelW - PAD - dw;
        boolean dHot = !dragging() && mouseX >= dx && mouseX < dx + dw
                && mouseY >= footerY && mouseY < footerY + 13;
        g.fill(dx, footerY, dx + dw, footerY + 13, withAlpha(t.accent(), alpha));
        g.drawString(font, done, dx + 7, footerY + 3, 0xFF14181D, false);
        doneHot = dHot;
        resetHot = rHot;
        resetRectX = rx;
        resetRectW = rw;
    }

    private boolean doneHot;
    private boolean resetHot;
    private int resetRectX;
    private int resetRectW;

    // ==================== 交互 ====================

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (closeStart != 0) return true;
        int x = (int) mx;
        int y = (int) my;

        // 页脚按钮
        if (y >= footerY && y < footerY + 13) {
            if (doneHot) {
                onClose();
                return true;
            }
            if (resetHot) {
                SoundPrintConfig.resetToDefaults();
                return true;
            }
        }
        // 摆动开关
        {
            int bx = panelX + panelW - PAD - 8 - font.width("SWAY");
            if (x >= bx - 4 && x < bx + font.width("SWAY") + 4
                    && y >= previewBoxY + 1 && y < previewBoxY + 13) {
                swayOn = !swayOn;
                preview.setSway(swayOn);
                return true;
            }
        }
        // 页签
        {
            String[] names = {"general", "detect", "multi", "shape", "motion", "sim"};
            int tx = panelX + PAD;
            for (int i = 0; i < names.length && i < tabs.size(); i++) {
                int w = font.width(Component.translatable(
                        "draginventory.soundprint.tab." + names[i]).getString()) + 10;
                if (x >= tx && x < tx + w && y >= tabBarY && y < tabBarY + 15) {
                    activeTab = i;
                    return true;
                }
                tx += w + 2;
            }
        }
        // 内容行
        if (x >= panelX + PAD && x < panelX + panelW - PAD
                && y >= contentY && y < contentY + contentH) {
            List<Control> tab = tabs.get(activeTab);
            int cy = contentY - tabScroll[activeTab];
            for (Control control : tab) {
                if (y >= cy && y < cy + control.height()) {
                    int w = panelW - PAD * 2;
                    int cw = Math.min(132, w / 2);
                    int cx = panelX + PAD + w - cw;
                    if (control instanceof BoolControl c) {
                        c.set.accept(!c.get.get());
                    } else if (control instanceof CyclerControl c) {
                        c.next();
                    } else if (control instanceof SliderControl c) {
                        draggingSlider = c;
                        dragSliderTo(x, cx, cw);
                    } else if (control instanceof ButtonControl c) {
                        c.action().run();
                    }
                    return true;
                }
                cy += control.height() + 1;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dragX, double dragY) {
        if (draggingSlider != null) {
            int w = panelW - PAD * 2;
            int cw = Math.min(132, w / 2);
            int cx = panelX + PAD + w - cw;
            dragSliderTo((int) mx, cx, cw);
            return true;
        }
        return super.mouseDragged(mx, my, button, dragX, dragY);
    }

    private void dragSliderTo(int mouseX, int cx, int cw) {
        SliderControl c = draggingSlider;
        float frac = Mth.clamp((mouseX - cx - 4) / (float) Math.max(1, cw - 8), 0f, 1f);
        float raw = c.min + frac * (c.max - c.min);
        float stepped = Math.round(raw / c.step) * c.step;
        c.set.accept(Mth.clamp(stepped, c.min, c.max));
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        draggingSlider = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (mx >= panelX && mx < panelX + panelW && my >= contentY && my < contentY + contentH) {
            int max = Math.max(0, contentHeight(tabs.get(activeTab)) - contentH);
            tabScroll[activeTab] = (int) Mth.clamp(
                    tabScroll[activeTab] - (float) scrollY * 18, 0, max);
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    private int contentHeight(List<Control> tab) {
        int h = 0;
        for (Control control : tab) {
            h += control.height() + 1;
        }
        return Math.max(0, h - 1);
    }

    // ==================== 绘制原语 ====================

    private static void pixelRect(GuiGraphics g, int x, int y, int w, int h,
                                  int fill, int border) {
        g.fill(x, y, x + w, y + h, border);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
    }

    private static int withAlpha(int color, int alpha) {
        if (alpha >= 255) return color;
        if (alpha <= 0) return 0;
        int a = (color >>> 24) * alpha / 255;
        return (a << 24) | (color & 0xFFFFFF);
    }
}
