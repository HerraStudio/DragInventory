package dev.draginventory.client.soundprint;

import com.lowdragmc.lowdraglib2.gui.ui.UIElement;
import com.lowdragmc.lowdraglib2.gui.ui.rendering.GUIContext;
import dev.draginventory.client.compass.CompassConfig;
import dev.draginventory.client.compass.CompassHeading;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

/**
 * 声纹控件：LDLib2 UIElement 子类，绘制方位条正下方的声纹带。
 *
 * <p>与方位条的协同全部为<b>只读</b>（零修改 compass 包）：
 * <ul>
 *   <li>朝向弹簧：自建 {@link CompassHeading} 实例，喂与 {@code CompassWidget}
 *       相同的目标源（玩家视角插值 yaw）与刚度（{@code CompassConfig.SMOOTHNESS}）——
 *       同算法同输入序列，两实例输出一致（初值差按临界阻尼指数收敛），声纹与
 *       方位条刻度逐像素同步滑动，无 {@code getSmoothHeading} 取整值的 1 度阶梯。</li>
 *   <li>水平映射：与 {@code CompassStyleContext.degreesToX} 同式
 *       （{@code centerX + wrapDegrees(bearing-heading)/halfRange*(width/2-6)}），
 *       视野角度读 {@code CompassConfig.RANGE}，声源与刻度同角度对位。</li>
 *   <li>显隐：复刻方位条可见性判定（{@code ENABLED} / F3 / 旁观 / hideGui），
 *       {@code FOLLOW_COMPASS} 开启时方位条隐藏即声纹隐藏。</li>
 *   <li>布局宽度 / 水平偏移：读 {@code CompassConfig.BAR_WIDTH / OFFSET_X}
 *       （由 {@link SoundPrintHud} 完成），声纹水平定位与方位条永远一体。</li>
 * </ul></p>
 *
 * <p>同一控件同时服务 HUD 与设置界面预览（预览模式使用合成演示声源，
 * 不读真实追踪器）。</p>
 */
public final class SoundPrintWidget extends UIElement {

    /** HUD 实例的自有朝向弹簧（与方位条 LIVE 同参数同输入，见类注释）。 */
    private final CompassHeading heading = CompassHeading.create();

    /** 预览模式（设置界面）：合成演示声源 + 自动摆动。 */
    private final boolean preview;
    private float previewHeadingTarget = 30f;
    private float previewBase = 30f;
    private boolean sway = true;

    // ==================== 帧状态 ====================
    private boolean wasVisible;
    private long entryStart = Long.MIN_VALUE;
    private long lastFrameMillis = Long.MIN_VALUE;
    private Player displayedPlayer;
    private boolean frameVisible;
    private float entryProgress = 1f;
    private float frameHeading;
    private float halfRange;
    private float edgeHalfWidth;
    private List<SoundPrintCluster> clusters = List.of();
    private float effectiveScale = 1f;

    public SoundPrintWidget(boolean preview) {
        this.preview = preview;
    }

    // ==================== 预览控制（设置界面） ====================

    /** 预览自动摆动开关。 */
    public void setSway(boolean sway) {
        this.sway = sway;
        this.previewBase = previewHeadingTarget;
    }

    // ==================== 状态更新 ====================

    private void updateState(GUIContext context) {
        Minecraft mc = Minecraft.getInstance();
        long now = System.currentTimeMillis();
        float seconds = secondsSinceLastFrame(now);

        boolean visible = computeVisible(mc);
        if (visible && !wasVisible) {
            entryStart = now;
        }
        wasVisible = visible;
        frameVisible = visible;
        if (!visible) {
            clusters = List.of();
            return;
        }
        entryProgress = entryProgress(now);

        float target;
        if (preview) {
            if (sway) {
                previewHeadingTarget = Mth.wrapDegrees(previewBase + 26f * (float) Math.sin(now / 3600.0));
                if (previewHeadingTarget < 0) previewHeadingTarget += 360f;
            }
            target = previewHeadingTarget;
        } else {
            Player player = mc.player;
            if (player == null) {
                clusters = List.of();
                return;
            }
            if (displayedPlayer != player) {
                displayedPlayer = player;
                heading.snapTo(CompassHeading.toHeading(player.getYRot()));
            }
            target = CompassHeading.toHeading(player.getViewYRot(context.partialTick));
        }
        // 与方位条同刚度（SMOOTHNESS）；无吸附语义，snapRange = 0。
        heading.step(target, seconds, (float) CompassConfig.SMOOTHNESS.get().doubleValue(), 0f);

        frameHeading = heading.smooth();
        halfRange = CompassConfig.RANGE.get() / 2f;
        // 屏外渐隐窗口：视野半角 + 8 度内淡出，之外不画（声源滑出视野自然消失）。
        edgeHalfWidth = halfRange + 8f;

        List<SoundPrintAggregator.Hit> hits;
        if (preview) {
            hits = previewHits();
        } else {
            LocalPlayer player = mc.player;
            var eye = player.getEyePosition(context.partialTick);
            hits = SoundPrintEvents.TRACKER.frameHits(
                    eye.x, eye.y, eye.z, SoundPrintConfig.VERTICAL_OFFSET.get());
        }
        clusters = SoundPrintAggregator.aggregate(
                hits,
                SoundPrintConfig.staggerMode(),
                SoundPrintConfig.MERGE_WINDOW.get(),
                SoundPrintConfig.STAGGER_SPACING.get());
        effectiveScale = (float) SoundPrintConfig.SCALE.get().doubleValue();
    }

    private float secondsSinceLastFrame(long now) {
        if (lastFrameMillis == Long.MIN_VALUE) {
            lastFrameMillis = now;
            return 0.016f;
        }
        float seconds = (now - lastFrameMillis) / 1000f;
        lastFrameMillis = now;
        return Mth.clamp(seconds, 0f, 0.1f);
    }

    private float entryProgress(long now) {
        if (entryStart == Long.MIN_VALUE) return 1f;
        float p = (now - entryStart) / 180f;
        if (p >= 1f) {
            entryStart = Long.MIN_VALUE;
            return 1f;
        }
        return 1f - (1f - p) * (1f - p); // ease-out
    }

    /** 可见性：声纹自身开关 + 复刻方位条判定（FOLLOW_COMPASS 时跟随其结果）。 */
    private boolean computeVisible(Minecraft mc) {
        if (preview) return true;
        if (!SoundPrintConfig.ENABLED.get()) return false;
        if (mc.options.hideGui || mc.level == null) return false;
        if (!(mc.getCameraEntity() instanceof Player camera) || camera.isSpectator()) return false;
        if (SoundPrintConfig.FOLLOW_COMPASS.get()) {
            boolean debugOpen = isDebugScreenOpen(mc);
            boolean compassVisible = CompassConfig.ENABLED.get()
                    && !(CompassConfig.HIDE_WITH_DEBUG.get() && debugOpen);
            return compassVisible;
        }
        return true;
    }

    private static boolean isDebugScreenOpen(Minecraft mc) {
        try {
            return mc.gui.getDebugOverlay().showDebugScreen();
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    // ==================== 绘制 ====================

    @Override
    public void drawBackgroundTexture(GUIContext context) {
        if (preview) return; // 预览实例仅经 renderStandalone 绘制
        updateState(context);
    }

    @Override
    public void drawBackgroundAdditional(GUIContext context) {
        if (preview) return;
        if (!frameVisible || clusters.isEmpty()) return;
        GuiGraphics g = context.graphics;
        float width = getSizeWidth();
        float centerX = getPositionX() + width / 2f;
        // v2.8.0 位置修复：LDLib2 绘制链是绝对屏幕坐标（无控件局部平移），
        // 基准线必须用 getPositionY()，旧版局部 0.5f 会把声纹画到屏幕顶端
        // 与方位条重合（用户实测反馈的重合缺陷根因）。
        g.pose().pushPose();
        try {
            applyScale(g, centerX);
            drawSoundprint(g, getPositionX(), getPositionY() + 0.5f, width, centerX);
        } finally {
            g.pose().popPose();
        }
    }

    /**
     * 独立渲染（设置界面预览）：与 HUD 同一绘制路径（绝对坐标），仅状态源不同。
     *
     * @param y 基准线的绝对屏幕 Y（v2.8.0：显式传入，不再依赖调用方平移 pose）
     */
    void renderStandalone(GuiGraphics g, float x, float y, float width, long now, float scaleOverride) {
        float seconds = lastFrameMillis == Long.MIN_VALUE ? 0.016f
                : Mth.clamp((now - lastFrameMillis) / 1000f, 0f, 0.1f);
        lastFrameMillis = now;
        if (sway) {
            previewHeadingTarget = Mth.wrapDegrees(previewBase + 26f * (float) Math.sin(now / 3600.0));
            if (previewHeadingTarget < 0) previewHeadingTarget += 360f;
        }
        heading.step(previewHeadingTarget, seconds, 15f, 0f);
        frameHeading = heading.smooth();
        halfRange = CompassConfig.RANGE.get() / 2f;
        edgeHalfWidth = halfRange + 8f;
        clusters = SoundPrintAggregator.aggregate(previewHits(),
                SoundPrintConfig.staggerMode(),
                SoundPrintConfig.MERGE_WINDOW.get(),
                SoundPrintConfig.STAGGER_SPACING.get());
        entryProgress = 1f;
        effectiveScale = scaleOverride;
        if (clusters.isEmpty()) return;
        g.pose().pushPose();
        try {
            applyScale(g, x + width / 2f);
            drawSoundprint(g, x, y + 0.5f, width, x + width / 2f);
        } finally {
            g.pose().popPose();
        }
    }

    private void applyScale(GuiGraphics g, float centerX) {
        float scale = effectiveScale;
        if (Math.abs(scale - 1f) < 0.01f) return;
        g.pose().translate(centerX, 0, 0);
        g.pose().scale(scale, scale, 1);
        g.pose().translate(-centerX, 0, 0);
    }

    /**
     * 声纹主体绘制：基准线 + 簇循环（HUD 与预览共用）。
     *
     * @param y   基准线的绝对屏幕 Y（HUD = 控件顶边，预览 = 调用方指定）
     */
    private void drawSoundprint(GuiGraphics g, float x, float y, float width, float centerX) {
        float opacity = (float) SoundPrintConfig.OPACITY.get().doubleValue();
        float alpha = opacity * entryProgress;
        if (alpha <= 0.01f) return;

        // 入场浮入：从上方 3px 轻落（独立设计，不触碰方位条入场）。
        float entryOffsetY = (1f - entryProgress) * -3f;

        // 基准线（绝对屏幕坐标，见 drawBackgroundAdditional 的 v2.8.0 注释）。
        float baselineY = y + entryOffsetY;
        if (SoundPrintConfig.BASELINE.get()) {
            fillH(g, x + 2f, x + width - 2f, baselineY, 1f, 0xE8E8E8, alpha * 0.5f);
        }

        int barCount = SoundPrintConfig.BAR_COUNT.get();
        float barWidth = SoundPrintConfig.BAR_WIDTH.get();
        float barGap = SoundPrintConfig.BAR_GAP.get();
        float maxHeight = SoundPrintConfig.MAX_HEIGHT.get();

        for (SoundPrintCluster cluster : clusters) {
            if (cluster.stagger()) {
                for (SoundPrintCluster.Member member : cluster.members()) {
                    drawCluster(g, width, centerX, member.bearing(), member.energy(), member.type(),
                            member.verticalOffset(), member.distance(), 1, alpha,
                            barCount, barWidth, barGap, maxHeight, baselineY,
                            member.staggerOffset(), 0.82f);
                }
            } else {
                drawCluster(g, width, centerX, cluster.bearing(), cluster.energy(), cluster.type(),
                        cluster.verticalOffset(), cluster.nearestDistance(), cluster.sourceCount(), alpha,
                        barCount, barWidth, barGap, maxHeight, baselineY, 0f, 1f);
            }
        }
    }

    /**
     * 绘制一个（合成或独立的）声纹簇。
     *
     * @param sourceCount    参与声源数（merge 簇 >= 2 时整体提亮一档）
     * @param staggerOffset  并排错位偏移（px）
     * @param sizeScale      尺寸系数（stagger 成员 0.82，避免错位后相邻簇粘连）
     */
    private void drawCluster(GuiGraphics g, float width, float centerX, float bearing, float energy,
                             SoundPrintType type, float verticalOffset, float distance,
                             int sourceCount, float alpha,
                             int barCount, float barWidth, float barGap, float maxHeight,
                             float baselineY, float staggerOffset, float sizeScale) {
        float diff = CompassHeading.wrapDegrees(bearing - frameHeading);
        if (Math.abs(diff) > edgeHalfWidth) return; // 视野外：不画
        float x = centerX + diff / halfRange * (width / 2f - 6f) + staggerOffset;

        // 边缘渐隐（视野边界柔和消失，对齐方位条 edgeFade 语义）。
        float edgeFade = 1f - SoundPrintEnvelope.smoothstep(
                Mth.clamp((Math.abs(diff) - halfRange * 0.7f) / (edgeHalfWidth - halfRange * 0.7f), 0f, 1f));

        // 形态参数。
        float clusterAlpha = alpha * edgeFade * (0.4f + 0.6f * energy);
        if (sourceCount >= 2) clusterAlpha = Math.min(1f, clusterAlpha * 1.12f);
        if (clusterAlpha <= 0.015f) return;
        float heightBase = maxHeight * type.heightBoost() * sizeScale * (0.4f + 0.6f * energy);
        // 枪声更密实：条宽 +1、间隙 -1（clamp 不塌）。
        float bw = barWidth + (type == SoundPrintType.GUNSHOT ? 1f : 0f);
        float gap = Math.max(0f, barGap - (type == SoundPrintType.GUNSHOT ? 1f : 0f));
        int rgb = resolveColor(type);

        float[] asym = SoundPrintEnvelope.asymmetryFactors(verticalOffset);
        float totalW = barCount * (bw + gap) - gap;
        float left = x - totalW / 2f;

        for (int i = 0; i < barCount; i++) {
            float bell = SoundPrintEnvelope.bell(i, barCount);
            if (bell < 0.06f) continue; // 钟形尾部低于可见阈值：整条省略（紧凑声源退化为中柱）
            float barAlpha = clusterAlpha * (0.45f + 0.55f * bell);
            float bx = left + i * (bw + gap);
            float hUp = heightBase * bell * asym[0];
            float hDown = heightBase * bell * asym[1];
            if (hUp >= 1f) {
                fillV(g, bx, bw, baselineY - hUp, hUp, rgb, barAlpha);
            }
            if (hDown >= 1f) {
                fillV(g, bx, bw, baselineY + 1.5f, hDown, rgb, barAlpha);
            }
        }

        // 无杆 V 形箭头：明确的上 / 下偏移才出现（水平声源无箭头，参考图 1/2）。
        if (SoundPrintConfig.ARROWS.get()) {
            float strength = SoundPrintEnvelope.arrowStrength(verticalOffset) * energy;
            if (strength > 0.05f) {
                float arrowAlpha = clusterAlpha * strength * 0.95f;
                if (arrowAlpha > 0.02f) {
                    float reach = heightBase * 0.92f + 3.5f;
                    float halfW = 2.2f + 0.8f * strength;
                    if (verticalOffset > 0) {
                        // 上方声源：箭头在声纹顶上、尖朝上。
                        drawVArrow(g, x, baselineY - reach - 2f, halfW, 3.6f, rgb, arrowAlpha, true);
                    } else {
                        // 下方声源：箭头在声纹底下、尖朝下（参考图 2）。
                        drawVArrow(g, x, baselineY + reach + 3.5f, halfW, 3.6f, rgb, arrowAlpha, false);
                    }
                }
            }
        }
    }

    private static int resolveColor(SoundPrintType type) {
        int override = type == SoundPrintType.GUNSHOT
                ? SoundPrintConfig.COLOR_GUNSHOT.get()
                : SoundPrintConfig.COLOR_FOOTSTEP.get();
        return override >= 0 ? override : type.defaultRgb();
    }

    // ==================== 绘制原语（像素战术风，对齐 CompassStyleContext 手法） ====================

    private static int rgba(int rgb, float alpha) {
        return (Math.round(Mth.clamp(alpha, 0f, 1f) * 255f) << 24) | (rgb & 0xFFFFFF);
    }

    /** 竖条：主体 + 顶 / 底 0.5px 微光（模拟发光边，与方位条 hline 柔边同语言）。 */
    private static void fillV(GuiGraphics g, float x, float w, float y, float h,
                              int rgb, float alpha) {
        int c = rgba(rgb, alpha);
        g.fill(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), c);
        int halo = rgba(rgb, alpha * 0.25f);
        if (halo != 0 && alpha > 0.15f) {
            g.fill(Math.round(x), Math.round(y - 0.5f), Math.round(x + w), Math.round(y), halo);
            g.fill(Math.round(x), Math.round(y + h), Math.round(x + w), Math.round(y + h + 0.5f), halo);
        }
    }

    /** 水平基准线（带微光）。 */
    private static void fillH(GuiGraphics g, float x1, float x2, float y, float h,
                              int rgb, float alpha) {
        int c = rgba(rgb, alpha);
        g.fill(Math.round(x1), Math.round(y), Math.round(x2), Math.round(y + h), c);
        if (alpha > 0.15f) {
            int halo = rgba(rgb, alpha * 0.22f);
            g.fill(Math.round(x1), Math.round(y - 0.5f), Math.round(x2), Math.round(y), halo);
            g.fill(Math.round(x1), Math.round(y + h), Math.round(x2), Math.round(y + h + 0.5f), halo);
        }
    }

    /**
     * 无杆 V 形箭头（两段斜臂行填充，同 CompassPaint.chevron 的像素语言）。
     *
     * @param cy     箭头几何中心行
     * @param halfW  半宽
     * @param h      半高（臂长）
     * @param up     true = 尖朝上；false = 尖朝下（参考图 2）
     */
    private static void drawVArrow(GuiGraphics g, float cx, float cy, float halfW, float h,
                                   int rgb, float alpha, boolean up) {
        int c = rgba(rgb, alpha);
        int rows = Math.max(3, Math.round(h));
        // 尖在上：从顶行（两臂相距最远）向底部收拢到尖点；朝下镜像。
        for (int i = 0; i < rows; i++) {
            float t = (i + 0.5f) / rows;          // 0 = 臂根 -> 1 = 尖
            float spread = up ? (1f - t) : t;     // 尖侧 spread -> 0
            float armX = halfW * spread;
            float y = up ? cy - h + i : cy - h + i;
            int y1 = Math.round(y);
            int y2 = y1 + 1;
            g.fill(Math.round(cx - armX - 0.5f), y1, Math.round(cx - armX + 0.5f), y2, c);
            g.fill(Math.round(cx + armX - 0.5f), y1, Math.round(cx + armX + 0.5f), y2, c);
        }
    }

    // ==================== 预览合成数据 ====================

    /** 三个演示声源：近脚步（右前地面）/ 远脚步（左侧）/ 枪声（左前楼上，红 + 上箭头）。 */
    private List<SoundPrintAggregator.Hit> previewHits() {
        float h = previewHeadingTarget;
        return List.of(
                new SoundPrintAggregator.Hit(wrap360(h + 24f), 0.72f, SoundPrintType.FOOTSTEP, -0.55f, 6f),
                new SoundPrintAggregator.Hit(wrap360(h - 38f), 0.34f, SoundPrintType.FOOTSTEP, -0.2f, 17f),
                new SoundPrintAggregator.Hit(wrap360(h + 61f), 0.95f, SoundPrintType.GUNSHOT, 0.6f, 11f));
    }

    private static float wrap360(float v) {
        float r = v % 360f;
        return r < 0 ? r + 360f : r;
    }
}
