package dev.draginventory.client.soundprint;

import java.util.List;

/**
 * 聚合后的渲染簇：声纹 HUD 的绘制单元。
 *
 * <p>由 {@link SoundPrintAggregator} 从活跃声源生成。两种模式共用本结构：
 * <ul>
 *   <li><b>merge（默认，聚合合并）</b>：同方位声源合并为一簇——能量 RMS 合成、
 *       方位能量加权、枪声优先定色。渲染画一个更大更密的合成声纹。</li>
 *   <li><b>stagger（并排错位）</b>：同方位声源保持各自独立声纹，簇只提供
 *       共同中心 {@link #bearing}，成员经 {@link Member#staggerOffset} 横向错开
 *       排列（参考图 3：多独立小簇沿水平分布、簇间留隙）。</li>
 * </ul></p>
 *
 * @param bearing         簇中心方位（0..360，能量加权）
 * @param energy          簇能量 [0,1]（merge = RMS 合成；stagger = 成员最大值，用于整体透明度）
 * @param type            簇类型（簇内含枪声则 GUNSHOT——红色威胁优先）
 * @param verticalOffset  垂直偏移 [-1,1]（能量加权）
 * @param nearestDistance 最近声源距离（米，簇尺寸参考）
 * @param sourceCount     参与聚合的声源数（>= 1）
 * @param stagger         是否并排错位模式（决定渲染读簇整体还是成员）
 * @param members         stagger 模式下的成员列表（按能量降序）；merge 模式为空表
 */
public record SoundPrintCluster(
        float bearing,
        float energy,
        SoundPrintType type,
        float verticalOffset,
        float nearestDistance,
        int sourceCount,
        boolean stagger,
        List<Member> members) {

    /**
     * stagger 模式的独立成员：保有自己的方位 / 能量 / 类型 / 垂直偏移，
     * 相对簇中心的水平错位（像素，右正左负）。
     */
    public record Member(
            float bearing,
            float energy,
            SoundPrintType type,
            float verticalOffset,
            float distance,
            float staggerOffset) {}
}
