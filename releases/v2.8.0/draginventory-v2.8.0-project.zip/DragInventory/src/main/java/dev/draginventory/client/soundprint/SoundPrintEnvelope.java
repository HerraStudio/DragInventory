package dev.draginventory.client.soundprint;

/**
 * 声纹包络数学：把“簇能量 + 垂直偏移”翻译成参考图的视觉语言。
 *
 * <p>参考图（已像素级分析确认）的形态规则：
 * <ul>
 *   <li>基准线上下各一排竖条，高度呈钟形包络（中心最高向两侧递减），上下对称（图 1）</li>
 *   <li>声源在下方时：上排压成暗弱短条，下排增强为长条，整体呈向下收窄的楔形，
 *       底部一枚无杆 V 形箭头指向下（图 2）</li>
 *   <li>枪声同构但更高、更密实（图 4）</li>
 * </ul>
 * 本类只做数学（纯函数，全部单测覆盖），绘制在 {@code SoundPrintWidget}。</p>
 */
public final class SoundPrintEnvelope {

    private SoundPrintEnvelope() {}

    /**
     * 单侧（上排或下排）第 i 根竖条的钟形高度系数。
     *
     * <p>高斯钟形：exp(-((i - c) / sigma)^2)，中心条 = 1，向两侧平滑递减；
     * sigma = (n-1)/2 / 1.6 使边缘条落到 ~0.18——与参考图“中心高、两侧快速收矮”的观感一致，
     * 且 n 很小时（快速退化簇）不至于全部塌成 0。</p>
     *
     * @param i 条序号 [0, count)
     * @param count 条总数
     */
    public static float bell(int i, int count) {
        if (count <= 1) return 1f;
        float center = (count - 1) / 2f;
        float sigma = Math.max(0.8f, center / 1.6f);
        float d = (i - center) / sigma;
        return (float) Math.exp(-d * d);
    }

    /**
     * 垂直不对称系数：把“声源在玩家上方 / 下方”映射为上下两排的增强 / 压制。
     *
     * <p>{@code asymmetry} 为正代表声源在上方（上排增强下排压制），为负反之，
     * 绝对值越大越不对称。返回 [up, down]：
     * 增强侧 ≈ 1 + |a| * 0.75（上限 1.75 倍），压制侧 ≈ 1 - |a| * 0.72
     * （参考图 2 中下方声源的上排被压到约 0.2~0.3 倍、只剩暗弱短条）。</p>
     */
    public static float[] asymmetryFactors(float asymmetry) {
        float a = clamp(asymmetry, -1f, 1f);
        float up = 1f + Math.max(0f, a) * 0.75f - Math.max(0f, -a) * 0.72f;
        float down = 1f + Math.max(0f, -a) * 0.75f - Math.max(0f, a) * 0.72f;
        return new float[]{Math.max(0.12f, up), Math.max(0.12f, down)};
    }

    /**
     * 距离衰减系数：dist=0 -> 1，dist=radius -> minDecay（默认 0.2）。
     *
     * <p>平方根曲线而非线性：近距离增益快（脚步贴脸声纹很高、威胁感强），
     * 远处仍有可辨识的底线（20m 边缘不会瞬间消失，与“听得到就显示”一致）。</p>
     */
    public static float distanceDecay(float dist, float radius, float minDecay, boolean enabled) {
        if (!enabled) return 1f;
        if (radius <= 0.01f) return minDecay;
        float t = clamp(dist / radius, 0f, 1f);
        return 1f - (1f - minDecay) * (float) Math.sqrt(t);
    }

    /**
     * 垂直偏移归一化：声源与玩家眼睛的高度差 -> [-1, 1]。
     *
     * <p>±4 格（一层半楼）达到满偏转；超过线性 clamp。地面脚步通常在
     * 眼下 0.8~1.6 格 -> 轻度下偏（下排稍强 + 可选小箭头），楼上脚步满上偏。</p>
     */
    public static float verticalOffset(double sourceY, double eyeY, boolean enabled) {
        if (!enabled) return 0f;
        return clamp((float) ((sourceY - eyeY) / 4.0), -1f, 1f);
    }

    /**
     * 箭头偏移阈值下的箭头显示强度 [0,1]：
     * 偏移 < 0.22（几乎水平）不显示箭头；0.22~0.65 线性淡入；>= 0.65 全显。
     * 参考图 1（水平声源）无箭头、图 2（明确下方声源）箭头全显。
     */
    public static float arrowStrength(float verticalOffset) {
        float a = Math.abs(clamp(verticalOffset, -1f, 1f));
        if (a <= 0.22f) return 0f;
        if (a >= 0.65f) return 1f;
        return (a - 0.22f) / 0.43f;
    }

    /** 聚合能量的 RMS 合成：sqrt(e1^2 + e2^2)，上限 1。多声源同方位叠加响度按
     *  声学直觉（对数叠加近似），RMS 比求和温和、比 max 明显——两三个脚步
     *  合成一簇明显更高的声纹，但不会线性爆表。 */
    public static float mergeEnergy(float e1, float e2) {
        float merged = (float) Math.sqrt(e1 * e1 + e2 * e2);
        return Math.min(1f, merged);
    }

    /** 角度加权合成中心（圆周量）：能量加权向量平均，atan2 保证 359° 与 1° 合成 0°。 */
    public static float weightedBearing(float[] bearings, float[] energies) {
        float sin = 0f, cos = 0f;
        for (int i = 0; i < bearings.length; i++) {
            double rad = Math.toRadians(bearings[i]);
            sin += (float) Math.sin(rad) * energies[i];
            cos += (float) Math.cos(rad) * energies[i];
        }
        if (sin == 0f && cos == 0f) return 0f;
        float bearing = (float) Math.toDegrees(Math.atan2(sin, cos));
        return bearing < 0 ? bearing + 360f : bearing;
    }

    /** 平滑阶梯（与方位条同式）。 */
    static float smoothstep(float t) {
        t = clamp(t, 0f, 1f);
        return t * t * (3 - 2 * t);
    }

    static float clamp(float v, float min, float max) {
        return v < min ? min : Math.min(v, max);
    }
}
