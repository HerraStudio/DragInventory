package dev.draginventory.client.soundprint;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;

/**
 * 游戏内指令 /herrasoundprint（别名 /soundprint /sp）：
 * <ul>
 *   <li>不带参数：打开图形化设置界面</li>
 *   <li>toggle / on / off：开关</li>
 *   <li>radius：检测半径</li>
 *   <li>mode：多声源模式（merge 聚合合并 / stagger 并排错位）</li>
 *   <li>sim：模拟声源（v2.8.0 测试功能：on/off/type/bearing/distance/mode）</li>
 *   <li>reset：恢复默认</li>
 * </ul>
 * 全部客户端指令，无需权限。与统一入口 /herra 的关系：本指令树是声纹模块的
 * 直达入口；/herra 主指令经 HERRA 模块注册表转发到同一批操作。
 */
public final class SoundPrintCommands {

    private SoundPrintCommands() {}

    /** 由 {@code SoundPrintEvents} 在 RegisterClientCommandsEvent 时调用。 */
    public static List<LiteralArgumentBuilder<CommandSourceStack>> buildRoots() {
        List<LiteralArgumentBuilder<CommandSourceStack>> roots = new ArrayList<>(3);
        roots.add(build("herrasoundprint"));
        roots.add(build("soundprint"));
        roots.add(Commands.literal("sp").executes(ctx -> {
            openSettings();
            return 1;
        }));
        return roots;
    }

    private static LiteralArgumentBuilder<CommandSourceStack> build(String name) {
        return Commands.literal(name)
                .executes(ctx -> {
                    openSettings();
                    return 1;
                })
                .then(Commands.literal("toggle").executes(ctx -> {
                    boolean enabled = !SoundPrintConfig.ENABLED.get();
                    SoundPrintConfig.set(SoundPrintConfig.ENABLED, enabled);
                    feedback(ctx, enabled ? "draginventory.soundprint.cmd.enabled"
                            : "draginventory.soundprint.cmd.disabled");
                    return 1;
                }))
                .then(Commands.literal("on").executes(ctx -> setEnabled(ctx, true)))
                .then(Commands.literal("off").executes(ctx -> setEnabled(ctx, false)))
                .then(Commands.literal("gui").executes(ctx -> {
                    openSettings();
                    return 1;
                }))
                .then(Commands.literal("radius")
                        .then(Commands.argument("meters", IntegerArgumentType.integer(4, 64))
                                .executes(ctx -> {
                                    int v = IntegerArgumentType.getInteger(ctx, "meters");
                                    SoundPrintConfig.set(SoundPrintConfig.RADIUS, v);
                                    feedback(ctx, "draginventory.soundprint.cmd.radius",
                                            Component.literal(String.valueOf(v)));
                                    return 1;
                                })))
                .then(Commands.literal("mode")
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(
                                        List.of("merge", "stagger"), builder))
                                .executes(ctx -> {
                                    String id = StringArgumentType.getString(ctx, "id");
                                    if (!"merge".equals(id) && !"stagger".equals(id)) {
                                        ctx.getSource().sendFailure(Component.translatable(
                                                "draginventory.soundprint.cmd.unknown_mode",
                                                Component.literal(id)));
                                        return 0;
                                    }
                                    SoundPrintConfig.set(SoundPrintConfig.MODE, id);
                                    feedback(ctx, "draginventory.soundprint.cmd.mode",
                                            Component.literal(id));
                                    return 1;
                                })))
                .then(Commands.literal("reset").executes(ctx -> {
                    SoundPrintConfig.resetToDefaults();
                    feedback(ctx, "draginventory.soundprint.cmd.reset");
                    return 1;
                }))
                .then(buildSim());
    }

    // ==================== 模拟声源（v2.8.0 测试功能） ====================

    private static LiteralArgumentBuilder<CommandSourceStack> buildSim() {
        return Commands.literal("sim")
                .executes(ctx -> {
                    simStatus(ctx);
                    return 1;
                })
                .then(Commands.literal("on").executes(ctx -> {
                    SoundPrintEvents.SIMULATOR.setEnabled(true);
                    simStatus(ctx);
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    SoundPrintEvents.SIMULATOR.setEnabled(false);
                    simStatus(ctx);
                    return 1;
                }))
                .then(Commands.literal("toggle").executes(ctx -> {
                    SoundPrintEvents.SIMULATOR.setEnabled(!SoundPrintEvents.SIMULATOR.isEnabled());
                    simStatus(ctx);
                    return 1;
                }))
                .then(Commands.literal("type")
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(
                                        List.of("footstep", "gunshot"), builder))
                                .executes(ctx -> {
                                    String id = StringArgumentType.getString(ctx, "id");
                                    SoundPrintType type = "gunshot".equalsIgnoreCase(id)
                                            ? SoundPrintType.GUNSHOT : null;
                                    if (type == null && !"footstep".equalsIgnoreCase(id)) {
                                        ctx.getSource().sendFailure(Component.translatable(
                                                "draginventory.soundprint.cmd.sim.unknown_type",
                                                Component.literal(id)));
                                        return 0;
                                    }
                                    SoundPrintEvents.SIMULATOR.setType(type == null
                                            ? SoundPrintType.FOOTSTEP : type);
                                    simStatus(ctx);
                                    return 1;
                                })))
                .then(Commands.literal("bearing")
                        .then(Commands.argument("degrees", IntegerArgumentType.integer(0, 359))
                                .executes(ctx -> {
                                    int deg = IntegerArgumentType.getInteger(ctx, "degrees");
                                    SoundPrintEvents.SIMULATOR.setBearing(deg);
                                    simStatus(ctx);
                                    return 1;
                                })))
                .then(Commands.literal("distance")
                        .then(Commands.argument("meters", IntegerArgumentType.integer(2, 20))
                                .executes(ctx -> {
                                    int m = IntegerArgumentType.getInteger(ctx, "meters");
                                    SoundPrintEvents.SIMULATOR.setDistance(m);
                                    simStatus(ctx);
                                    return 1;
                                })))
                .then(Commands.literal("mode")
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(
                                        List.of("static", "orbit", "random"), builder))
                                .executes(ctx -> {
                                    String id = StringArgumentType.getString(ctx, "id");
                                    SoundPrintSimulator.Movement movement = parseMovement(id);
                                    if (movement == null) {
                                        ctx.getSource().sendFailure(Component.translatable(
                                                "draginventory.soundprint.cmd.sim.unknown_mode",
                                                Component.literal(id)));
                                        return 0;
                                    }
                                    SoundPrintEvents.SIMULATOR.setMovement(movement);
                                    simStatus(ctx);
                                    return 1;
                                })));
    }

    private static SoundPrintSimulator.Movement parseMovement(String id) {
        return switch (id.toLowerCase(Locale.ROOT)) {
            case "static" -> SoundPrintSimulator.Movement.STATIC;
            case "orbit" -> SoundPrintSimulator.Movement.ORBIT;
            case "random" -> SoundPrintSimulator.Movement.RANDOM;
            default -> null;
        };
    }

    /** 模拟器状态概览（一条消息带齐全部参数，改完即回显）。 */
    private static void simStatus(CommandContext<CommandSourceStack> ctx) {
        var sim = SoundPrintEvents.SIMULATOR;
        feedback(ctx, "draginventory.soundprint.cmd.sim.status",
                Component.literal(switch (sim.type()) {
                    case GUNSHOT -> "gunshot";
                    case FOOTSTEP -> "footstep";
                }),
                Component.literal(String.format(Locale.ROOT, "%.0f", sim.bearing())),
                Component.literal(String.format(Locale.ROOT, "%.0f", sim.distance())),
                Component.literal(sim.movement().name().toLowerCase(Locale.ROOT)),
                Component.literal(String.valueOf(sim.isEnabled())));
    }

    private static int setEnabled(CommandContext<CommandSourceStack> ctx, boolean enabled) {
        SoundPrintConfig.set(SoundPrintConfig.ENABLED, enabled);
        feedback(ctx, enabled ? "draginventory.soundprint.cmd.enabled"
                : "draginventory.soundprint.cmd.disabled");
        return 1;
    }

    private static void openSettings() {
        Minecraft.getInstance().tell(() ->
                Minecraft.getInstance().setScreen(SoundPrintSettingsScreen.create()));
    }

    private static void feedback(CommandContext<CommandSourceStack> ctx, String key, Object... args) {
        ctx.getSource().sendSuccess(() -> Component.translatable(key, args), false);
    }
}
