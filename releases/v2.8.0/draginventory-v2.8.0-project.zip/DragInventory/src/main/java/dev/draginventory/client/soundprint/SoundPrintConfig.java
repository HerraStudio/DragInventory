package dev.draginventory.client.soundprint;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * 声纹 HUD 的客户端配置（TOML 文件 draginventory-soundprint-client.toml）。
 *
 * <p>结构与写入纪律与 {@code CompassConfig} 完全一致：全部值注册进 {@link #ALL}
 * 供恢复默认与遍历校验；运行时修改走 {@link #set}（journal + 防抖 500ms 落盘，
 * 对抗 FML 监视线程的异步重载覆盖，见 CompassConfig 的类注释——两处共用同一对策）。
 * 声纹不改动 compass 包任何代码，协同所需的状态（方位条宽度 / 偏移 / 视野角度 /
 * 显隐）全部通过只读 {@code CompassConfig} 公开字段获得。</p>
 *
 * <p>多声源模式（v2.7.0 用户决策）：{@code mode = "merge"}（默认，聚合合并：
 * 同方位声源合成一簇更大的声纹，能量叠加）/ {@code "stagger"}（并排错位：
 * 同方位声源保持独立声纹，横向错开排列）。</p>
 */
public final class SoundPrintConfig {
    public static final ModConfigSpec SPEC;

    /** 用于“恢复默认”与遍历校验的全部值注册表。 */
    private static final List<ModConfigSpec.ConfigValue<?>> ALL = new ArrayList<>();

    /** 关键字表缓存：原始字符串变化时才重新解析（渲染/事件热路径零解析）。 */
    private static volatile String cachedFootstepCsv = "";
    private static volatile String cachedGunshotCsv = "";
    private static volatile List<String> cachedFootstepKeywords = List.of();
    private static volatile List<String> cachedGunshotKeywords = List.of();

    /** 防抖落盘状态（与 CompassConfig 同策略）。 */
    private static volatile boolean dirty;
    private static volatile long lastChangeMillis;
    private static final long SAVE_QUIET_PERIOD_MS = 500L;

    /** 写前日志（对抗 FML 监视线程重载覆盖）。 */
    private static final ConcurrentHashMap<ModConfigSpec.ConfigValue<?>, Object> JOURNAL =
            new ConcurrentHashMap<>();

    // ==================== 常规 ====================
    public static final ModConfigSpec.BooleanValue ENABLED;
    /** 跟随方位条显隐：方位条隐藏（含 F3）时声纹一并隐藏。关闭后声纹独立显隐。 */
    public static final ModConfigSpec.BooleanValue FOLLOW_COMPASS;

    // ==================== 检测 ====================
    /** 检测半径（米），默认 20。 */
    public static final ModConfigSpec.IntValue RADIUS;
    public static final ModConfigSpec.BooleanValue FOOTSTEPS;
    public static final ModConfigSpec.BooleanValue GUNSHOTS;
    /** 忽略玩家自己的脚步 / 动作声。 */
    public static final ModConfigSpec.BooleanValue IGNORE_OWN;
    /** 检测自己的枪声（v2.8.0 缺陷①，测试用）：自声枪声绕过自声过滤，
     *  投影到视线前方渲染在条带正中。 */
    public static final ModConfigSpec.BooleanValue OWN_GUNSHOTS;
    /** 走动持续点亮（v2.8.0 缺陷②）：半径内走动实体实时续期 / 新建声源，
     *  停走后按 linger 淡出；静步（潜行）不触发。 */
    public static final ModConfigSpec.BooleanValue MOTION_PERSIST;
    /** 脚步声 id 关键字（逗号分隔，小写子串匹配）。 */
    public static final ModConfigSpec.ConfigValue<String> FOOTSTEP_KEYWORDS;
    /** 枪声 id 关键字（逗号分隔，小写子串匹配），供外部枪械模组追加。 */
    public static final ModConfigSpec.ConfigValue<String> GUNSHOT_KEYWORDS;

    // ==================== 多声源 ====================
    /** merge（默认：聚合合并）/ stagger（并排错位）。 */
    public static final ModConfigSpec.ConfigValue<String> MODE;
    /** 聚合窗口（度）：方位差小于该值的声源合并为一簇（merge 模式）。 */
    public static final ModConfigSpec.IntValue MERGE_WINDOW;
    /** 并排错位模式的成员水平间隔（像素）。 */
    public static final ModConfigSpec.IntValue STAGGER_SPACING;

    // ==================== 形态与配色 ====================
    /** 每簇竖条数量。 */
    public static final ModConfigSpec.IntValue BAR_COUNT;
    /** 单根竖条宽度（像素）。 */
    public static final ModConfigSpec.IntValue BAR_WIDTH;
    /** 竖条间隙（像素）。 */
    public static final ModConfigSpec.IntValue BAR_GAP;
    /** 声纹单侧最大高度（像素，不含枪声加成）。 */
    public static final ModConfigSpec.IntValue MAX_HEIGHT;
    /** 基准线（与方位条底边对齐的水平线）。 */
    public static final ModConfigSpec.BooleanValue BASELINE;
    /** 无杆方向箭头（上 / 下）。 */
    public static final ModConfigSpec.BooleanValue ARROWS;
    /** 距离衰减（高度与透明度随距离降低）。 */
    public static final ModConfigSpec.BooleanValue DISTANCE_DECAY;
    /** 最远可见系数：半径边缘处的高度 / 透明度下限。 */
    public static final ModConfigSpec.DoubleValue MIN_DECAY;
    /** 垂直偏移联动（声源在上方 / 下方时上下不对称 + 箭头指示）。 */
    public static final ModConfigSpec.BooleanValue VERTICAL_OFFSET;
    /** 颜色覆盖：-1 = 跟随类型默认色（脚步白 / 枪声红）。 */
    public static final ModConfigSpec.IntValue COLOR_FOOTSTEP;
    public static final ModConfigSpec.IntValue COLOR_GUNSHOT;
    public static final ModConfigSpec.DoubleValue OPACITY;
    public static final ModConfigSpec.DoubleValue SCALE;

    // ==================== 动画 ====================
    /** 出现速度（弹簧 omega，越大越快起振）。 */
    public static final ModConfigSpec.DoubleValue ATTACK;
    /** 衰减速度（弹簧 omega，越大消失越快）。 */
    public static final ModConfigSpec.DoubleValue RELEASE;
    /** 声纹停留（毫秒）：声音停止后满能量保持的窗口（v2.8.0 缺陷②），
     *  默认 650ms 超过人类脚步间隔（~450ms），连走不闪烁；停走后满能保持
     *  该时长再淡出——即“暂停 0.5~1 秒后消失”。 */
    public static final ModConfigSpec.IntValue LINGER_MS;

    // ==================== 位置 ====================
    /** 与方位条底边的垂直间距（像素）。 */
    public static final ModConfigSpec.IntValue SPACING;

    /** v2.8.0 声纹形态预设一次性收敛标记（见 SoundPrintConfigEvents），无需手动修改。 */
    public static final ModConfigSpec.BooleanValue SHAPE_RETUNED;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.comment("声纹 HUD (HERRA Soundprint) — 客户端配置",
                "修改后立即生效；外部编辑文件由 NeoForge 自动热重载。",
                "声纹渲染在方位条正下方，默认跟随方位条显隐。",
                "shape_retuned 为 v2.8.0 形态预设收敛标记，无需手动修改。").push("general");
        ENABLED = reg(b.define("enabled", true));
        FOLLOW_COMPASS = reg(b.define("follow_compass_visibility", true));
        SHAPE_RETUNED = reg(b.define("shape_retuned", false));
        b.pop();

        b.comment("检测：radius = 检测半径（米）；关键字表为声音 id 的小写子串匹配，",
                "外部枪械模组的声音 id 可通过 gunshot_keywords 追加。",
                "detect_own_gunshots = 检测自己的枪声（测试用，声纹渲染在条带正中）；",
                "motion_persist = 走动持续点亮（半径内走动实体实时续期，停走后按 linger 淡出）。")
                .push("detection");
        RADIUS = reg(b.defineInRange("radius", 20, 4, 64));
        FOOTSTEPS = reg(b.define("footsteps", true));
        GUNSHOTS = reg(b.define("gunshots", true));
        IGNORE_OWN = reg(b.define("ignore_own_sounds", true));
        OWN_GUNSHOTS = reg(b.define("detect_own_gunshots", true));
        MOTION_PERSIST = reg(b.define("motion_persist", true));
        FOOTSTEP_KEYWORDS = reg(b.define("footstep_keywords",
                "step, footstep"));
        GUNSHOT_KEYWORDS = reg(b.define("gunshot_keywords",
                "gun, shot, shoot, rifle, pistol, sniper, cannon, gunfire, muzzle, explosion, blast"));
        b.pop();

        b.comment("多声源：mode = merge（默认：聚合合并，同方位声源合成一簇）",
                "或 stagger（并排错位，同方位声源保持独立声纹横向错开）。",
                "merge_window = 聚合窗口（度）；stagger_spacing = 错位间隔（像素）。").push("multi_source");
        MODE = reg(b.define("mode", "merge"));
        MERGE_WINDOW = reg(b.defineInRange("merge_window", 6, 2, 20));
        STAGGER_SPACING = reg(b.defineInRange("stagger_spacing", 2, 1, 6));
        b.pop();

        b.comment("形态与配色：bar_count / bar_width / bar_gap / max_height 决定单簇声纹几何；",
                "颜色覆盖 -1 = 跟随默认（脚步白 / 枪声红），其余为 0xRRGGBB 整数。",
                "v2.8.0 预设拉宽：bar_count 9→14、bar_gap 1→3（单簇宽 26px→67px，",
                "消除“太扁”观感）；老配置由 SoundPrintConfigEvents 一次性收敛。").push("style");
        BAR_COUNT = reg(b.defineInRange("bar_count", 14, 5, 21));
        BAR_WIDTH = reg(b.defineInRange("bar_width", 2, 1, 4));
        BAR_GAP = reg(b.defineInRange("bar_gap", 3, 0, 3));
        MAX_HEIGHT = reg(b.defineInRange("max_height", 24, 8, 56));
        BASELINE = reg(b.define("baseline", true));
        ARROWS = reg(b.define("arrows", true));
        DISTANCE_DECAY = reg(b.define("distance_decay", true));
        MIN_DECAY = reg(b.defineInRange("min_decay", 0.2, 0.0, 0.6));
        VERTICAL_OFFSET = reg(b.define("vertical_offset", true));
        COLOR_FOOTSTEP = reg(b.defineInRange("color_footstep", -1, -1, 0xFFFFFF));
        COLOR_GUNSHOT = reg(b.defineInRange("color_gunshot", -1, -1, 0xFFFFFF));
        OPACITY = reg(b.defineInRange("opacity", 0.9, 0.15, 1.0));
        SCALE = reg(b.defineInRange("scale", 1.0, 0.5, 2.0));
        b.pop();

        b.comment("动画：attack / release 为弹簧刚度（omega），帧率无关；",
                "枪声自动比起同能量脚步更快起振与消散；",
                "linger = 声纹停留（毫秒），声音停止后满能量保持窗口，",
                "超过人类脚步间隔即连走不闪。").push("animation");
        ATTACK = reg(b.defineInRange("attack", 18.0, 4.0, 40.0));
        RELEASE = reg(b.defineInRange("release", 7.0, 1.0, 20.0));
        LINGER_MS = reg(b.defineInRange("linger_ms", 650, 300, 1500));
        b.pop();

        b.comment("位置：spacing = 声纹基准线与方位条底边的垂直间距（像素）。",
                "水平位置与宽度始终跟随方位条配置，不可单独偏移（战术上一体）。").push("position");
        SPACING = reg(b.defineInRange("spacing", 2, 0, 20));
        b.pop();

        SPEC = b.build();
    }

    private SoundPrintConfig() {}

    private static <T extends ModConfigSpec.ConfigValue<?>> T reg(T value) {
        ALL.add(value);
        return value;
    }

    // ==================== 关键字表缓存 ====================

    /** 脚步关键字表（带配置变化检测的缓存）。 */
    public static List<String> footstepKeywords() {
        String csv = FOOTSTEP_KEYWORDS.get();
        if (!Objects.equals(csv, cachedFootstepCsv)) {
            cachedFootstepKeywords = SoundClassifier.parseKeywords(csv);
            cachedFootstepCsv = csv;
        }
        return cachedFootstepKeywords;
    }

    /** 枪声关键字表（带配置变化检测的缓存）。 */
    public static List<String> gunshotKeywords() {
        String csv = GUNSHOT_KEYWORDS.get();
        if (!Objects.equals(csv, cachedGunshotCsv)) {
            cachedGunshotKeywords = SoundClassifier.parseKeywords(csv);
            cachedGunshotCsv = csv;
        }
        return cachedGunshotKeywords;
    }

    /** 当前模式是否为并排错位（否则聚合合并）。 */
    public static boolean staggerMode() {
        return "stagger".equalsIgnoreCase(MODE.get());
    }

    // ==================== 写入纪律（与 CompassConfig 同一套） ====================

    /** 运行时修改配置（指令 / 设置界面使用）：journal + 防抖落盘。 */
    public static <T> void set(ModConfigSpec.ConfigValue<T> value, T newValue) {
        value.set(newValue);
        JOURNAL.put(value, newValue);
        dirty = true;
        lastChangeMillis = System.currentTimeMillis();
    }

    /** 由 client tick 调用：连续修改静默后统一落盘。 */
    static void tickSave() {
        if (dirty && System.currentTimeMillis() - lastChangeMillis >= SAVE_QUIET_PERIOD_MS) {
            flush();
        }
    }

    /** 立即落盘（退出世界等时机的兜底）。 */
    public static void flush() {
        if (dirty) {
            dirty = false;
            SPEC.save();
        }
    }

    /** 配置重载对账（Loading / Reloading 事件均调用；可能在监视线程执行）。 */
    static void onConfigReloaded() {
        if (JOURNAL.isEmpty()) return;
        boolean reapplied = false;
        for (Iterator<Map.Entry<ModConfigSpec.ConfigValue<?>, Object>> it = JOURNAL.entrySet().iterator();
                it.hasNext(); ) {
            Map.Entry<ModConfigSpec.ConfigValue<?>, Object> entry = it.next();
            ModConfigSpec.ConfigValue<?> value = entry.getKey();
            Object wanted = entry.getValue();
            try {
                if (Objects.equals(value.getRaw(), wanted)) {
                    it.remove();
                } else {
                    setQuietly(value, wanted);
                    reapplied = true;
                }
            } catch (IllegalStateException | NullPointerException ignored) {
            }
        }
        if (reapplied) {
            dirty = true;
            lastChangeMillis = System.currentTimeMillis();
        }
    }

    /** 配置卸载（退出到主菜单）。 */
    static void onConfigUnloaded() {
        JOURNAL.clear();
        dirty = false;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void setQuietly(ModConfigSpec.ConfigValue value, Object wanted) {
        value.set(wanted);
    }

    /** 全部恢复默认值并写盘。 */
    public static void resetToDefaults() {
        for (ModConfigSpec.ConfigValue<?> value : ALL) {
            resetOne(value);
            JOURNAL.put(value, value.getDefault());
        }
        dirty = false;
        SPEC.save();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void resetOne(ModConfigSpec.ConfigValue<?> value) {
        ((ModConfigSpec.ConfigValue) value).set(value.getDefault());
    }

    /** 供主类注册使用。 */
    public static ModConfig.Type type() {
        return ModConfig.Type.CLIENT;
    }

    public static String fileName() {
        return "draginventory-soundprint-client.toml";
    }
}
