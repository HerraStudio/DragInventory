package dev.draginventory.client.soundprint;

/**
 * 声纹声源类型：决定声纹颜色与形态强度。
 *
 * <p>脚步 = 冷静的战术白；枪声 = 攻击性的红（参考三角洲行动的声纹语言）。
 * 类型判定见 {@link SoundClassifier}，颜色可被配置覆盖
 * （{@link SoundPrintConfig#COLOR_FOOTSTEP} / {@link SoundPrintConfig#COLOR_GUNSHOT}，
 * -1 = 跟随此处的默认色）。</p>
 */
public enum SoundPrintType {
    /** 脚步与移动声：纯白微暖。 */
    FOOTSTEP(0xF2F2F2),
    /** 枪声与爆炸：攻击性红。 */
    GUNSHOT(0xFF5252);

    private final int defaultRgb;

    SoundPrintType(int defaultRgb) {
        this.defaultRgb = defaultRgb;
    }

    /** 默认颜色（未配置覆盖时）。 */
    public int defaultRgb() {
        return defaultRgb;
    }

    /** 形态强度系数：枪声更高、更密实（参考图 4）。 */
    public float heightBoost() {
        return this == GUNSHOT ? 1.35f : 1f;
    }

    /** 类型基准音量：用于把不同类型的原始响度归一化到可比的能量区间。
     *  脚步的原始 volume 普遍在 0.15~0.3，枪声在 0.8~1.0，直接用原始值
     *  会让脚步声纹永远矮半截；按各自基准归一后两者都可吃满高度。 */
    public float baseVolume() {
        return this == GUNSHOT ? 0.85f : 0.28f;
    }

    /** 能量衰减时长系数：枪声瞬态（起得快落得也快），脚步稍缓。 */
    public float decaySeconds() {
        return this == GUNSHOT ? 0.85f : 1.25f;
    }
}
