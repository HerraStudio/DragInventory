package dev.draginventory.client.soundprint;

import com.lowdragmc.lowdraglib2.gui.hud.ModularHudLayer;
import com.lowdragmc.lowdraglib2.gui.ui.ModularUI;
import com.lowdragmc.lowdraglib2.gui.ui.UI;
import com.lowdragmc.lowdraglib2.gui.ui.UIElement;
import dev.draginventory.client.compass.CompassConfig;
import dev.draginventory.client.compass.CompassWidget;
import dev.vfyjxf.taffy.style.TaffyPosition;
import java.lang.reflect.Field;
import net.minecraft.util.Mth;

/**
 * 声纹 HUD 层：LDLib2 ModularHudLayer 独立实现（与 {@code CompassHud} 同模式）。
 *
 * <h2>v2.8.0 位置策略（用户实测反馈缺陷③重合后确立）</h2>
 * <p><b>实时识别方位条 UI 的真实位置，声纹贴其正下方</b>，而非复算配置公式：</p>
 * <ol>
 *   <li><b>实时识别</b>：反射读取 {@code CompassHud} 活动实例内 {@code CompassWidget}
 *       的 Taffy 布局解析值（{@code getPositionY / getSizeWidth / getSizeHeight}
 *       即本帧真实屏幕几何）。方位条被拖动 / 拉宽 / 换皮肤 / 改缩放的当帧声纹
 *       即跟随，不需要复算“皮肤声明高度夹 40~72”等任何隐式约定。</li>
 *   <li><b>缩放换算</b>：方位条绘制时以 (centerX, 0) 为锚做 {@code CompassConfig.SCALE}
 *       缩放（视觉 top = offset_y × scale），声纹布局值先按方位条缩放换算到视觉
 *       像素，再除以声纹自身 SCALE（自身绘制同样 y=0 锚缩放），保证“间距”是
 *       视觉像素语义。</li>
 *   <li><b>回退数学</b>：反射任何一步失败（私有字段演进 / 方位条 UI 未建，如
 *       方位条被禁用）回退到与 {@code CompassHud.syncLayout} 同式的配置数学，
 *       声纹永不错位到屏外。</li>
 * </ol>
 * <p>反射只读本 mod 自有类的私有字段（无混淆、同名 JAR 内），声纹依旧<b>零修改</b>
 * compass 包任何代码。</p>
 *
 * <h2>v2.8.0 绘制坐标系修复（重合缺陷的另一半根因）</h2>
 * <p>LDLib2 绘制链（{@code UIElement.drawBackgroundTexture/Additional}）工作在
 * <b>绝对屏幕坐标</b>（无控件局部平移，源码级实证）；{@code SoundPrintWidget}
 * 旧版误用控件局部 Y（baselineY=0.5f），声纹全部画在屏幕顶端与方位条重合。
 * 修复见 {@code SoundPrintWidget.drawBackgroundAdditional}。</p>
 */
final class SoundPrintHud implements ModularHudLayer {

    private ModularUI ui;
    private SoundPrintWidget widget;
    private int cachedWidth = -1;
    private int cachedOffsetX = Integer.MIN_VALUE;
    private int cachedOffsetY = Integer.MIN_VALUE;
    private int cachedHeight = -1;
    private int cachedSpacing = -1;

    // ==================== 实时方位条几何（反射，字段句柄静态缓存） ====================

    /** 反射解析失败哨兵（一次失败后续直接走回退数学，不再每帧抛异常）。 */
    private static volatile boolean reflectionBroken;
    private static volatile Field compassLayerField;
    private static volatile Field compassWidgetField;

    /** 方位条活动控件（不可用返回 null：UI 未建 / 反射演进失败）。 */
    private static CompassWidget liveCompassWidget() {
        if (reflectionBroken) return null;
        try {
            if (compassLayerField == null || compassWidgetField == null) {
                Field layerField = Class.forName(
                        "dev.draginventory.client.compass.CompassHudRegistration").getDeclaredField("LAYER");
                layerField.setAccessible(true);
                Field widgetField = Class.forName(
                        "dev.draginventory.client.compass.CompassHud").getDeclaredField("widget");
                widgetField.setAccessible(true);
                compassLayerField = layerField;
                compassWidgetField = widgetField;
            }
            Object layer = compassLayerField.get(null);
            if (layer == null) return null;
            Object widget = compassWidgetField.get(layer);
            return widget instanceof CompassWidget cw ? cw : null;
        } catch (ReflectiveOperationException | RuntimeException e) {
            reflectionBroken = true; // 此后永久回退配置数学（本 mod 自有类，正常永不触发）
            return null;
        }
    }

    /** 本帧方位条几何（布局值，未含缩放）：[topY, height, width]。 */
    private static float[] compassLayoutGeometry() {
        CompassWidget live = liveCompassWidget();
        if (live != null) {
            float w = live.getSizeWidth();
            float h = live.getSizeHeight();
            if (w > 0f && h > 0f) {
                return new float[]{live.getPositionY(), h, w};
            }
        }
        // 回退：与 CompassHud.syncLayout 同式的配置数学。
        float width = CompassConfig.BAR_WIDTH.get();
        float height = Mth.clamp(Math.round(CompassWidget.currentStyle().widgetHeight()), 40, 72);
        return new float[]{CompassConfig.OFFSET_Y.get(), height, width};
    }

    @Override
    public ModularUI getModularUI() {
        if (ui == null) {
            var root = new UIElement().layout(l -> l.widthPercent(100).heightPercent(100));
            widget = new SoundPrintWidget(false);
            root.addChild(widget);
            ui = ModularUI.of(UI.of(root));
        }
        syncLayout();
        return ui;
    }

    /** 每帧热同步：实时方位条几何 + 声纹自身配置（间距 / 缩放 / 形态）变化即更新布局。 */
    private void syncLayout() {
        float[] compass = compassLayoutGeometry();
        float compassTop = compass[0];
        float compassHeight = compass[1];
        float compassWidth = compass[2];
        float compassScale = (float) CompassConfig.SCALE.get().doubleValue();

        // 方位条视觉底边（其 applyScale 以 y=0 为锚：视觉 y = 布局 y × scale）。
        float visualBottom = (compassTop + compassHeight) * compassScale;

        int spacing = SoundPrintConfig.SPACING.get();
        float ownScale = Math.max(0.05f, (float) SoundPrintConfig.SCALE.get().doubleValue());
        // 声纹自身绘制同样以 y=0 锚缩放：布局值 = 期望视觉值 / 自身缩放。
        int width = Math.max(60, Math.round(compassWidth * compassScale / ownScale));
        int offsetY = Math.max(0, Math.round((visualBottom + spacing) / ownScale));
        // 水平：与方位条同中心（屏中 + OFFSET_X，方位条缩放绕自身中心不改中心）。
        int offsetX = CompassConfig.OFFSET_X.get();
        // 声纹带预留高度：上下两排（含枪声 1.35 加成）+ 基线 2 + 箭头 8。
        int height = Math.round(SoundPrintConfig.MAX_HEIGHT.get() * 1.35f) * 2 + 10;
        if (width == cachedWidth && offsetX == cachedOffsetX && offsetY == cachedOffsetY
                && height == cachedHeight && spacing == cachedSpacing) {
            return;
        }
        cachedWidth = width;
        cachedOffsetX = offsetX;
        cachedOffsetY = offsetY;
        cachedHeight = height;
        cachedSpacing = spacing;
        widget.layout(l -> l.positionType(TaffyPosition.ABSOLUTE)
                .leftPercent(50)
                .marginLeft(-width / 2f + offsetX)
                .top(offsetY)
                .width(width)
                .height(height));
    }
}
