package dev.draginventory.client.soundprint;

/**
 * 采集安全策略（v2.7.1 实机崩溃修复的核心决策，纯 JVM、零 Minecraft 依赖，
 * 与分类器 / 包络 / 追踪器同套“纯逻辑 + 薄适配”纪律）。
 *
 * <p><b>崩溃背景（用户实测：进存档走第一步即崩）</b>：原版
 * {@code SoundEngine.play} 先发 PlaySoundEvent、事件返回后才调
 * {@code resolve()}；{@code AbstractSoundInstance} 的 sound 字段只有 resolve
 * 才赋值，{@code getVolume()} 在其内部直接解引用——事件回调里直接读响度
 * 必然 NPE，世界内任何命中关键字的声音都会炸穿客户端 tick。</p>
 *
 * <p>本类把“先幂等补 resolve、再读响度；占位声效跳过；任何实现异常退满响度、
 * 绝不外溢”的决策流与判定数学收敛于此；生产侧由 {@link SoundPrintEvents}
 * 以 {@link SoundView} 适配 SoundInstance，回归侧（
 * SoundPrintCaptureSafetyTest）直接以桩实现锁定时序与决策表。</p>
 */
final class SoundPrintCaptureRules {
    private SoundPrintCaptureRules() {}

    /**
     * 声效读取视图（生产侧包装 SoundInstance / SoundManager；声效对象在此
     * 统一为 Object——判定全部由实现侧以引用恒等完成，纯 JVM 层不关心其类型）。
     */
    interface SoundView {
        /** 当前已解析的底层声效；null = 尚未解析（事件回调期的常态）。 */
        Object resolvedSound();

        /** 幂等解析一次（引擎稍后自己还会再 resolve，重解析无副作用）。 */
        void resolveOnce();

        /** 该声效是否“引擎最终不会播放”的占位（未注册 / 刻意留空）。 */
        boolean isUnplayable(Object sound);

        /**
         * 读取原始响度。未解析时按原版语义必然 NPE——实现方无须防御，
         * 调用时序由 {@link #safeLoudness} 保证先 resolve。
         */
        float rawVolume();
    }

    /**
     * 安全响度决策：
     * <ul>
     *   <li>未解析 → 先幂等补一次 resolve 再读（顺序即回归点：任何实现未解析
     *       就读响度会在此当场 NPE，被测试捕获）；</li>
     *   <li>解析后为占位声效（引擎只会 warn 不会播）→ 返回 NaN，调用方按
     *       “听得到才采集”跳过；</li>
     *   <li>resolve / 取声效 / 读响度任一步抛异常（非常规实现，如 Connector
     *       转换的 Fabric 声）→ 退回满响度 1.0，任何路径都不外溢。</li>
     * </ul>
     *
     * @return 采集响度（未夹取，调用方统一 [0.05, 1] 截断）；NaN = 跳过采集
     */
    static float safeLoudness(SoundView view) {
        Object resolved = quietResolved(view);
        if (resolved == null) {
            try {
                view.resolveOnce();
            } catch (RuntimeException ignored) {
                // 非常规实现解析失败：按满响度采集
            }
            resolved = quietResolved(view);
        }
        if (resolved == null) return 1f;
        if (view.isUnplayable(resolved)) return Float.NaN;
        try {
            return view.rawVolume();
        } catch (RuntimeException ignored) {
            return 1f;
        }
    }

    private static Object quietResolved(SoundView view) {
        try {
            return view.resolvedSound();
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    /**
     * 自声判定阈值：声源距玩家碰撞箱表面这个距离以内视为玩家自己发出的声音
     * （脚步 / 落地 / 受伤等全部发自体内，距离 0m）。碰撞箱间隙小于该值的
     * 贴脸声也会被误伤，但那个距离上的威胁肉眼可见，声纹不承担信息量。
     */
    static final double OWN_SOUND_METERS = 0.3;

    /**
     * 声源到轴对齐碰撞箱（中心 {@code (px,pz)}、脚底 {@code py}、宽 0.6、高
     * 1.8）的最近点距离平方，箱内为 0。数学与原版
     * {@code AABB.distanceToSqr(Vec3)} 完全一致（每轴
     * {@code max(max(min-p, p-max), 0)} 后平方和）。
     *
     * <p>取代 v2.7.0 的“眼睛位置 3D 距离”：脚步声在脚部播放，与眼睛垂直差
     * 1.62m 直接击穿旧 0.9m 阈值，自声过滤从未生效（正是它触发了采集 NPE）。</p>
     */
    static double boxDistanceSqr(double px, double py, double pz,
                                 double x, double y, double z) {
        double dx = Math.max(Math.max(px - 0.3 - x, x - (px + 0.3)), 0d);
        double dy = Math.max(Math.max(py - y, y - (py + 1.8)), 0d);
        double dz = Math.max(Math.max(pz - 0.3 - z, z - (pz + 0.3)), 0d);
        return dx * dx + dy * dy + dz * dz;
    }

    /** 便捷判定：声源是否落入自声范围（碰撞箱或其表面 OWN_SOUND_METERS 内）。 */
    static boolean isOwnSound(double px, double py, double pz,
                              double x, double y, double z) {
        return boxDistanceSqr(px, py, pz, x, y, z)
                < OWN_SOUND_METERS * OWN_SOUND_METERS;
    }

    /**
     * 自声枪声投影（v2.8.0 缺陷①：检测自己的枪声，测试用）。
     *
     * <p>自己的枪声发自体内（dx=dz=0），直接算方位会得 atan2(0,0)=0 恒指北，
     * 面朝其他方向时声纹出现在视野外毫无测试价值。按"枪口在我眼前"的语义
     * 把声源投到眼睛沿视线前方 {@code distance} 米处：声纹落在条带正中
     * （bearing = 当前朝向），俯仰时垂直偏移联动（测箭头），距离近能量足
     * （测形态）。视线向量归一在此完成（不假设调用方已归一）。</p>
     *
     * @param eyeX eyeY eyeZ 眼睛位置
     * @param vx vy vz 视线方向（任意长度，零向量退回眼睛位置）
     * @param distance 投影距离（米）
     * @return 投影后的声源坐标 {x, y, z}
     */
    static double[] projectAhead(double eyeX, double eyeY, double eyeZ,
                                 double vx, double vy, double vz, double distance) {
        double len = Math.sqrt(vx * vx + vy * vy + vz * vz);
        if (len < 1e-6) {
            return new double[]{eyeX, eyeY, eyeZ};
        }
        double k = distance / len;
        return new double[]{eyeX + vx * k, eyeY + vy * k, eyeZ + vz * k};
    }
}
