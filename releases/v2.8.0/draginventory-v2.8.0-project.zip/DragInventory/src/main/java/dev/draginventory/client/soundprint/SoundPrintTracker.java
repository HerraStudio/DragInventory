package dev.draginventory.client.soundprint;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * 声纹状态中心：活跃声源表的生命周期管理。
 *
 * <p>数据流：{@link SoundPrintEvents}（PlaySoundEvent，可能任意线程）-> {@link #offer}
 * 并发队列 -> client tick（主线程）{@link #tick} 汇入活跃表、步进能量弹簧、淘汰过期源
 * -> 渲染帧 {@link #frameHits} 输出聚合器输入。核心为纯 JVM（不 import MC 类），
 * 单测直接驱动 tick / offer 时间线。</p>
 *
 * <p>能量模型：每个源有 peak（由最近样本的归一化音量 × 当时的距离衰减决定），
 * target = peak × 时间窗因子（hold 后线性淡出），displayEnergy 用临界阻尼弹簧
 * 追 target——重听即刷新（连走脚步持续满能量，停步后按 release 速度衰减消失，
 * 枪声自动更瞬态）。弹簧闭式解与 {@code CompassHeading} / {@code WeaponHudMotion}
 * 同源：无过冲、帧率（tick 率）无关。</p>
 */
public final class SoundPrintTracker {

    /** 同一物理声源的合并半径（米）：两样本相距小于该值视为同源刷新。 */
    static final double SAME_SOURCE_METERS = 1.6;

    /** 默认停留窗口（毫秒）：仅在调用方未传 linger 时的兼容缺省。 */
    static final long HOLD_MS = 650L;

    /** 活跃声源上限（超限时替换能量最低者，防极端声场堆积）。 */
    static final int MAX_SOURCES = 16;

    /** 一个活跃声源的完整渲染态。 */
    public static final class ActiveSource {
        final SoundPrintType type;
        double x, y, z;
        /** 峰值能量（最近一次触发的归一化音量 × 当时距离衰减）。 */
        float peak;
        /** 当前显示能量（弹簧平滑值，0..1）。 */
        float displayEnergy;
        /** 最近一次听到的时间（毫秒）。 */
        long lastHeard;
        /** 声音 id（最近一次触发，调试用）。 */
        String soundId;

        ActiveSource(SoundSample sample, float energy, long now) {
            this.type = sample.type();
            this.x = sample.x();
            this.y = sample.y();
            this.z = sample.z();
            this.peak = energy;
            this.displayEnergy = 0f;
            this.lastHeard = now;
            this.soundId = sample.soundId();
        }
    }

    private final ConcurrentLinkedQueue<SoundSample> inbox = new ConcurrentLinkedQueue<>();
    private final List<ActiveSource> sources = new ArrayList<>();
    private long lastTickMillis = Long.MIN_VALUE;

    /** 事件层投递（线程安全；样本已在外层完成分类 / 距离 / 自声过滤）。 */
    public void offer(SoundSample sample) {
        if (sample != null) inbox.add(sample);
    }

    /**
     * client tick 步进：汇入新样本、更新距离衰减、步进弹簧、淘汰过期源。
     *
     * @param nowMillis 当前毫秒
     * @param px py pz 玩家眼睛位置（世界坐标）
     * @param radius 检测半径（米）
     * @param minDecay 半径边缘的可见系数
     * @param distanceDecay 距离衰减开关
     * @param attack 出现弹簧 omega（配置）
     * @param release 衰减弹簧 omega（配置）
     */
    public void tick(long nowMillis,
                     double px, double py, double pz,
                     float radius, float minDecay, boolean distanceDecay,
                     float attack, float release, long holdMs) {
        float dt = stepDeltaSeconds(nowMillis);

        // 汇入新样本（同源刷新 / 新建 / 超限替换）。
        SoundSample sample;
        while ((sample = inbox.poll()) != null) {
            if (nowMillis - sample.atMillis() > 2000L) continue; // 严重迟到的样本丢弃
            mergeOrAdd(sample, nowMillis, px, py, pz, radius, minDecay, distanceDecay);
        }

        // 弹簧步进 + 淘汰。
        for (int i = sources.size() - 1; i >= 0; i--) {
            ActiveSource source = sources.get(i);
            float target = targetEnergy(source, nowMillis, px, py, pz, radius, minDecay, distanceDecay, holdMs);
            boolean rising = target > source.displayEnergy;
            source.displayEnergy = springStep(source.displayEnergy, target,
                    dt, rising ? attack : Math.max(release, 1.5f));
            boolean expired = source.displayEnergy < 0.02f
                    && nowMillis - source.lastHeard > holdMs + 240L;
            if (expired) {
                sources.remove(i);
            }
        }
    }

    // ==================== 走动续期（v2.8.0 连贯显示） ====================

    /**
     * 半径内一个"正在走动"实体的最小快照（事件层从世界采集，主线程喂入）。
     *
     * @param x y z 实体脚部世界坐标（脚步声源的参考位置）
     * @param speed 水平速度（米 / tick），走动强度参考
     */
    public record Mover(double x, double y, double z, double speed) {}

    /** 走动能量映射：慢走 0.1 m/t ~ 0.53，疾跑 0.28 m/t ~ 0.85，下限 0.35。 */
    static float motionEnergy(double speedBlocksPerTick) {
        return SoundPrintEnvelope.clamp(
                (float) (0.35 + speedBlocksPerTick * 1.8), 0.35f, 0.9f);
    }

    /**
     * 走动续期步进（client tick 主线程，需在 {@link #tick} 之前调用）：
     * <ul>
     *   <li>命中已有脚步源（1.6m 内）：lastHeard 续期 + 位置实时跟随
     *       （声纹随行走者滑移）；不抬 peak（走动是"在场"证据，不是新响度）。</li>
     *   <li>无匹配源且未满员：按速度能量新建（刚进入半径 / 超耳距但仍在
     *       检测半径内的走动者）。</li>
     *   <li>枪声源不参与续期：站位开枪者走开时枪声按自身 linger 淡出，
     *       其脚步语义由（新建的）脚步源表达。</li>
     * </ul>
     * 停止走动的事件层不再喂入该实体，源自然按 linger 淡出——即
     * "走动一直显示，暂停 0.5~1 秒后消失"。
     */
    public void motionTick(long nowMillis, List<Mover> movers) {
        if (movers.isEmpty()) return;
        for (Mover mover : movers) {
            boolean matched = false;
            for (ActiveSource source : sources) {
                if (source.type != SoundPrintType.FOOTSTEP) continue;
                if (samePosition(source, mover.x(), mover.y(), mover.z())) {
                    source.x = mover.x();
                    source.y = mover.y();
                    source.z = mover.z();
                    source.lastHeard = Math.max(source.lastHeard, nowMillis);
                    matched = true;
                    break;
                }
            }
            if (!matched && sources.size() < MAX_SOURCES) {
                float energy = motionEnergy(mover.speed());
                sources.add(new ActiveSource(
                        new SoundSample(mover.x(), mover.y(), mover.z(),
                                SoundPrintType.FOOTSTEP, energy, nowMillis,
                                "draginventory:motion_walk"),
                        energy, nowMillis));
            }
        }
    }

    private float stepDeltaSeconds(long nowMillis) {
        float dt;
        if (lastTickMillis == Long.MIN_VALUE) {
            dt = 0.05f;
        } else {
            dt = Math.min(0.25f, Math.max(0.001f, (nowMillis - lastTickMillis) / 1000f));
        }
        lastTickMillis = nowMillis;
        return dt;
    }

    private void mergeOrAdd(SoundSample sample, long nowMillis,
                            double px, double py, double pz,
                            float radius, float minDecay, boolean distanceDecay) {
        // 同物理声源（同类型 + 相距 < SAME_SOURCE_METERS）刷新而非新建：
        // 连续脚步 / 连发枪声表现为同一声纹持续满能量，而不是多簇抖动。
        for (ActiveSource source : sources) {
            if (source.type == sample.type() && samePosition(source, sample)) {
                source.x = sample.x();
                source.y = sample.y();
                source.z = sample.z();
                source.lastHeard = nowMillis;
                source.soundId = sample.soundId();
                float energy = normalizedEnergy(sample, px, py, pz, radius, minDecay, distanceDecay);
                source.peak = Math.max(source.peak * 0.6f, energy);
                return;
            }
        }
        float energy = normalizedEnergy(sample, px, py, pz, radius, minDecay, distanceDecay);
        if (sources.size() >= MAX_SOURCES) {
            // 满员：新声源能量高于"保留价值最低"的旧源时替换它（保持最新威胁）。
            int weakest = 0;
            for (int i = 1; i < sources.size(); i++) {
                if (scoreForReplacement(sources.get(i), nowMillis)
                        < scoreForReplacement(sources.get(weakest), nowMillis)) {
                    weakest = i;
                }
            }
            if (energy > scoreForReplacement(sources.get(weakest), nowMillis)) {
                sources.set(weakest, new ActiveSource(sample, energy, nowMillis));
            }
            return;
        }
        sources.add(new ActiveSource(sample, energy, nowMillis));
    }

    /** 替换评分：越低越先被替换（衰减越久、能量越低越先走）。 */
    private static float scoreForReplacement(ActiveSource source, long nowMillis) {
        long quiet = Math.max(0L, nowMillis - source.lastHeard - HOLD_MS);
        return source.displayEnergy * (1f / (1f + quiet / 300f));
    }

    private static boolean samePosition(ActiveSource source, SoundSample sample) {
        return samePosition(source, sample.x(), sample.y(), sample.z());
    }

    private static boolean samePosition(ActiveSource source, double x, double y, double z) {
        double dx = source.x - x;
        double dy = source.y - y;
        double dz = source.z - z;
        return dx * dx + dy * dy + dz * dz <= SAME_SOURCE_METERS * SAME_SOURCE_METERS;
    }

    /** 归一化基准音量：类型基准归一（不含距离衰减——衰减在 targetEnergy 用
     *  当前距离每 tick 重算，玩家移动时能量随距离实时变化）。 */
    private static float normalizedEnergy(SoundSample sample,
                                          double px, double py, double pz,
                                          float radius, float minDecay, boolean distanceDecay) {
        // 位置参数仅为签名统一；距离衰减不在此计算（见 targetEnergy）。
        return SoundPrintEnvelope.clamp(sample.volume() / sample.type().baseVolume(), 0.25f, 1f);
    }

    /** 当前目标能量：peak × 时间窗因子 × 当前距离衰减。 */
    private static float targetEnergy(ActiveSource source, long nowMillis,
                                      double px, double py, double pz,
                                      float radius, float minDecay, boolean distanceDecay,
                                      long holdMs) {
        long quiet = nowMillis - source.lastHeard;
        long fadeMs = (long) (source.type.decaySeconds() * 1000L);
        float timeFactor;
        if (quiet <= holdMs) {
            timeFactor = 1f;
        } else if (quiet >= holdMs + fadeMs) {
            timeFactor = 0f;
        } else {
            timeFactor = 1f - (float) (quiet - holdMs) / fadeMs;
        }
        float dist = distance(px, py, pz, source.x, source.y, source.z);
        return source.peak * timeFactor
                * SoundPrintEnvelope.distanceDecay(dist, radius, minDecay, distanceDecay);
    }

    static float distance(double ax, double ay, double az, double bx, double by, double bz) {
        double dx = ax - bx, dy = ay - by, dz = az - bz;
        return (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** 临界阻尼弹簧闭式解一步（与 CompassHeading 同源算法，无过冲）。 */
    static float springStep(float value, float target, float dt, float omega) {
        if (dt <= 0f) return value;
        double displacement = value - target;
        double coefficient = /* velocity 略（无观测，按静止重置） */ omega * displacement;
        double decay = Math.exp(-omega * dt);
        double next = target + (displacement + coefficient * dt) * decay;
        // 穿越保护：越过目标即夹住（无观测速度的简化弹簧偶发微过冲）。
        if (displacement > 0 && next < target) next = target;
        if (displacement < 0 && next > target) next = target;
        return (float) next;
    }

    /**
     * 渲染帧输出：活跃声源 -> 聚合器命中列表（世界方位 + 能量 + 垂直偏移 + 距离）。
     *
     * @param eyeX eyeY eyeZ 玩家眼睛位置（垂直偏移的参考系）
     */
    public List<SoundPrintAggregator.Hit> frameHits(double eyeX, double eyeY, double eyeZ,
                                                    boolean verticalOffsetEnabled) {
        List<SoundPrintAggregator.Hit> hits = new ArrayList<>(sources.size());
        for (ActiveSource source : sources) {
            if (source.displayEnergy < 0.01f) continue;
            hits.add(new SoundPrintAggregator.Hit(
                    bearingFrom(eyeX, eyeZ, source.x, source.z),
                    source.displayEnergy,
                    source.type,
                    SoundPrintEnvelope.verticalOffset(source.y, eyeY, verticalOffsetEnabled),
                    distance(eyeX, eyeY, eyeZ, source.x, source.y, source.z)));
        }
        return hits;
    }

    /** 玩家眼睛 -> 声源的世界罗盘方位（0=北顺时针），与方位条 bearingBetween 同式。 */
    public static float bearingFrom(double eyeX, double eyeZ, double x, double z) {
        double dx = x - eyeX;
        double dz = z - eyeZ;
        float bearing = (float) Math.toDegrees(Math.atan2(dx, -dz));
        return bearing < 0 ? bearing + 360f : bearing;
    }

    /** 当前活跃声源数（调试 / 测试）。 */
    public int activeCount() {
        return sources.size();
    }

    /** 世界切换 / 重置：清空一切状态。 */
    public void clear() {
        inbox.clear();
        sources.clear();
        lastTickMillis = Long.MIN_VALUE;
    }
}
