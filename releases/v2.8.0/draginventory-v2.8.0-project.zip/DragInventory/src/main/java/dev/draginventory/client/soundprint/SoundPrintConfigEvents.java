package dev.draginventory.client.soundprint;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.config.ModConfigEvent;

/**
 * 声纹配置的 MOD 总线事件：与 FML 配置系统的加载 / 重载 / 卸载对账。
 *
 * <p>与 {@code CompassConfigEvents} 同一套机制（写前日志 + 重载对账重放，
 * 对 save() 内同步触发与监视线程异步触发的 Reloading 均幂等），类级注释
 * 见 {@code CompassConfig}。</p>
 *
 * <p>v2.8.0 形态预设一次性收敛（{@link #retuneShapeDefaults}，标记驱动，
 * 仅 Loading 事件触发）：用户实测反馈单簇声纹"太扁"，出厂预设拉宽
 * bar_count 9→14、bar_gap 1→3（单簇宽 26px→67px）。规则同方位条 v2.6.1
 * retune 先例——仍为旧默认值的项收敛到新默认，玩家自定过的项（≠旧默认）
 * 一律保留，置位标记并落盘，此后玩家主动改回旧值的选择被永久尊重。</p>
 */
@EventBusSubscriber(modid = "draginventory", value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class SoundPrintConfigEvents {

    private SoundPrintConfigEvents() {}

    @SubscribeEvent
    public static void onConfigLoading(ModConfigEvent.Loading event) {
        if (isSoundprintConfig(event)) {
            retuneShapeDefaults();
            SoundPrintConfig.onConfigReloaded();
        }
    }

    @SubscribeEvent
    public static void onConfigReloading(ModConfigEvent.Reloading event) {
        if (isSoundprintConfig(event)) {
            SoundPrintConfig.onConfigReloaded();
        }
    }

    @SubscribeEvent
    public static void onConfigUnloading(ModConfigEvent.Unloading event) {
        if (isSoundprintConfig(event)) {
            SoundPrintConfig.onConfigUnloaded();
        }
    }

    private static boolean isSoundprintConfig(ModConfigEvent event) {
        return SoundPrintConfig.fileName().equals(event.getConfig().getFileName());
    }

    /** v2.8.0 单簇形态预设收敛（详见类注释；同 CompassConfigEvents#retuneDefaults 纪律）。 */
    private static void retuneShapeDefaults() {
        if (SoundPrintConfig.SHAPE_RETUNED.get()) return; // 已收敛过：尊重玩家此后的主动修改
        if (SoundPrintConfig.BAR_COUNT.get() == 9) {
            SoundPrintConfig.set(SoundPrintConfig.BAR_COUNT, 14);
        }
        if (SoundPrintConfig.BAR_GAP.get() == 1) {
            SoundPrintConfig.set(SoundPrintConfig.BAR_GAP, 3);
        }
        SoundPrintConfig.set(SoundPrintConfig.SHAPE_RETUNED, true);
        SoundPrintConfig.flush();
    }
}
