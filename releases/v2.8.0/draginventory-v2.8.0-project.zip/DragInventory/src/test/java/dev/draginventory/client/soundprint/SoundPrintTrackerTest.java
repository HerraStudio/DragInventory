package dev.draginventory.client.soundprint;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import org.junit.jupiter.api.Test;

/**
 * 追踪器生命周期：采集 -> 弹簧包络 -> 衰减 -> 淘汰；refire 刷新、距离衰减
 * 随玩家移动更新、世界切换清空、满员替换。
 */
class SoundPrintTrackerTest {

    /** 标准参数（与出厂配置一致）。 */
    private static final float RADIUS = 20f;
    private static final float MIN_DECAY = 0.2f;
    private static final boolean DECAY = true;
    private static final float ATTACK = 18f;
    private static final float RELEASE = 7f;
    /** v2.8.0 出厂停留窗口（毫秒）。 */
    private static final long HOLD = 650L;
    private static final long TICK_MS = 50L;

    private static SoundSample footstepAt(double x, double y, double z, float volume, long t) {
        return new SoundSample(x, y, z, SoundPrintType.FOOTSTEP, volume, t, "test:step");
    }

    private static SoundSample gunshotAt(double x, double y, double z, float volume, long t) {
        return new SoundSample(x, y, z, SoundPrintType.GUNSHOT, volume, t, "test:shot");
    }

    @Test
    void sampleRisesWithAttackThenDecaysAndExpires() {
        SoundPrintTracker tracker = new SoundPrintTracker();
        long t = 10_000L;
        // 脚步 at 8m 正北：归一音量 = 0.28/0.28 = 1；decay(8/20)=1-0.8*0.632=0.494。
        tracker.offer(footstepAt(0, 64, -8, 0.28f, t));

        tracker.tick(t, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        assertEquals(1, tracker.activeCount());
        float first = tracker.frameHits(0, 64, 0, true).get(0).energy();
        assertTrue(first > 0f, "energy should start rising, got " + first);

        // 持续 tick：能量先升后（静默后）降。
        float peak = first;
        for (int i = 1; i <= 12; i++) {
            tracker.tick(t + i * TICK_MS, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
            float e = tracker.frameHits(0, 64, 0, true).get(0).energy();
            peak = Math.max(peak, e);
        }
        assertTrue(peak > 0.3f, "peak energy should be substantial, got " + peak);

        // 静默到 hold + fade + 弹簧尾巴：linger=650 + fade=1250 后目标归零
        // （i≥38），release 弹簧每 tick 收敛因子 ~0.951（时间常数 ~1s），
        // 完全消散需再 ~2.5s —— 旣 i=140（7s 静默）宽裕覆盖。
        for (int i = 13; i <= 140; i++) {
            tracker.tick(t + i * TICK_MS, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        }
        assertEquals(0, tracker.activeCount(), "source should expire after fade window");
    }

    @Test
    void refireRefreshesLifetimeInsteadOfStacking() {
        SoundPrintTracker tracker = new SoundPrintTracker();
        long t = 100_000L;
        // 连续脚步（同位置）：同源刷新，不叠加新源。
        for (int i = 0; i < 10; i++) {
            tracker.offer(footstepAt(3, 64, -3, 0.28f, t + i * 200L));
            tracker.tick(t + i * 200L, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        }
        assertEquals(1, tracker.activeCount());
        // 持续听到：能量维持高位（不进入 fade）。
        float energy = tracker.frameHits(0, 64, 0, true).get(0).energy();
        assertTrue(energy > 0.4f, "continuous footsteps should keep energy high: " + energy);
    }

    @Test
    void samePositionDifferentTypeKeepsSeparateSources() {
        SoundPrintTracker tracker = new SoundPrintTracker();
        long t = 200_000L;
        tracker.offer(footstepAt(2, 64, -2, 0.28f, t));
        tracker.offer(gunshotAt(2, 64, -2, 0.9f, t));
        tracker.tick(t, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        assertEquals(2, tracker.activeCount());
        List<SoundPrintAggregator.Hit> hits = tracker.frameHits(0, 64, 0, true);
        assertTrue(hits.stream().anyMatch(h -> h.type() == SoundPrintType.GUNSHOT));
        assertTrue(hits.stream().anyMatch(h -> h.type() == SoundPrintType.FOOTSTEP));
    }

    @Test
    void playerMovementUpdatesDistanceDecay() {
        SoundPrintTracker tracker = new SoundPrintTracker();
        long t = 300_000L;
        // 声源固定在 (0,64,-4)，玩家从 (0,64,0) 走到 (0,64,15)：距离 4 -> 19。
        tracker.offer(footstepAt(0, 64, -4, 0.28f, t));
        float farPeak;
        {
            tracker.tick(t, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
            for (int i = 1; i <= 8; i++) {
                tracker.tick(t + i * TICK_MS, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
            }
            float near = tracker.frameHits(0, 64, 0, true).get(0).energy();
            assertTrue(near > 0.4f, "near source energy: " + near);
            // refire 一次把 lastHeard 刷新，然后走远继续 tick。
            tracker.offer(footstepAt(0, 64, -4, 0.28f, t + 9 * TICK_MS));
        }
        // 玩家走到 15（距离 19）：target 应被距离衰减压低。
        for (int i = 10; i <= 30; i++) {
            tracker.tick(t + i * TICK_MS, 0, 64, 15, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        }
        farPeak = tracker.frameHits(0, 64, 15, true).get(0).energy();
        assertTrue(farPeak < 0.4f, "far source energy should decay with distance: " + farPeak);
    }

    @Test
    void bearingMatchesCompassConvention() {
        // 正北（-Z）：0；正东（+X）：90。
        assertEquals(0f, SoundPrintTracker.bearingFrom(0, 0, 0, -10), 0.01f);
        assertEquals(90f, SoundPrintTracker.bearingFrom(0, 0, 10, 0), 0.01f);
        assertEquals(180f, SoundPrintTracker.bearingFrom(0, 0, 0, 10), 0.01f);
        assertEquals(270f, SoundPrintTracker.bearingFrom(0, 0, -10, 0), 0.01f);
        // frameHits 输出一致。
        SoundPrintTracker tracker = new SoundPrintTracker();
        long t = 400_000L;
        tracker.offer(gunshotAt(10, 64, 0, 0.9f, t));
        tracker.tick(t, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        List<SoundPrintAggregator.Hit> hits = tracker.frameHits(0, 64, 0, true);
        assertEquals(90f, hits.get(0).bearing(), 0.5f);
    }

    @Test
    void verticalOffsetFlowsthroughFrameHits() {
        SoundPrintTracker tracker = new SoundPrintTracker();
        long t = 500_000L;
        // 楼上脚步（+4 格眼高差）：满上偏。
        tracker.offer(footstepAt(0, 68, -5, 0.28f, t));
        tracker.tick(t, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        List<SoundPrintAggregator.Hit> hits = tracker.frameHits(0, 64, 0, true);
        assertTrue(hits.get(0).verticalOffset() > 0.7f);
        // 关闭联动后 frameHits 输出 0。
        List<SoundPrintAggregator.Hit> flat = tracker.frameHits(0, 64, 0, false);
        assertEquals(0f, flat.get(0).verticalOffset(), 1e-6);
    }

    @Test
    void capacityOverflowReplacesWeakest() {
        SoundPrintTracker tracker = new SoundPrintTracker();
        long t = 600_000L;
        // 填满 16 个远端弱源。
        for (int i = 0; i < SoundPrintTracker.MAX_SOURCES; i++) {
            tracker.offer(footstepAt(i * 2.0, 64, -14, 0.1f, t));
        }
        tracker.tick(t, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        assertEquals(SoundPrintTracker.MAX_SOURCES, tracker.activeCount());
        // 新的强源应替换最弱者而不是被丢弃。
        tracker.offer(gunshotAt(1, 64, -1, 1.0f, t + TICK_MS));
        tracker.tick(t + TICK_MS, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        assertEquals(SoundPrintTracker.MAX_SOURCES, tracker.activeCount());
        List<SoundPrintAggregator.Hit> hits = tracker.frameHits(0, 64, 0, true);
        assertTrue(hits.stream().anyMatch(h -> h.type() == SoundPrintType.GUNSHOT),
                "loud newcomer should replace a weak source");
    }

    @Test
    void staleSamplesDroppedAndClearResets() {
        SoundPrintTracker tracker = new SoundPrintTracker();
        long t = 700_000L;
        // 迟到超过 2s 的样本丢弃。
        tracker.offer(footstepAt(0, 64, -5, 0.28f, t - 3000L));
        tracker.tick(t, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        assertEquals(0, tracker.activeCount());
        // 正常源 + clear。
        tracker.offer(footstepAt(0, 64, -5, 0.28f, t));
        tracker.tick(t + TICK_MS, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        assertEquals(1, tracker.activeCount());
        tracker.clear();
        assertEquals(0, tracker.activeCount());
    }

    // ==================== v2.8.0 连贯显示 ====================

    @Test
    void lingerWindowHoldsEnergyBetweenSteps() {
        // 缺陷②防闪烁回归：脚步间隔 ~450ms 内能量不得回落（旧 260ms hold 会
        // 在间隔内进入 fade，表现为“一直闪”）。
        SoundPrintTracker tracker = new SoundPrintTracker();
        long t = 800_000L;
        // 800ms 建立期，每 200ms 重听一次（连走节奏），最后一次在 t+800。
        for (int i = 1; i <= 16; i++) {
            if (i % 4 == 0) {
                tracker.offer(footstepAt(0, 64, -8, 0.28f, t + i * TICK_MS));
            }
            tracker.tick(t + i * TICK_MS, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        }
        float established = tracker.frameHits(0, 64, 0, true).get(0).energy();
        assertTrue(established > 0.4f, "established energy: " + established);
        // 静默 450ms（一个完整步间隔，仍在 linger=650 内）：能量不应下降。
        for (int i = 17; i <= 25; i++) {
            tracker.tick(t + i * TICK_MS, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        }
        float held = tracker.frameHits(0, 64, 0, true).get(0).energy();
        assertTrue(held >= established - 0.02f,
                "linger window should hold energy between steps: " + established + " -> " + held);
        // 静默超过 linger 后进入淡出：fade 于静默 1900ms（i=54）归零，
        // release 弹簧 ~1s 时间常数再追 ~2s —— 至 i=90（静默 4.5s）显著回落。
        for (int i = 26; i <= 90; i++) {
            tracker.tick(t + i * TICK_MS, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        }
        float fading = tracker.frameHits(0, 64, 0, true).get(0).energy();
        assertTrue(fading < established * 0.6f,
                "energy should fade after linger window: " + fading);
    }

    @Test
    void motionTickKeepsWalkingSourceAliveAndGlides() {
        // 缺陷②走动续期：走动者持续点亮 + 声纹随行走者滑移。
        SoundPrintTracker tracker = new SoundPrintTracker();
        long t = 900_000L;
        tracker.offer(footstepAt(0, 63, -5, 0.28f, t));
        tracker.tick(t, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        assertEquals(1, tracker.activeCount());

        // 行走者从 (0,63,-5) 向 +X 走 4 秒（0.2 m/t），每 tick 续期。
        double moverX = 0;
        for (int i = 1; i <= 80; i++) {
            moverX += 0.2;
            tracker.motionTick(t + i * TICK_MS, List.of(
                    new SoundPrintTracker.Mover(moverX, 63, -5, 0.2)));
            tracker.tick(t + i * TICK_MS, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        }
        assertEquals(1, tracker.activeCount(), "walking mover should keep exactly one source");
        List<SoundPrintAggregator.Hit> hits = tracker.frameHits(0, 64, 0, true);
        assertEquals(1, hits.size());
        // 4 秒无声纯走动：能量仍维持（续期生效，不因 linger 淡出；非续期源
        // 在 hold 650 + fade 1250 后早已淘汰）。16.8m 处距离衰减 ≈ 0.27。
        assertTrue(hits.get(0).energy() > 0.2f,
                "4s of walking should keep source lit: " + hits.get(0).energy());
        // 位置滑移：声源已从 (0,-5) 跟到 (16,-5)，方位从 0°（北）变 ~72°（东偏北）。
        assertTrue(hits.get(0).bearing() > 60f && hits.get(0).bearing() < 85f,
                "source should glide with the walker, bearing=" + hits.get(0).bearing());

        // 停走：不再喂 mover，源按 linger+fade 淡出并淘汰。
        for (int i = 81; i <= 170; i++) {
            tracker.tick(t + i * TICK_MS, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        }
        assertEquals(0, tracker.activeCount(), "source should expire after walking stops");
    }

    @Test
    void motionTickCreatesSourceForUnheardWalker() {
        // 刚进入半径 / 超耳距但仍在检测半径内的走动者：按速度新建。
        SoundPrintTracker tracker = new SoundPrintTracker();
        long t = 950_000L;
        // 持续走动 10 tick（0.5s，弹簧起振 + 仍在 linger 内）。
        for (int i = 0; i < 10; i++) {
            tracker.motionTick(t + i * TICK_MS, List.of(
                    new SoundPrintTracker.Mover(4, 63, 0, 0.28)));
            tracker.tick(t + i * TICK_MS, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        }
        assertEquals(1, tracker.activeCount());
        List<SoundPrintAggregator.Hit> hits = tracker.frameHits(0, 64, 0, true);
        assertEquals(SoundPrintType.FOOTSTEP, hits.get(0).type());
        // 疾跑 0.28 m/t 映射峰值 = 0.35+0.28*1.8 = 0.854，4.1m 处距离衰减
        // = 1-0.8*sqrt(0.206) ≈ 0.64 -> 目标能量 ≈ 0.54，弹簧收敛后同量级。
        assertTrue(hits.get(0).energy() > 0.35f,
                "sprint walker source should be substantial: " + hits.get(0).energy());
    }

    @Test
    void motionTickDoesNotProlongGunshotPrint() {
        // 枪声源不参与走动续期：枪手站位开枪后走开，枪声按自身 linger 淡出；
        // 行走者的脚步语义由（新建的）脚步源表达。
        SoundPrintTracker tracker = new SoundPrintTracker();
        long t = 980_000L;
        tracker.offer(gunshotAt(0, 64, -6, 0.9f, t));
        tracker.tick(t, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        // 枪手原地持续走动（同位置 mover）。
        for (int i = 1; i <= 120; i++) { // 6 秒 > 枪声 hold+fade 全程
            tracker.motionTick(t + i * TICK_MS, List.of(
                    new SoundPrintTracker.Mover(0, 63, -6, 0.15)));
            tracker.tick(t + i * TICK_MS, 0, 64, 0, RADIUS, MIN_DECAY, DECAY, ATTACK, RELEASE, HOLD);
        }
        List<SoundPrintAggregator.Hit> hits = tracker.frameHits(0, 64, 0, true);
        assertTrue(hits.stream().noneMatch(h -> h.type() == SoundPrintType.GUNSHOT),
                "gunshot print must fade on its own timeline");
        assertTrue(hits.stream().anyMatch(h -> h.type() == SoundPrintType.FOOTSTEP),
                "walking gunman should show a footstep source");
    }

    @Test
    void motionEnergyMapsSpeed() {
        assertEquals(0.35f, SoundPrintTracker.motionEnergy(0.0), 1e-3);
        assertEquals(0.53f, SoundPrintTracker.motionEnergy(0.1), 1e-3);
        assertEquals(0.854f, SoundPrintTracker.motionEnergy(0.28), 1e-3);
        // 上限 0.9。
        assertEquals(0.9f, SoundPrintTracker.motionEnergy(1.0), 1e-3);
    }
}
