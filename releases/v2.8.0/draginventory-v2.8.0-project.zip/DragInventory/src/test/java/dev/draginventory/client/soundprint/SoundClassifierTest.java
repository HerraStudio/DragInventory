package dev.draginventory.client.soundprint;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.List;
import org.junit.jupiter.api.Test;

/** 声音分类器：关键字匹配 / 表解析 / 脚步优先。 */
class SoundClassifierTest {

    private static final List<String> FOOT = List.of("step", "footstep");
    private static final List<String> GUN = List.of("gun", "shot", "shoot", "rifle", "explosion");

    @Test
    void vanillaEntityStepClassifiedAsFootstep() {
        assertEquals(SoundPrintType.FOOTSTEP,
                SoundClassifier.classify("minecraft:entity.zombie.step", FOOT, GUN));
        assertEquals(SoundPrintType.FOOTSTEP,
                SoundClassifier.classify("minecraft:block.grass.step", FOOT, GUN));
        assertEquals(SoundPrintType.FOOTSTEP,
                SoundClassifier.classify("somemod:custom_footstep", FOOT, GUN));
    }

    @Test
    void weaponSoundsClassifiedAsGunshot() {
        for (String id : new String[]{
                "gwo:rifle.fire", "gwo:gunshot", "minecraft:entity.blaze.shoot",
                "somemod:pistol_shoot", "gwo:explosion_small"}) {
            assertEquals(SoundPrintType.GUNSHOT, SoundClassifier.classify(id, FOOT, GUN), id);
        }
    }

    @Test
    void unrelatedSoundsIgnored() {
        assertNull(SoundClassifier.classify("minecraft:music.menu", FOOT, GUN));
        assertNull(SoundClassifier.classify("minecraft:block.stone.place", FOOT, GUN));
        assertNull(SoundClassifier.classify("minecraft:entity.villager.ambient", FOOT, GUN));
        assertNull(SoundClassifier.classify(null, FOOT, GUN));
        assertNull(SoundClassifier.classify("", FOOT, GUN));
    }

    @Test
    void footstepWinsWhenIdMatchesBothTables() {
        // "step" 命中脚步且 "shot" 未出现；构造一个双命中的 id 验证脚步优先。
        List<String> gunWithStep = List.of("gunstep");
        assertEquals(SoundPrintType.FOOTSTEP,
                SoundClassifier.classify("mod:gunstep_sound", FOOT, gunWithStep));
    }

    @Test
    void keywordParsingTrimsLowercasesAndSkipsEmpty() {
        List<String> parsed = SoundClassifier.parseKeywords(" Step , FOOTSTEP ,,gun ");
        assertEquals(List.of("step", "footstep", "gun"), parsed);
        assertEquals(List.of(), SoundClassifier.parseKeywords(null));
        assertEquals(List.of(), SoundClassifier.parseKeywords("  ,  "));
    }

    @Test
    void mayRelateMatchesClassify() {
        assertEquals(SoundClassifier.classify("a.b.step", FOOT, GUN) != null,
                SoundClassifier.mayRelate("a.b.step", FOOT, GUN));
        assertEquals(false, SoundClassifier.mayRelate("a.b.place", FOOT, GUN));
    }
}
