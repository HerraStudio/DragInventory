package dev.draginventory.client.soundprint;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import org.junit.jupiter.api.Test;

/**
 * 聚合器两模式（用户决策：默认 merge 聚合合并，可切 stagger 并排错位）
 * 与去重 / wrap 边界 / 上限截断。
 */
class SoundPrintAggregatorTest {

    private static SoundPrintAggregator.Hit hit(float bearing, float energy,
                                                SoundPrintType type, float vOff, float dist) {
        return new SoundPrintAggregator.Hit(bearing, energy, type, vOff, dist);
    }

    // ==================== merge（默认） ====================

    @Test
    void mergeCombinesSourcesWithinWindow() {
        List<SoundPrintCluster> out = SoundPrintAggregator.aggregate(List.of(
                hit(50f, 0.5f, SoundPrintType.FOOTSTEP, -0.2f, 8f),
                hit(53f, 0.4f, SoundPrintType.FOOTSTEP, -0.4f, 12f)),
                false, 6f, 2f);
        assertEquals(1, out.size());
        SoundPrintCluster cluster = out.get(0);
        assertEquals(2, cluster.sourceCount());
        assertTrue(cluster.stagger() == false);
        // 能量 RMS 合成：sqrt(.25+.16) ≈ .64
        assertEquals(0.6403f, cluster.energy(), 0.01f);
        // 方位能量加权：偏向 50°。
        assertTrue(cluster.bearing() >= 50f && cluster.bearing() <= 53f);
        assertTrue(cluster.bearing() < 51.6f);
        // 垂直偏移能量加权。
        assertTrue(cluster.verticalOffset() < -0.2f && cluster.verticalOffset() > -0.4f);
        // 最近距离。
        assertEquals(8f, cluster.nearestDistance(), 1e-4);
    }

    @Test
    void mergeKeepsSeparateClustersBeyondWindow() {
        List<SoundPrintCluster> out = SoundPrintAggregator.aggregate(List.of(
                hit(20f, 0.5f, SoundPrintType.FOOTSTEP, 0f, 5f),
                hit(80f, 0.5f, SoundPrintType.FOOTSTEP, 0f, 5f)),
                false, 6f, 2f);
        assertEquals(2, out.size());
    }

    @Test
    void mergeWindowSeparationBoundary() {
        // 恰好 = 窗口：合并（<= 语义）。
        assertEquals(1, SoundPrintAggregator.aggregate(List.of(
                hit(10f, 0.5f, SoundPrintType.FOOTSTEP, 0f, 5f),
                hit(16f, 0.5f, SoundPrintType.FOOTSTEP, 0f, 5f)),
                false, 6f, 2f).size());
        // 窗口 + 1：分离。
        assertEquals(2, SoundPrintAggregator.aggregate(List.of(
                hit(10f, 0.5f, SoundPrintType.FOOTSTEP, 0f, 5f),
                hit(16.5f, 0.5f, SoundPrintType.FOOTSTEP, 0f, 5f)),
                false, 6f, 2f).size());
    }

    @Test
    void mergeWrapsGroupsAcrossNorth() {
        // 359° 与 1° 物理同向：排序后分居首尾，wrap 合并为一簇。
        List<SoundPrintCluster> out = SoundPrintAggregator.aggregate(List.of(
                hit(1f, 0.5f, SoundPrintType.FOOTSTEP, 0f, 5f),
                hit(359f, 0.5f, SoundPrintType.FOOTSTEP, 0f, 5f),
                hit(180f, 0.5f, SoundPrintType.FOOTSTEP, 0f, 5f)),
                false, 6f, 2f);
        assertEquals(2, out.size());
        boolean hasNorthCluster = out.stream().anyMatch(c -> c.sourceCount() == 2
                && Math.abs(c.bearing()) < 2f);
        assertTrue(hasNorthCluster, "359/1 should merge across north: " + out);
    }

    @Test
    void gunshotDominatesMergedClusterType() {
        // 脚步 + 枪声同方位：整簇红（威胁优先）。
        List<SoundPrintCluster> out = SoundPrintAggregator.aggregate(List.of(
                hit(100f, 0.6f, SoundPrintType.FOOTSTEP, 0f, 5f),
                hit(102f, 0.3f, SoundPrintType.GUNSHOT, 0f, 5f)),
                false, 6f, 2f);
        assertEquals(1, out.size());
        assertEquals(SoundPrintType.GUNSHOT, out.get(0).type());
    }

    // ==================== stagger（并排错位） ====================

    @Test
    void staggerKeepsMembersIndependent() {
        List<SoundPrintCluster> out = SoundPrintAggregator.aggregate(List.of(
                hit(40f, 0.5f, SoundPrintType.FOOTSTEP, -0.3f, 6f),
                hit(42f, 0.7f, SoundPrintType.GUNSHOT, 0.5f, 10f)),
                true, 6f, 2f);
        assertEquals(1, out.size());
        SoundPrintCluster cluster = out.get(0);
        assertTrue(cluster.stagger());
        assertEquals(2, cluster.members().size());
        assertEquals(2, cluster.sourceCount());
        // 各自保留类型与垂直偏移。
        assertTrue(cluster.members().stream()
                .anyMatch(m -> m.type() == SoundPrintType.GUNSHOT && m.verticalOffset() == 0.5f));
        assertTrue(cluster.members().stream()
                .anyMatch(m -> m.type() == SoundPrintType.FOOTSTEP && m.verticalOffset() == -0.3f));
        // 最响成员居中（slot 0），另一成员错开。
        SoundPrintCluster.Member loudest = cluster.members().get(0);
        assertEquals(0.7f, loudest.energy(), 1e-4);
        assertEquals(0f, loudest.staggerOffset(), 1e-4);
        assertEquals(2f, cluster.members().get(1).staggerOffset(), 1e-4);
        // 簇能量 = 成员最大值（整体透明度参考）。
        assertEquals(0.7f, cluster.energy(), 1e-4);
    }

    @Test
    void staggerMembersAlternateSymmetrically() {
        // 四成员错位序列：0, +s, -s, +2s（交替向外）。
        List<SoundPrintCluster> out = SoundPrintAggregator.aggregate(List.of(
                hit(10f, 0.9f, SoundPrintType.FOOTSTEP, 0f, 5f),
                hit(11f, 0.8f, SoundPrintType.FOOTSTEP, 0f, 5f),
                hit(12f, 0.7f, SoundPrintType.FOOTSTEP, 0f, 5f),
                hit(13f, 0.6f, SoundPrintType.FOOTSTEP, 0f, 5f)),
                true, 6f, 3f);
        assertEquals(1, out.size());
        List<SoundPrintCluster.Member> members = out.get(0).members();
        assertEquals(0f, members.get(0).staggerOffset(), 1e-4);
        assertEquals(3f, members.get(1).staggerOffset(), 1e-4);
        assertEquals(-3f, members.get(2).staggerOffset(), 1e-4);
        assertEquals(6f, members.get(3).staggerOffset(), 1e-4);
    }

    @Test
    void staggerStillGroupsByDirection() {
        // 不同方位的两族各成簇（错位只发生在族内）。
        List<SoundPrintCluster> out = SoundPrintAggregator.aggregate(List.of(
                hit(30f, 0.5f, SoundPrintType.FOOTSTEP, 0f, 5f),
                hit(31f, 0.5f, SoundPrintType.FOOTSTEP, 0f, 5f),
                hit(120f, 0.5f, SoundPrintType.FOOTSTEP, 0f, 5f)),
                true, 6f, 2f);
        assertEquals(2, out.size());
    }

    // ==================== 去重与上限 ====================

    @Test
    void clusterCountCappedByEnergy() {
        // 20 个分散声源 > 上限 16：保能量高的。
        java.util.List<SoundPrintAggregator.Hit> hits = new java.util.ArrayList<>();
        for (int i = 0; i < 20; i++) {
            hits.add(hit(i * 17f, i == 19 ? 0.99f : 0.05f + i * 0.001f,
                    SoundPrintType.FOOTSTEP, 0f, 5f));
        }
        List<SoundPrintCluster> out = SoundPrintAggregator.aggregate(hits, false, 6f, 2f);
        assertEquals(SoundPrintAggregator.MAX_CLUSTERS, out.size());
        // 最高能量簇在（0.99 那个）。
        assertTrue(out.stream().anyMatch(c -> c.energy() > 0.98f));
    }

    @Test
    void emptyInputYieldsEmptyOutput() {
        assertEquals(0, SoundPrintAggregator.aggregate(List.of(), false, 6f, 2f).size());
        assertEquals(0, SoundPrintAggregator.aggregate(List.of(), true, 6f, 2f).size());
    }
}
