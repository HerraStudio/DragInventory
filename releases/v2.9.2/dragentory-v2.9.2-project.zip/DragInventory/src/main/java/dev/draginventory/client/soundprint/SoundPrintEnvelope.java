package dev.draginventory.client.soundprint;

public final class SoundPrintEnvelope {
   private SoundPrintEnvelope() {
   }

   public static float bell(int i, int count) {
      if (count <= 1) {
         return 1.0F;
      } else {
         float center = (float)(count - 1) / 2.0F;
         float sigma = Math.max(0.8F, center / 1.6F);
         float d = ((float)i - center) / sigma;
         return (float)Math.exp((double)(-d * d));
      }
   }

   public static float[] asymmetryFactors(float asymmetry) {
      float a = clamp(asymmetry, -1.0F, 1.0F);
      float up = 1.0F + Math.max(0.0F, a) * 0.75F - Math.max(0.0F, -a) * 0.72F;
      float down = 1.0F + Math.max(0.0F, -a) * 0.75F - Math.max(0.0F, a) * 0.72F;
      return new float[]{Math.max(0.12F, up), Math.max(0.12F, down)};
   }

   public static float distanceDecay(float dist, float radius, float minDecay, boolean enabled) {
      if (!enabled) {
         return 1.0F;
      } else if (radius <= 0.01F) {
         return minDecay;
      } else {
         float t = clamp(dist / radius, 0.0F, 1.0F);
         return 1.0F - (1.0F - minDecay) * (float)Math.sqrt((double)t);
      }
   }

   public static float verticalOffset(double sourceY, double eyeY, boolean enabled) {
      return !enabled ? 0.0F : clamp((float)((sourceY - eyeY) / 4.0), -1.0F, 1.0F);
   }

   public static float arrowStrength(float verticalOffset) {
      float a = Math.abs(clamp(verticalOffset, -1.0F, 1.0F));
      if (a <= 0.22F) {
         return 0.0F;
      } else {
         return a >= 0.65F ? 1.0F : (a - 0.22F) / 0.43F;
      }
   }

   public static float mergeEnergy(float e1, float e2) {
      float merged = (float)Math.sqrt((double)(e1 * e1 + e2 * e2));
      return Math.min(1.0F, merged);
   }

   public static float weightedBearing(float[] bearings, float[] energies) {
      float sin = 0.0F;
      float cos = 0.0F;

      for (int i = 0; i < bearings.length; i++) {
         double rad = Math.toRadians((double)bearings[i]);
         sin += (float)Math.sin(rad) * energies[i];
         cos += (float)Math.cos(rad) * energies[i];
      }

      if (sin == 0.0F && cos == 0.0F) {
         return 0.0F;
      } else {
         float bearing = (float)Math.toDegrees(Math.atan2((double)sin, (double)cos));
         return bearing < 0.0F ? bearing + 360.0F : bearing;
      }
   }

   static float smoothstep(float t) {
      t = clamp(t, 0.0F, 1.0F);
      return t * t * (3.0F - 2.0F * t);
   }

   static float clamp(float v, float min, float max) {
      return v < min ? min : Math.min(v, max);
   }
}
