package dev.draginventory.client.soundprint;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.fml.event.config.ModConfigEvent;
import net.neoforged.fml.event.config.ModConfigEvent.Loading;
import net.neoforged.fml.event.config.ModConfigEvent.Reloading;
import net.neoforged.fml.event.config.ModConfigEvent.Unloading;

@EventBusSubscriber(
   modid = "draginventory",
   value = {Dist.CLIENT},
   bus = Bus.MOD
)
public final class SoundPrintConfigEvents {
   private SoundPrintConfigEvents() {
   }

   @SubscribeEvent
   public static void onConfigLoading(Loading event) {
      if (isSoundprintConfig(event)) {
         retuneShapeDefaults();
         SoundPrintConfig.onConfigReloaded();
      }
   }

   @SubscribeEvent
   public static void onConfigReloading(Reloading event) {
      if (isSoundprintConfig(event)) {
         SoundPrintConfig.onConfigReloaded();
      }
   }

   @SubscribeEvent
   public static void onConfigUnloading(Unloading event) {
      if (isSoundprintConfig(event)) {
         SoundPrintConfig.onConfigUnloaded();
      }
   }

   private static boolean isSoundprintConfig(ModConfigEvent event) {
      return SoundPrintConfig.fileName().equals(event.getConfig().getFileName());
   }

   private static void retuneShapeDefaults() {
      if (!(Boolean)SoundPrintConfig.SHAPE_RETUNED.get()) {
         if ((Integer)SoundPrintConfig.BAR_COUNT.get() == 9) {
            SoundPrintConfig.set(SoundPrintConfig.BAR_COUNT, 14);
         }

         if ((Integer)SoundPrintConfig.BAR_GAP.get() == 1) {
            SoundPrintConfig.set(SoundPrintConfig.BAR_GAP, 3);
         }

         SoundPrintConfig.set(SoundPrintConfig.SHAPE_RETUNED, true);
         SoundPrintConfig.flush();
      }
   }
}
