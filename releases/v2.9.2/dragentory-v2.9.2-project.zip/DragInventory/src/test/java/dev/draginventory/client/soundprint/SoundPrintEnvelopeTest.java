package dev.draginventory.client.soundprint;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** 声纹包络数学：钟形 / 垂直不对称 / 距离衰减 / 箭头阈值 / 能量合成 / 圆周加权。 */
class SoundPrintEnvelopeTest {

    @Test
    void bellPeaksAtCenterAndDecaysToEdges() {
        int n = 9;
        int center = 4;
        float centerValue = SoundPrintEnvelope.bell(center, n);
        assertEquals(1f, centerValue, 1e-4);
        // 两侧单调递减。
        for (int i = 1; i <= center; i++) {
            float inner = SoundPrintEnvelope.bell(center - i, n);
            float outer = SoundPrintEnvelope.bell(center + i, n);
            assertEquals(inner, outer, 1e-4); // 对称
            assertTrue(inner < SoundPrintEnvelope.bell(center - i + 1, n),
                    "bell should decay from center, i=" + i);
        }
        // 边缘条仍在可见阈值之上（快速退化簇不会全灭）。
        assertTrue(SoundPrintEnvelope.bell(0, n) > 0.05f);
        // 单条簇恒为中柱。
        assertEquals(1f, SoundPrintEnvelope.bell(0, 1), 1e-6);
    }

    @Test
    void asymmetryBoostsSourceSideAndSuppressesOtherSide() {
        // 水平声源：上下对称。
        float[] neutral = SoundPrintEnvelope.asymmetryFactors(0f);
        assertEquals(neutral[0], neutral[1], 1e-5);
        // 上方声源（正）：上排增强、下排压制。
        float[] up = SoundPrintEnvelope.asymmetryFactors(0.8f);
        assertTrue(up[0] > 1f);
        assertTrue(up[1] < 1f);
        assertTrue(up[1] >= 0.12f); // 压制有底：参考图 2 上排仍剩暗弱短条
        // 下方声源（负）：镜像。
        float[] down = SoundPrintEnvelope.asymmetryFactors(-0.8f);
        assertEquals(up[0], down[1], 1e-4);
        assertEquals(up[1], down[0], 1e-4);
        // 极值 clamp 不越界。
        float[] extreme = SoundPrintEnvelope.asymmetryFactors(5f);
        assertTrue(extreme[0] <= 1.75f + 1e-4);
        assertTrue(extreme[1] >= 0.12f - 1e-4);
    }

    @Test
    void distanceDecayFallsToFloorAtRadius() {
        assertEquals(1f, SoundPrintEnvelope.distanceDecay(0f, 20f, 0.2f, true), 1e-4);
        assertEquals(0.2f, SoundPrintEnvelope.distanceDecay(20f, 20f, 0.2f, true), 1e-4);
        assertEquals(0.2f, SoundPrintEnvelope.distanceDecay(99f, 20f, 0.2f, true), 1e-4);
        // 关闭衰减恒 1。
        assertEquals(1f, SoundPrintEnvelope.distanceDecay(19f, 20f, 0.2f, false), 1e-6);
        // 平方根曲线：四分之一半径处衰减小于线性。
        float quarter = SoundPrintEnvelope.distanceDecay(5f, 20f, 0f, true);
        assertEquals(1f - 0.5f, quarter, 1e-4); // sqrt(0.25) = 0.5
    }

    @Test
    void verticalOffsetScalesAndClamps() {
        // ±4 格满偏。
        assertEquals(1f, SoundPrintEnvelope.verticalOffset(4.5, 0.5, true), 1e-4);
        assertEquals(-1f, SoundPrintEnvelope.verticalOffset(-3.5, 0.5, true), 1e-4);
        assertEquals(0.25f, SoundPrintEnvelope.verticalOffset(1.5, 0.5, true), 1e-4);
        // 关闭联动恒 0（水平对称、无箭头）。
        assertEquals(0f, SoundPrintEnvelope.verticalOffset(9, 0, false), 1e-6);
        // 越界 clamp。
        assertEquals(1f, SoundPrintEnvelope.verticalOffset(20, 0, true), 1e-6);
    }

    @Test
    void arrowStrengthHasDeadZoneAndFullZone() {
        // 水平 / 轻微偏移：无箭头（参考图 1）。
        assertEquals(0f, SoundPrintEnvelope.arrowStrength(0f), 1e-6);
        assertEquals(0f, SoundPrintEnvelope.arrowStrength(0.2f), 1e-6);
        // 明确偏移：全显（参考图 2）。
        assertEquals(1f, SoundPrintEnvelope.arrowStrength(0.7f), 1e-6);
        assertEquals(1f, SoundPrintEnvelope.arrowStrength(-1f), 1e-6);
        // 中段单调淡入。
        float mid = SoundPrintEnvelope.arrowStrength(0.45f);
        assertTrue(mid > 0f && mid < 1f);
        assertTrue(SoundPrintEnvelope.arrowStrength(0.35f) < mid);
    }

    @Test
    void mergeEnergyRmsStyleCappedAtOne() {
        assertEquals(0.5f, SoundPrintEnvelope.mergeEnergy(0.3f, 0.4f), 1e-4); // sqrt(.09+.16)=.5
        assertEquals(1f, SoundPrintEnvelope.mergeEnergy(0.9f, 0.9f), 1e-6);  // cap
        assertTrue(SoundPrintEnvelope.mergeEnergy(0.3f, 0.4f) > 0.4f);       // 比 max 明显
        assertTrue(SoundPrintEnvelope.mergeEnergy(0.2f, 0.2f) < 0.4f);       // 比求和温和
    }

    @Test
    void weightedBearingWrapsAcrossNorth() {
        // 359° 与 1° 的能量加权中心应为 0°（而非 180°）。
        assertEquals(0f, SoundPrintEnvelope.weightedBearing(
                new float[]{359f, 1f}, new float[]{1f, 1f}), 0.5f);
        // 能量加权（向量平均，非线性插值）：0° 与 30° 按 1:3 -> atan2(sin·1+sin30·3, cos·1+cos30·3)
        // = atan2(1.5, 3.598) ≈ 22.6°，偏向强源但受圆周几何约束。
        assertEquals(22.63f, SoundPrintEnvelope.weightedBearing(
                new float[]{0f, 30f}, new float[]{1f, 3f}), 0.2f);
        // 全零向量安全返回。
        assertEquals(0f, SoundPrintEnvelope.weightedBearing(
                new float[]{90f, 270f}, new float[]{0f, 0f}), 1e-6);
    }
}
