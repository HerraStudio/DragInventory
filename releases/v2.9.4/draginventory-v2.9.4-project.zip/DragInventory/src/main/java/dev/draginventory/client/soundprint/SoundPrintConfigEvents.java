package dev.draginventory.client.soundprint;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.fml.event.config.ModConfigEvent;
import net.neoforged.fml.event.config.ModConfigEvent.Loading;
import net.neoforged.fml.event.config.ModConfigEvent.Reloading;
import net.neoforged.fml.event.config.ModConfigEvent.Unloading;

@EventBusSubscriber(
   modid = "draginventory",
   value = {Dist.CLIENT},
   bus = Bus.MOD
)
public final class SoundPrintConfigEvents {
   private SoundPrintConfigEvents() {
   }

   @SubscribeEvent
   public static void onConfigLoading(Loading event) {
      if (isSoundprintConfig(event)) {
         retuneShapeDefaults();
         retuneV294Defaults();
         SoundPrintConfig.onConfigReloaded();
      }
   }

   @SubscribeEvent
   public static void onConfigReloading(Reloading event) {
      if (isSoundprintConfig(event)) {
         SoundPrintConfig.onConfigReloaded();
      }
   }

   @SubscribeEvent
   public static void onConfigUnloading(Unloading event) {
      if (isSoundprintConfig(event)) {
         SoundPrintConfig.onConfigUnloaded();
      }
   }

   private static boolean isSoundprintConfig(ModConfigEvent event) {
      return SoundPrintConfig.fileName().equals(event.getConfig().getFileName());
   }

   private static void retuneShapeDefaults() {
      if (!(Boolean)SoundPrintConfig.SHAPE_RETUNED.get()) {
         if ((Integer)SoundPrintConfig.BAR_COUNT.get() == 9) {
            SoundPrintConfig.set(SoundPrintConfig.BAR_COUNT, 14);
         }

         if ((Integer)SoundPrintConfig.BAR_GAP.get() == 1) {
            SoundPrintConfig.set(SoundPrintConfig.BAR_GAP, 3);
         }

         SoundPrintConfig.set(SoundPrintConfig.SHAPE_RETUNED, true);
         SoundPrintConfig.flush();
      }
   }

   /**
    * v2.9.4 one-time default retune (same discipline as shape_retuned):
    * max_height 24 -> 30 and stack_alpha_gain 0.22 -> 0.30. Only values
    * still sitting at the OLD defaults are bumped, so any deliberate
    * customization survives; after this single pass the marker guards
    * future manual changes permanently.
    */
   private static void retuneV294Defaults() {
      if (!(Boolean)SoundPrintConfig.V294_RETUNED.get()) {
         if ((Integer)SoundPrintConfig.MAX_HEIGHT.get() == 24) {
            SoundPrintConfig.set(SoundPrintConfig.MAX_HEIGHT, 30);
         }

         if ((Double)(SoundPrintConfig.STACK_ALPHA_GAIN.get()) == 0.22D) {
            SoundPrintConfig.set(SoundPrintConfig.STACK_ALPHA_GAIN, 0.30D);
         }

         SoundPrintConfig.set(SoundPrintConfig.V294_RETUNED, true);
         SoundPrintConfig.flush();
      }
   }
}
