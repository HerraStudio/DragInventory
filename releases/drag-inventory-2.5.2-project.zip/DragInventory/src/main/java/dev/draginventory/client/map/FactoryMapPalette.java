package dev.draginventory.client.map;

import java.util.Locale;

/**
 * 彩色底图 + 预设滤镜管线（v2.5.0 起）。
 *
 * <p>底图不再使用固定语义色板，而是采样方块的 {@code MapColor} 真实颜色
 * （见 {@link FactoryMapSampler.Sample#color}），保留方块像素结构（1 方块 = 1 纹素）。
 * 滤镜从"三个自由滑条"改为<b>六选一预设样式</b>（{@link Style}），默认 {@link Style#NONE}
 * 即彩色原色不滤镜；其余样式对标各战术游戏的地图观感（三角洲 / 塔科夫 / 暗区 / Apex / PUBG）。</p>
 *
 * <p>烘焙管线（{@link #bake}）：
 * <ol>
 *   <li>{@link MapSemantics#VOID} → 全透明（配合底幕实现透明度语义）；</li>
 *   <li><b>语义恒定强调</b>（不受样式影响，保证战术可读性）：
 *       DOOR 向青绿混色、STAIR 向暖金混色、EDGE 各通道压暗；</li>
 *   <li>样式 ≠ NONE 时套用预设：亮度 LUT（contrast/brightness，256 项，样式变化时重建）
 *       → 饱和度灰度插值 → tint 混色 → WALL 墙体漂白（wallWhiten）。</li>
 * </ol>
 * 样式变化只需重建 LUT，256 个瓦片全量重烤也不产生逐像素乘除的 GC 与 CPU 压力。</p>
 */
final class FactoryMapPalette {

    /**
     * 滤镜预设样式。参数含义：
     * <ul>
     *   <li>{@code contrast / brightness} —— 亮度 LUT（围绕 0.5 中点缩放 + 平移）；</li>
     *   <li>{@code saturation} —— 饱和度（1 = 原样，0 = 全灰，&gt;1 增饱和）；</li>
     *   <li>{@code tint / tintAmount} —— 整体染色（ARGB 颜色 + 混色强度，tint = 0 不染）；</li>
     *   <li>{@code wallWhiten} —— WALL 语义向浅白靠拢的强度（对标参考图中的浅白建筑）。</li>
     * </ul>
     */
    enum Style {
        /** 彩色原色，不套滤镜（默认）。 */
        NONE(1.0, 0.0, 1.0, 0, 0.0, 0),
        /** 三角洲：深色去饱和 + 浅白建筑。 */
        DELTA(1.30, -0.10, 0.18, 0xFF0E141A, 0.10, 0.55),
        /** 塔科夫：亮纸面蓝图。 */
        TARKOV(1.18, 0.10, 0.30, 0xFFD8D2C4, 0.12, 0.35),
        /** 暗区：暗绿夜视。 */
        DARKZONE(1.25, -0.06, 0.35, 0xFF0F2B22, 0.22, 0.25),
        /** Apex：明亮干净。 */
        APEX(1.10, 0.05, 1.15, 0, 0.0, 0),
        /** PUBG：卫星遥感。 */
        PUBG(1.18, 0.02, 0.72, 0xFF2A2A20, 0.12, 0);

        /** 对比度（围绕 0.5 中点缩放）。 */
        final double contrast;
        /** 亮度偏移。 */
        final double brightness;
        /** 饱和度（1 = 原样）。 */
        final double saturation;
        /** 整体染色（ARGB）；0 = 不染色。 */
        final int tint;
        /** 染色强度（0..1）。 */
        final double tintAmount;
        /** WALL 语义漂白强度（0..1）。 */
        final double wallWhiten;

        Style(double contrast, double brightness, double saturation, int tint, double tintAmount, double wallWhiten) {
            this.contrast = contrast;
            this.brightness = brightness;
            this.saturation = saturation;
            this.tint = tint;
            this.tintAmount = tintAmount;
            this.wallWhiten = wallWhiten;
        }
    }

    /**
     * 配置 id → 样式。未知 / null 值一律回退 {@link Style#NONE}
     * （彩色原色不滤镜，保证配置文件被手改坏时地图仍可用）。
     */
    static Style styleFromId(String id) {
        if (id == null) return Style.NONE;
        try {
            return Style.valueOf(id.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            return Style.NONE;
        }
    }

    private final int[] lut = new int[256];
    private Style style = Style.NONE;
    private boolean dirty = true;

    // ==================== 语义基础色 ====================

    /** 语义 → 基础色（未滤镜）。采样回退（方块无 MapColor 时）与 UI 图例的统一源头。 */
    static int baseColor(MapSemantics s) {
        return switch (s) {
            case VOID -> 0xFF0D141A;
            case WALL -> 0xFFD5DCE0;   // 浅白建筑——参考图中建筑以白色块呈现
            case FLOOR -> 0xFF39424A;
            case EDGE -> 0xFF7F939B;
            case STAIR -> 0xFFC9A45C;  // 暖金楼梯
            case DOOR -> 0xFF3FBF9A;   // 青绿主题色（与 HERRA HUD 统一）
            case WATER -> 0xFF17303F;  // 深蓝黑水体
            case BLOCKED -> 0xFF161F26;
            case DECOR -> 0xFF2A3A31;
        };
    }

    /** 语义 → 基础色（未滤镜，图例用）。实例方法转发静态色表（保留既有调用点）。 */
    public int color(MapSemantics s) {
        return baseColor(s);
    }

    /** 语义 → 未滤镜的图例色（图例展示语义本身的颜色，不受当前滤镜影响）。 */
    public int legendColor(MapSemantics s) {
        return color(s);
    }

    // ==================== 烘焙主入口 ====================

    /**
     * 新主入口：语义 + 方块真实颜色 → 最终烘焙色。
     *
     * @param s         语义分类（VOID → 全透明 0x00000000，配合底幕实现透明度语义）
     * @param baseColor 采样到的方块颜色（ARGB；无采样色时为语义基础色）
     * @return ARGB 烘焙色（非 VOID 恒不透明；VOID 恒全透明）
     */
    public int bake(MapSemantics s, int baseColor) {
        if (s == MapSemantics.VOID) return 0x00000000;
        int r = baseColor >>> 16 & 0xFF;
        int g = baseColor >>> 8 & 0xFF;
        int b = baseColor & 0xFF;

        // 1) 语义恒定强调（不受样式影响，保证战术可读性）：
        //    DOOR 青绿出入点、STAIR 暖金垂直连接、EDGE 压暗描边。
        if (s == MapSemantics.DOOR) {
            r = mix(r, 0x35, 0.45);
            g = mix(g, 0xD8, 0.45);
            b = mix(b, 0xA0, 0.45);
        } else if (s == MapSemantics.STAIR) {
            r = mix(r, 0xE0, 0.30);
            g = mix(g, 0xB0, 0.30);
            b = mix(b, 0x60, 0.30);
        } else if (s == MapSemantics.EDGE) {
            r = scale(r, 0.78);
            g = scale(g, 0.78);
            b = scale(b, 0.78);
        }

        // 2) 预设滤镜（NONE 直通，即彩色原色）。
        if (style != Style.NONE) {
            if (dirty) rebuildLut();
            r = lut[r];
            g = lut[g];
            b = lut[b];
            // 饱和度：向灰度插值（sat > 1 时向外推，公式对称）。
            int gray = (int) Math.round(r * 0.299 + g * 0.587 + b * 0.114);
            r = clamp(gray + (r - gray) * style.saturation);
            g = clamp(gray + (g - gray) * style.saturation);
            b = clamp(gray + (b - gray) * style.saturation);
            // 整体染色。
            if (style.tint != 0) {
                r = mix(r, style.tint >>> 16 & 0xFF, style.tintAmount);
                g = mix(g, style.tint >>> 8 & 0xFF, style.tintAmount);
                b = mix(b, style.tint & 0xFF, style.tintAmount);
            }
            // 墙体漂白：WALL 语义向浅白靠拢（对标参考图的浅白建筑）。
            if (style.wallWhiten > 0 && s == MapSemantics.WALL) {
                r = mix(r, 0xE8, style.wallWhiten);
                g = mix(g, 0xEE, style.wallWhiten);
                b = mix(b, 0xF2, style.wallWhiten);
            }
        }

        return 0xFF000000 | clamp(r) << 16 | clamp(g) << 8 | clamp(b);
    }

    /** 上下层叠加时的透明度（alpha 字节值）：上层墙体轮廓、下层地面淡显。 */
    public int overlayAlpha(MapSemantics s) {
        return switch (s) {
            case WALL -> 0x2E;
            case FLOOR, EDGE, DOOR, STAIR -> 0x18;
            default -> 0;
        };
    }

    // ==================== 状态 ====================

    /** 切换滤镜预设；与当前不同才置脏（值不变零开销，渲染器每帧调用）。 */
    public void setStyle(Style style) {
        if (style == null) style = Style.NONE;
        if (style != this.style) {
            this.style = style;
            dirty = true;
        }
    }

    /** 标记全部瓦片需重烤（签名变化时由渲染器调用）。 */
    public void markDirty() { dirty = true; }

    /** 当前样式（测试与设置界面读取）。 */
    public Style style() { return style; }

    // ==================== 辅助 ====================

    /**
     * 单通道混色：{@code a + (b - a) * t}，四舍五入后钳制 0..255。
     * （色板保持纯 JVM 可测：不引用 Minecraft 类，钳制用本地实现。）
     */
    private static int mix(int a, int b, double t) {
        return clamp(a + (b - a) * t);
    }

    /** 单通道缩放（EDGE 压暗等），四舍五入后钳制 0..255。 */
    private static int scale(int v, double factor) {
        return clamp(v * factor);
    }

    /** 浮点 → 钳制到 0..255 的字节值（四舍五入）。 */
    private static int clamp(double v) {
        int i = (int) Math.round(v);
        return i < 0 ? 0 : Math.min(i, 255);
    }

    /** 亮度 LUT：对比度围绕 0.5 中点缩放 + 亮度平移。样式变化时重建（256 项）。 */
    private void rebuildLut() {
        for (int v = 0; v < 256; v++) {
            double d = (v / 255.0 - 0.5) * style.contrast + 0.5 + style.brightness;
            lut[v] = clamp(d * 255.0);
        }
        dirty = false;
    }
}
