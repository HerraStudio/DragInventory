package dev.draginventory.client.map;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

public final class FactoryMapKeyBindings {
    public static final KeyMapping OPEN_MAP = new KeyMapping(
            "key.draginventory.map",
            GLFW.GLFW_KEY_M,
            "key.categories.draginventory");

    /** 清除全部地图标点（反馈⑧：清屏外也可一键清除）。 */
    public static final KeyMapping CLEAR_MARKERS = new KeyMapping(
            "key.draginventory.map_clear_markers",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C,
            "key.categories.draginventory");

    /** 大地图 HUD（清屏模式）开关——地图内 H 键与右下角提示共用同一绑定。 */
    public static final KeyMapping TOGGLE_MAP_HUD = new KeyMapping(
            "key.draginventory.map_hud",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H,
            "key.categories.draginventory");

    private FactoryMapKeyBindings() {}

    @EventBusSubscriber(modid = "draginventory", value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
    public static final class Registrar {
        private Registrar() {}

        @SubscribeEvent
        public static void register(RegisterKeyMappingsEvent event) {
            event.register(OPEN_MAP);
            event.register(CLEAR_MARKERS);
            event.register(TOGGLE_MAP_HUD);
        }
    }
}
