# 战术地图

全屏动态战术地图：彩色底图按真实方块颜色实时采样成图（Xaero 世界地图风格），打开默认完整界面（可在设置视觉页开启“打开时进入清屏模式”只显示地图、玩家与标点，`H` 随时切换）；左上角常驻方形小地图随楼层跟随。底图不预渲染、不绑定固定区域——任意已加载地形都能即时成图。

## 动态绘制架构

- **瓦片化**：世界按 64×64 格切成瓦片（4×4 区块），每张瓦片一张 64×64 纹理（1 方块 = 1 纹素，保留像素结构）。只烘焙覆盖视口的瓦片（外扩一圈），视野拉多远都不受固定范围限制。
- **分帧渐进烘焙**：每瓦片每帧推进 16 行（4 帧烤完一张）；活动层每帧最多烘焙 3 张、上下叠加层各 1 张，每帧采样上限约 4k 格（旧全图方案为 65536 格/帧），未烤区域保持透明、透出底幕，画面随烘焙渐进清晰。
- **LRU 瓦片池**：各楼层共用 256 张容量（约 4MB 显存）的访问序缓存，超限淘汰并释放纹理。瓦片键含楼层 Y，切层不主动失效——切回旧层立即命中。
- **彩色采样**：分类的同时读取方块原版地图色（`getMapColor`，ABGR→ARGB 转换），以真实颜色写入瓦片；语义分类只保留战术强调——房门青绿、楼梯金黄、边界压暗，深坑与阻挡自动变暗，其余一律方块本色。滤镜不再是逐项参数，而是六种预设（关闭=彩色 / 三角洲 / 塔科夫 / 暗区突围 / Apex / PUBG）驱动色板 LUT，切预设全量重烤。
- **语义 9 类**：每格分类为 未知/墙体/地面/边界/楼梯/房门/水体/阻挡/装饰，按固定优先级判定；图层开关直接决定哪些语义参与烘焙，未加载区域画全透明 VOID。
- **动态楼层扫描**：玩家移动时每 40 tick、静止时每 200 tick（v2.5.1 降频防周期性卡帧）、或水平移动超过 32 格时重建楼层目录（半径 `behavior.scan_radius`，默认 256 格）；相近楼面按 |ΔY| ≤ 3 合并，最多 16 层；楼层 id = floorY（跨目录重建稳定），自动换层带死区 + 迟滞双防抖。目录写入共享缓存，小地图据此与大地图对齐同一层。
- **楼层恒定自动跟随**（v2.5.2）：手动层模式已整体移除，活动层永远跟随玩家所在楼面，层高跨度一半作为切换死区（上下楼梯不闪跳）。视野中心被钳制在目录范围 ±96 格内，允许略微出界平移。

## 布局说明

- **清屏模式（`general.clean_on_open`，v2.5.1 起默认关）**：开启后开图只绘制底幕、瓦片、网格、楼梯连接点、标点与玩家箭头，右下角小字提示“按 H 显示界面”；按 `H` 或右侧眼睛按钮切换到完整 HUD，任何模式下均可切换，标点不受清屏影响。
- **顶栏**：当前楼层 Y 大字 + 楼层标签组（最多 6 枚，活动层高亮）+ 中央北向指示 + 右上 18px 关闭按钮（v2.5.2 移除自动/手动徽标）。
- **右侧图标工具栏**（4 枚，18×18 像素；v2.5.2 移除上层/下层两键）：图例与标点管理（弹窗开关，激活态高亮）、清屏切换（眼睛）、定位（回玩家）、设置（打开地图设置 GUI）。
- **图例+标点管理弹窗**（v2.5.2 从画布左侧伸出）：工具栏首键唤出，210×240 战术面板，开启时 180ms 从左侧滑入，位置对标 2.4.0 的左侧面板但占位更小。上半部为八语义图例（色块+名称，两列四行）；下半部为标点管理——地点/敌情/物资三种类型行（含各类型当前数量徽标，点击或数字键 1/2/3 选为当前放置类型）、“显示标点”开关与“清除全部标点”按钮。
- **右下角**：缩放按钮对、按当前缩放自适应的比例尺、悬停坐标与缩放百分比读数；完整快捷键说明缩小后收在这里（0.7 缩放小字，键名随用户改键动态显示）。
- **常驻小地图**：左上角方形 HUD（`minimap` 组可开关，64~256 像素），跟随玩家所在楼层渲染同源彩色瓦片，缩放 0.5~4.0 可调；楼层与大地图共享同一目录、显示同一层（v2.5.2），异常熔断可恢复（10 秒冷却重试、换世界自动复位）。玩家箭头随朝向旋转，顶部北向指示，深色边框 + 四角青绿角标。下方居中显示“对局还有 X 结束”倒计时（默认 10:00 占位，`MapMatchTimer` 接口供对局系统接入真实剩余时间）。打开任意界面（含大地图）或 F1 时自动隐藏，`/map off` 连同关闭。
- **地图设置 GUI**：五页签（楼层/图层/视觉/行为/标点）单屏收纳全部选项，顶部为实时预览——左侧迷你地图（独立坐标变换，不污染地图会话）+ 右侧九语义色样例（对应图层关闭的语义画未知色并加红色小斜杠）+ 底部不透明度与滤镜读数。视觉页为六滤镜预设块，行为页含小地图开关/缩放/尺寸（v2.5.2 重排后尺寸滑条完整可见）。改动经防抖落盘，关屏兜底立即写盘。
- 窗口变小或 GUI 比例提高时，整套界面按画布等比缩小，命中区域与显示像素一一对应（小于 640×360 时整体缩小）。

## 操作

- `M` 打开或关闭，`Esc` 关闭；`H` 在清屏与完整界面间切换（默认开完整界面，`clean_on_open` 可改为默认清屏）；不暂停游戏。全部快捷键均为主键盘核心键区可打出的键（M/ESC/H/C/1/2/3/空格），不依赖数字小键盘、PageUp/PageDown/Home 等扩展键区（60% 小配列键盘友好；小键盘数字不响应，1/2/3 以主键盘为准）。
- 左键拖动平移；滚轮以鼠标位置为锚缩放（清屏模式下满屏可用）；空格或「定位」回到玩家。
- 右键在已加载地形上放置当前类型的地图标点（地点/敌情/物资），数字键 `1`/`2`/`3` 切换类型并弹出底部反馈通知（弹窗内亦可点选，快捷键说明中已列出）；`C` 一键清除全部地图标点（有/无标点均有底部反馈），大地图内或游戏内按均有效。标点与世界 HUD 共用 5 个名额、60 秒生命周期，清屏模式下仍绘制（标点不随界面隐藏）。
- 楼层恒定自动跟随玩家所在层（v2.5.2 移除 PgUp/PgDn/Home 手动调层键与手动层功能），换层有顶部闪烁提示。
- 地形外观由当前世界决定；未加载区域保持底幕色且不能添加标记。截图里的工厂是隔离测试场景，未随模组添加到玩家世界。

## 指令参考

`/herramap` 与 `/map` 为等价完整子树，`/m` 为快捷别名；三条根指令无参均直接打开大地图（v2.5.0 起），`/map gui` 打开设置界面。全部为客户端指令，无需权限；非法参数直接报错并列出合法值。

| 指令 | 说明 |
| --- | --- |
| `/m`、`/map`、`/herramap`（无参） | 直接打开大地图 |
| `/map gui` | 打开地图设置界面（与地图工具栏设置按钮同入口） |
| `/map toggle` / `on` / `off` | 总开关（控制 M 键、大地图与小地图显示） |
| `/map span <1..16>` | 层高跨度（自动层切换死区 ±span/2，v2.5.2 起楼层恒定自动跟随） |
| `/map layer list` | 汇总显示 8 个图层开关状态 |
| `/map layer <id> <on\|off>` | 单独开关图层（id：walls / floor / water / stairs / doors / decor / upper / lower） |
| `/map opacity <0.3..1.0>` | 地图整体不透明度（低不透明度可透出游戏世界） |
| `/map filter` | 显示当前滤镜预设 |
| `/map filter <id>` | 滤镜预设六选一（none 彩色 / delta 三角洲 / tarkov 塔科夫 / darkzone 暗区突围 / apex / pubg） |
| `/map grid <on\|off>` | 网格线 |
| `/map minimap` | 显示小地图当前状态 |
| `/map minimap on` / `off` | 常驻小地图开关 |
| `/map minimap zoom <0.5..4.0>` | 小地图缩放 |
| `/map minimap size <64..256>` | 小地图边长（像素） |
| `/map radius <64..512>` | 楼层扫描半径（格） |
| `/map zoom min <0.2..1.0>` | 最小缩放 |
| `/map zoom max <2.0..16.0>` | 最大缩放 |
| `/map zoom reset` | 缩放范围回默认（0.25 / 8.0） |
| `/map follow <on\|off>` | 打开地图时居中玩家（关闭时记忆上次视野） |
| `/map marker style <tactical\|minimal>` | 标点风格 |
| `/map marker ping <location\|enemy\|item>` | 右键放置的标点类型 |
| `/map marker show <on\|off>` | 地图上是否显示标点 |
| `/map marker distance <on\|off>` | 标点距离标注 |
| `/map marker countdown <on\|off>` | 标点倒计时 |
| `/map reset` | 全部恢复默认 |
| `/map info` | 一条消息汇总（模式/楼层/滤镜/不透明度/小地图/标点/图层/缩放/扫描半径） |

已移除 `/map contrast` / `brightness` / `saturation`（滤镜改为预设制，见 `/map filter`）。

## 配置文件

客户端配置 `config/draginventory-map-client.toml`，修改后立即生效，外部编辑由 NeoForge 自动热重载；指令与设置 GUI 的改动经 500ms 防抖落盘（写前日志对抗保存竞态，退出世界时兜底写盘）。

| 组 | 键 | 默认 | 说明 |
| --- | --- | --- | --- |
| general | `enabled` | true | 总开关（控制 M 键、大地图与小地图显示，v2.5.0 起生效） |
| general | `layer_span` | 4 | 层高跨度（1~16；自动层切换死区 ±span/2；v2.5.2 移除 auto_floor/manual_floor_y，楼层恒定自动跟随） |
| general | `clean_on_open` | false | 打开大地图时进入清屏模式（v2.5.1 新增，默认关；地图内 H 随时切换） |
| general | `migrated` | false | 配置迁移标记（v2.5.1 内部键，首次加载自动置位，无需手动修改） |
| layers | `show_walls` / `show_floor` / `show_water` / `show_stairs` / `show_doors` | true | 墙体/地面/水体/楼梯/房门图层 |
| layers | `show_decor` | false | 地面装饰（信息量低，默认关） |
| layers | `show_upper` / `show_lower` | true | 上层墙体轮廓叠加 / 下层地面淡显 |
| vision | `opacity` | 0.95 | 整体不透明度（0.3~1.0，低不透明度透出游戏世界） |
| vision | `filter_style` | none | 滤镜预设（none 彩色 / delta / tarkov / darkzone / apex / pubg） |
| vision | `grid` | true | 网格线 |
| minimap | `enabled` | true | 左上角常驻小地图开关 |
| minimap | `zoom` | 2.0 | 小地图缩放（0.5~4.0，每格方块对应的像素数） |
| minimap | `size` | 128 | 小地图边长（64~256 像素） |
| behavior | `scan_radius` | 256 | 楼层扫描半径（64~512 格） |
| behavior | `zoom_min` / `zoom_max` | 0.25 / 8.0 | 缩放范围 |
| behavior | `follow_player` | true | 打开时居中玩家（关闭时记忆上次视野） |
| markers | `marker_style` | tactical | 标点风格（tactical / minimal） |
| markers | `visible` | true | 地图上是否显示标点 |
| markers | `ping_type` | location | 右键放置的标点类型（location / enemy / item） |
| markers | `show_distances` / `show_countdown` | true | 距离标注 / 倒计时 |

v2.5.1 配置迁移：新增 `general.migrated` 标记（内部键），首次加载时把旧版残留的 `enabled = false` 复位为开启后置位——与文件结构无关的一次性迁移，修复 2.5.0 重发版迁移在玩家运行过任一版 2.5.0 后失效的问题；此后主动执行的 `/map off` 被尊重。新增 `general.clean_on_open`（默认 false）。

v2.5.0 配置迁移：删除 `vision.contrast` / `vision.brightness` / `vision.saturation`（并入 `filter_style` 预设），新增 `vision.filter_style`、`minimap` 组三键与 `markers.visible` / `markers.ping_type`。

## 开发验证

```powershell
.\gradlew.bat test build
.\gradlew.bat runClient -PmapSmoke -PweaponGameDir=run-map-redesign
.\gradlew.bat clean test build
```

`mapSmoke` 仅用于隔离验证，自动创建测试世界并生成工厂建筑，沿 v2.5.2 新流程检查：开图（默认完整界面，`clean_on_open` 为 false；截图 `factory_map_hud`）→ 缩放拖拽与清屏右键放点、空格居中 → 数字键 1/2/3 放三种标点并确认底部反馈（`factory_map_pings`）→ 图例弹窗从左侧伸出（`factory_map_legend`）→ `H` 切清屏（`factory_map_clean`）→ 已移除的手动调层键（PgUp/PgDn）不再影响自动楼层（`factory_map_floor`）→ GUI 4 倍缩放下 18px 按钮命中（`factory_map_scale4`）→ 关闭释放瓦片池后重开。正式构建不要传入此参数。色板与滤镜预设有 `FactoryMapPaletteTest` 单元测试（VOID 透明、语义强调、预设 LUT、样式切换）。

源码：`src/main/java/dev/draginventory/client/map/`。中文与英文文字位于各语言 JSON；绘制词汇集中在 `FactoryMapUI`，采样、瓦片与色板分别在 `FactoryMapSampler`、`FactoryMapTiles`、`FactoryMapPalette`（六滤镜预设），常驻小地图在 `FactoryMinimapHud`（对局计时接口 `MapMatchTimer`），坐标变换在 `MapCoordinateTransform`，配置在 `MapConfig`。
