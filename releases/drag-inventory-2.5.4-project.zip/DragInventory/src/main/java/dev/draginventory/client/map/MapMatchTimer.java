package dev.draginventory.client.map;

import java.util.Locale;

/**
 * 对局剩余时间接口（对局系统的接入点，预留模式）。
 *
 * <p>与 {@link MapPoiProvider} 同属"对局系统上线前预留"的模式：小地图 HUD
 * （{@code FactoryMinimapHud}）每帧经 {@link #format} 读取剩余时间并显示在
 * 小地图下方（语言键 {@code draginventory.map.match_timer}）。对局系统实装后
 * 实现 {@link Provider} 并调用 {@link #register} 注册即可，地图/小地图自动改用
 * 真实值，无需改任何渲染代码；未注册期间固定显示占位值
 * {@link #DEFAULT_REMAINING_SECONDS}（10:00）。</p>
 */
public final class MapMatchTimer {
    /** 对局系统实现此接口提供剩余秒数；注册后地图/小地图自动改用真实值。 */
    public interface Provider { long remainingSeconds(); }

    /** 占位剩余秒数（10 分钟）：对局系统未实装期间的显示值。 */
    public static final long DEFAULT_REMAINING_SECONDS = 600L;

    private static volatile Provider provider;

    private MapMatchTimer() {}

    /** 注册提供者（对局系统启动时调用一次）。 */
    public static void register(Provider p) { provider = p; }

    /**
     * 剩余秒数：未注册返回默认占位；注册后取 provider 值并夹到 &ge;0
     * （对局系统提前结束/溢出时不会显示负数）。
     */
    public static long remainingSeconds() {
        Provider p = provider;
        if (p == null) return DEFAULT_REMAINING_SECONDS;
        long seconds = p.remainingSeconds();
        return Math.max(0L, seconds);
    }

    /** "m:ss" 格式（如 9:59 / 10:00；超过一小时进位为 61:05 形式）。 */
    public static String format() {
        long seconds = remainingSeconds();
        return seconds / 60 + ":" + String.format(Locale.ROOT, "%02d", seconds % 60);
    }
}
