package dev.draginventory.client.soundprint;

import com.lowdragmc.lowdraglib2.gui.ui.UIElement;
import com.lowdragmc.lowdraglib2.gui.ui.rendering.GUIContext;
import dev.draginventory.client.compass.CompassConfig;
import dev.draginventory.client.compass.CompassHeading;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public final class SoundPrintWidget extends UIElement {
   private final CompassHeading heading = CompassHeading.create();
   private final boolean preview;
   private float previewHeadingTarget = 30.0F;
   private float previewBase = 30.0F;
   private boolean sway = true;
   private boolean wasVisible;
   private long entryStart = Long.MIN_VALUE;
   private long lastFrameMillis = Long.MIN_VALUE;
   private Player displayedPlayer;
   private boolean frameVisible;
   private float entryProgress = 1.0F;
   private float frameHeading;
   private float halfRange;
   private float edgeHalfWidth;
   private List<SoundPrintCluster> clusters = List.of();
   private float effectiveScale = 1.0F;

   public SoundPrintWidget(boolean preview) {
      this.preview = preview;
   }

   public void setSway(boolean sway) {
      this.sway = sway;
      this.previewBase = this.previewHeadingTarget;
   }

   private void updateState(GUIContext context) {
      Minecraft mc = Minecraft.getInstance();
      long now = System.currentTimeMillis();
      float seconds = this.secondsSinceLastFrame(now);
      boolean visible = this.computeVisible(mc);
      if (visible && !this.wasVisible) {
         this.entryStart = now;
      }

      this.wasVisible = visible;
      this.frameVisible = visible;
      if (!visible) {
         this.clusters = List.of();
      } else {
         this.entryProgress = this.entryProgress(now);
         float target;
         if (this.preview) {
            if (this.sway) {
               this.previewHeadingTarget = Mth.wrapDegrees(this.previewBase + 26.0F * (float)Math.sin((double)now / 3600.0));
               if (this.previewHeadingTarget < 0.0F) {
                  this.previewHeadingTarget += 360.0F;
               }
            }

            target = this.previewHeadingTarget;
         } else {
            Player player = mc.player;
            if (player == null) {
               this.clusters = List.of();
               return;
            }

            if (this.displayedPlayer != player) {
               this.displayedPlayer = player;
               this.heading.snapTo(CompassHeading.toHeading(player.getYRot()));
            }

            target = CompassHeading.toHeading(player.getViewYRot(context.partialTick));
         }

         this.heading.step(target, seconds, (float)((Double)CompassConfig.SMOOTHNESS.get()).doubleValue(), 0.0F);
         this.frameHeading = this.heading.smooth();
         this.halfRange = (float)((Integer)CompassConfig.RANGE.get()).intValue() / 2.0F;
         this.edgeHalfWidth = this.halfRange + 8.0F;
         List<SoundPrintAggregator.Hit> hits;
         if (this.preview) {
            hits = this.previewHits(now);
         } else {
            LocalPlayer playerx = mc.player;
            Vec3 eye = playerx.getEyePosition(context.partialTick);
            hits = SoundPrintEvents.TRACKER.frameHits(eye.x, eye.y, eye.z, (Boolean)SoundPrintConfig.VERTICAL_OFFSET.get());
         }

         this.clusters = SoundPrintAggregator.aggregate(
            hits,
            SoundPrintConfig.staggerMode(),
            (float)((Integer)SoundPrintConfig.MERGE_WINDOW.get()).intValue(),
            (float)((Integer)SoundPrintConfig.STAGGER_SPACING.get()).intValue()
         );
         this.effectiveScale = (float)((Double)SoundPrintConfig.SCALE.get()).doubleValue();
      }
   }

   private float secondsSinceLastFrame(long now) {
      if (this.lastFrameMillis == Long.MIN_VALUE) {
         this.lastFrameMillis = now;
         return 0.016F;
      } else {
         float seconds = (float)(now - this.lastFrameMillis) / 1000.0F;
         this.lastFrameMillis = now;
         return Mth.clamp(seconds, 0.0F, 0.1F);
      }
   }

   private float entryProgress(long now) {
      if (this.entryStart == Long.MIN_VALUE) {
         return 1.0F;
      } else {
         float p = (float)(now - this.entryStart) / 180.0F;
         if (p >= 1.0F) {
            this.entryStart = Long.MIN_VALUE;
            return 1.0F;
         } else {
            return 1.0F - (1.0F - p) * (1.0F - p);
         }
      }
   }

   private boolean computeVisible(Minecraft mc) {
      if (this.preview) {
         return true;
      } else if (!(Boolean)SoundPrintConfig.ENABLED.get()) {
         return false;
      } else if (!mc.options.hideGui && mc.level != null) {
         if (!(mc.getCameraEntity() instanceof Player camera) || camera.isSpectator()) {
            return false;
         }

         if (!(Boolean)SoundPrintConfig.FOLLOW_COMPASS.get()) {
            return true;
         } else {
            boolean debugOpen = isDebugScreenOpen(mc);
            return (Boolean)CompassConfig.ENABLED.get() && (!(Boolean)CompassConfig.HIDE_WITH_DEBUG.get() || !debugOpen);
         }
      } else {
         return false;
      }
   }

   private static boolean isDebugScreenOpen(Minecraft mc) {
      try {
         return mc.gui.getDebugOverlay().showDebugScreen();
      } catch (RuntimeException var2) {
         return false;
      }
   }

   public void drawBackgroundTexture(GUIContext context) {
      if (!this.preview) {
         this.updateState(context);
      }
   }

   public void drawBackgroundAdditional(GUIContext context) {
      if (!this.preview) {
         if (this.frameVisible && !this.clusters.isEmpty()) {
            GuiGraphics g = context.graphics;
            float width = this.getSizeWidth();
            float centerX = this.getPositionX() + width / 2.0F;
            // Baseline sits at the widget's vertical center so bars extend symmetrically
            // and never climb into the compass strip above.
            float baselineY = this.getPositionY() + this.getSizeHeight() / 2.0F + 1.0F;
            long now = System.currentTimeMillis();
            g.pose().pushPose();

            try {
               this.applyScale(g, centerX);
               this.drawSoundprint(g, this.getPositionX(), baselineY, width, centerX, now);
            } finally {
               g.pose().popPose();
            }
         }
      }
   }

   void renderStandalone(GuiGraphics g, float x, float y, float width, long now, float scaleOverride) {
      float seconds = this.lastFrameMillis == Long.MIN_VALUE ? 0.016F : Mth.clamp((float)(now - this.lastFrameMillis) / 1000.0F, 0.0F, 0.1F);
      this.lastFrameMillis = now;
      if (this.sway) {
         this.previewHeadingTarget = Mth.wrapDegrees(this.previewBase + 26.0F * (float)Math.sin((double)now / 3600.0));
         if (this.previewHeadingTarget < 0.0F) {
            this.previewHeadingTarget += 360.0F;
         }
      }

      this.heading.step(this.previewHeadingTarget, seconds, 15.0F, 0.0F);
      this.frameHeading = this.heading.smooth();
      this.halfRange = (float)((Integer)CompassConfig.RANGE.get()).intValue() / 2.0F;
      this.edgeHalfWidth = this.halfRange + 8.0F;
      this.clusters = SoundPrintAggregator.aggregate(
         this.previewHits(now),
         SoundPrintConfig.staggerMode(),
         (float)((Integer)SoundPrintConfig.MERGE_WINDOW.get()).intValue(),
         (float)((Integer)SoundPrintConfig.STAGGER_SPACING.get()).intValue()
      );
      this.entryProgress = 1.0F;
      this.effectiveScale = scaleOverride;
      if (!this.clusters.isEmpty()) {
         g.pose().pushPose();

         try {
            this.applyScale(g, x + width / 2.0F);
            this.drawSoundprint(g, x, y + 0.5F, width, x + width / 2.0F, now);
         } finally {
            g.pose().popPose();
         }
      }
   }

   private void applyScale(GuiGraphics g, float centerX) {
      float scale = this.effectiveScale;
      if (!(Math.abs(scale - 1.0F) < 0.01F)) {
         g.pose().translate(centerX, 0.0F, 0.0F);
         g.pose().scale(scale, scale, 1.0F);
         g.pose().translate(-centerX, 0.0F, 0.0F);
      }
   }

   private void drawSoundprint(GuiGraphics g, float x, float baselineY, float width, float centerX, long now) {
      float opacity = (float)((Double)SoundPrintConfig.OPACITY.get()).doubleValue();
      float alpha = opacity * this.entryProgress;
      if (!(alpha <= 0.01F)) {
         float entryOffsetY = (1.0F - this.entryProgress) * -3.0F;
         float baseline = baselineY + entryOffsetY;
         // The baseline breathes with the loudest live cluster and vanishes with
         // it - no static white line may remain once the sound is over.
         float maxEnergy = 0.0F;
         for (SoundPrintCluster cluster : this.clusters) {
            maxEnergy = Math.max(maxEnergy, cluster.energy());
         }

         if ((Boolean)SoundPrintConfig.BASELINE.get() && maxEnergy > 0.01F) {
            fillH(g, x + 2.0F, x + width - 2.0F, baseline, 1.0F, 15263976, alpha * 0.65F * maxEnergy);
         }

         int barCount = (Integer)SoundPrintConfig.BAR_COUNT.get();
         float barWidth = (float)((Integer)SoundPrintConfig.BAR_WIDTH.get()).intValue();
         float barGap = (float)((Integer)SoundPrintConfig.BAR_GAP.get()).intValue();
         float maxHeight = (float)((Integer)SoundPrintConfig.MAX_HEIGHT.get()).intValue();
         SoundPrintWidget.OscStyle osc = new SoundPrintWidget.OscStyle(
            (Boolean)SoundPrintConfig.OSCILLATE.get(),
            ((Double)SoundPrintConfig.OSC_SPEED.get()).floatValue(),
            (float)((Integer)SoundPrintConfig.OSC_AMP_MIN.get()).intValue(),
            (float)((Integer)SoundPrintConfig.OSC_AMP_MAX.get()).intValue(),
            ((Double)SoundPrintConfig.STACK_AMP_GAIN.get()).floatValue(),
            ((Double)SoundPrintConfig.STACK_ALPHA_GAIN.get()).floatValue(),
            (float)((Integer)SoundPrintConfig.RADIUS.get()).intValue(),
            ((Double)SoundPrintConfig.MIN_DECAY.get()).floatValue(),
            (Boolean)SoundPrintConfig.DISTANCE_DECAY.get(),
            now / 1000.0F
         );

         for (SoundPrintCluster cluster : this.clusters) {
            if (cluster.stagger()) {
               for (SoundPrintCluster.Member member : cluster.members()) {
                  this.drawCluster(
                     g,
                     width,
                     centerX,
                     member.bearing(),
                     member.energy(),
                     member.type(),
                     member.verticalOffset(),
                     member.distance(),
                     1,
                     alpha,
                     barCount,
                     barWidth,
                     barGap,
                     maxHeight,
                     baseline,
                     member.staggerOffset(),
                     0.82F,
                     osc
                  );
               }
            } else {
               this.drawCluster(
                  g,
                  width,
                  centerX,
                  cluster.bearing(),
                  cluster.energy(),
                  cluster.type(),
                  cluster.verticalOffset(),
                  cluster.nearestDistance(),
                  cluster.sourceCount(),
                  alpha,
                  barCount,
                  barWidth,
                  barGap,
                  maxHeight,
                  baseline,
                  0.0F,
                  1.0F,
                  osc
               );
            }
         }
      }
   }

   private void drawCluster(
      GuiGraphics g,
      float width,
      float centerX,
      float bearing,
      float energy,
      SoundPrintType type,
      float verticalOffset,
      float distance,
      int sourceCount,
      float alpha,
      int barCount,
      float barWidth,
      float barGap,
      float maxHeight,
      float baselineY,
      float staggerOffset,
      float sizeScale,
      SoundPrintWidget.OscStyle osc
   ) {
      float diff = CompassHeading.wrapDegrees((double)(bearing - this.frameHeading));
      if (!(Math.abs(diff) > this.edgeHalfWidth)) {
         float x = centerX + diff / this.halfRange * (width / 2.0F - 6.0F) + staggerOffset;
         float edgeFade = 1.0F
            - SoundPrintEnvelope.smoothstep(Mth.clamp((Math.abs(diff) - this.halfRange * 0.7F) / (this.edgeHalfWidth - this.halfRange * 0.7F), 0.0F, 1.0F));
         float clusterAlpha = alpha * edgeFade * (0.4F + 0.6F * energy);
         // Same-bearing stacking: each extra source makes the cluster more opaque.
         clusterAlpha = SoundPrintOscillator.stackedAlpha(clusterAlpha, sourceCount, osc.stackAlphaGain);

         if (!(clusterAlpha <= 0.015F)) {
            // v2.9.1: no static height floor - bar height follows the live
            // energy straight down to zero, so the print collapses entirely
            // instead of leaving a stub of white bars behind.
            float heightBase = maxHeight * type.heightBoost() * sizeScale * energy;
            float bw = barWidth + (type == SoundPrintType.GUNSHOT ? 1.0F : 0.0F);
            float gap = Math.max(0.0F, barGap - (type == SoundPrintType.GUNSHOT ? 1.0F : 0.0F));
            int rgb = resolveColor(type);
            float[] asym = SoundPrintEnvelope.asymmetryFactors(verticalOffset);
            float totalW = (float)barCount * (bw + gap) - gap;
            float left = x - totalW / 2.0F;
            float distFactor = SoundPrintEnvelope.distanceDecay(distance, osc.radius, osc.minDecay, osc.distanceDecay);
            float ampPx = osc.enabled
               ? SoundPrintOscillator.amplitude(energy, distFactor, sourceCount, osc.stackAmpGain, osc.ampMin, osc.ampMax)
               : 0.0F;
            float clusterPhase = SoundPrintOscillator.clusterPhase(bearing);

            for (int i = 0; i < barCount; i++) {
               float bell = SoundPrintEnvelope.bell(i, barCount);
               if (!(bell < 0.06F)) {
                  float pulse = SoundPrintOscillator.pulse(osc.timeSec, osc.speedHz, clusterPhase, i);
                  float barAlpha = clusterAlpha * (0.45F + 0.55F * bell);
                  float bx = left + (float)i * (bw + gap);
                  float oscUp = ampPx * bell * pulse;
                  float hUp = Math.max(0.0F, heightBase * bell * asym[0] + oscUp);
                  float hDown = Math.max(0.0F, heightBase * bell * asym[1] + oscUp);
                  if (hUp >= 1.0F) {
                     fillV(g, bx, bw, baselineY - hUp, hUp, rgb, barAlpha);
                  }

                  if (hDown >= 1.0F) {
                     fillV(g, bx, bw, baselineY + 1.5F, hDown, rgb, barAlpha);
                  }
               }
            }

            if ((Boolean)SoundPrintConfig.ARROWS.get()) {
               float strength = SoundPrintEnvelope.arrowStrength(verticalOffset) * energy;
               if (strength > 0.05F) {
                  float arrowAlpha = clusterAlpha * strength * 0.95F;
                  if (arrowAlpha > 0.02F) {
                     float reach = heightBase * 0.92F + 3.5F + ampPx * 0.6F;
                     float halfW = 2.2F + 0.8F * strength;
                     if (verticalOffset > 0.0F) {
                        drawVArrow(g, x, baselineY - reach - 2.0F, halfW, 3.6F, rgb, arrowAlpha, true);
                     } else {
                        drawVArrow(g, x, baselineY + reach + 3.5F, halfW, 3.6F, rgb, arrowAlpha, false);
                     }
                  }
               }
            }
         }
      }
   }

   private static int resolveColor(SoundPrintType type) {
      int override = type == SoundPrintType.GUNSHOT ? (Integer)SoundPrintConfig.COLOR_GUNSHOT.get() : (Integer)SoundPrintConfig.COLOR_FOOTSTEP.get();
      return override >= 0 ? override : type.defaultRgb();
   }

   private static int rgba(int rgb, float alpha) {
      return Math.round(Mth.clamp(alpha, 0.0F, 1.0F) * 255.0F) << 24 | rgb & 16777215;
   }

   private static void fillV(GuiGraphics g, float x, float w, float y, float h, int rgb, float alpha) {
      int c = rgba(rgb, alpha);
      g.fill(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), c);
      int halo = rgba(rgb, alpha * 0.25F);
      if (halo != 0 && alpha > 0.15F) {
         g.fill(Math.round(x), Math.round(y - 0.5F), Math.round(x + w), Math.round(y), halo);
         g.fill(Math.round(x), Math.round(y + h), Math.round(x + w), Math.round(y + h + 0.5F), halo);
      }
   }

   private static void fillH(GuiGraphics g, float x1, float x2, float y, float h, int rgb, float alpha) {
      int c = rgba(rgb, alpha);
      g.fill(Math.round(x1), Math.round(y), Math.round(x2), Math.round(y + h), c);
      if (alpha > 0.15F) {
         int halo = rgba(rgb, alpha * 0.22F);
         g.fill(Math.round(x1), Math.round(y - 0.5F), Math.round(x2), Math.round(y), halo);
         g.fill(Math.round(x1), Math.round(y + h), Math.round(x2), Math.round(y + h + 0.5F), halo);
      }
   }

   private static void drawVArrow(GuiGraphics g, float cx, float cy, float halfW, float h, int rgb, float alpha, boolean up) {
      int c = rgba(rgb, alpha);
      int rows = Math.max(3, Math.round(h));

      for (int i = 0; i < rows; i++) {
         float t = ((float)i + 0.5F) / (float)rows;
         float spread = up ? 1.0F - t : t;
         float armX = halfW * spread;
         float y = up ? cy - h + (float)i : cy - h + (float)i;
         int y1 = Math.round(y);
         int y2 = y1 + 1;
         g.fill(Math.round(cx - armX - 0.5F), y1, Math.round(cx - armX + 0.5F), y2, c);
         g.fill(Math.round(cx + armX - 0.5F), y1, Math.round(cx + armX + 0.5F), y2, c);
      }
   }

   private List<SoundPrintAggregator.Hit> previewHits(long now) {
      float h = this.previewHeadingTarget;
      // Preview energies breathe slowly so the settings preview demonstrates
      // the live-vibration look of the real HUD.
      float breath0 = 0.72F * (0.78F + 0.22F * (float)Math.sin((double)now / 650.0));
      float breath1 = 0.45F * (0.78F + 0.22F * (float)Math.sin((double)now / 650.0 + 2.1));
      float breath2 = 0.95F * (0.72F + 0.28F * (float)Math.sin((double)now / 430.0 + 0.9));
      return List.of(
         new SoundPrintAggregator.Hit(wrap360(h + 24.0F), breath0, SoundPrintType.FOOTSTEP, -0.55F, 6.0F),
         new SoundPrintAggregator.Hit(wrap360(h - 38.0F), breath1, SoundPrintType.FOOTSTEP, -0.2F, 17.0F),
         new SoundPrintAggregator.Hit(wrap360(h + 61.0F), breath2, SoundPrintType.GUNSHOT, 0.6F, 11.0F)
      );
   }

   private static final record OscStyle(
      boolean enabled,
      float speedHz,
      float ampMin,
      float ampMax,
      float stackAmpGain,
      float stackAlphaGain,
      float radius,
      float minDecay,
      boolean distanceDecay,
      float timeSec
   ) {
   }

   private static float wrap360(float v) {
      float r = v % 360.0F;
      return r < 0.0F ? r + 360.0F : r;
   }
}
