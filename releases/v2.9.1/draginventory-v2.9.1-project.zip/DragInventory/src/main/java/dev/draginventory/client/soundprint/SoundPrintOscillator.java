package dev.draginventory.client.soundprint;

/**
 * Pure-JVM vibration math for the soundprint bars.
 *
 * Amplitude model (v2.9.0):
 * - intensity = energy x distanceFactor x stackBoost, clamped to [0, 1]
 * - ampPx interpolates from min to max with that intensity
 * - each bar pulses around the cluster phase with a per-bar offset, so a
 *   cluster ripples instead of moving as a rigid block.
 */
public final class SoundPrintOscillator {
   /** Per-bar phase offset in radians: adjacent bars are visibly out of step. */
   static final float BAR_PHASE_STEP = 0.85F;
   /** Minimum share of the pulse wave (bars keep at least 35% of the amp when the sine is low). */
   static final float PULSE_FLOOR = 0.35F;

   private SoundPrintOscillator() {
   }

   /**
    * Vibration amplitude in pixels for one cluster.
    *
    * @param energy       cluster energy in [0, 1]
    * @param distFactor   distance factor in [0, 1] (1 = right next to the player)
    * @param sourceCount  number of sources merged into this cluster (>= 1)
    * @param stackAmpGain extra amplitude per additional co-located source (0 = off)
    * @param minPx        amplitude floor in pixels
    * @param maxPx        amplitude ceiling in pixels
    */
   public static float amplitude(float energy, float distFactor, int sourceCount, float stackAmpGain, float minPx, float maxPx) {
      float boost = 1.0F + Math.max(0, sourceCount - 1) * Math.max(0.0F, stackAmpGain);
      float intensity = SoundPrintEnvelope.clamp(energy * SoundPrintEnvelope.clamp(distFactor, 0.0F, 1.0F) * boost, 0.0F, 1.0F);
      float lo = Math.min(minPx, maxPx);
      float hi = Math.max(minPx, maxPx);
      return lo + (hi - lo) * intensity;
   }

   /**
    * Per-bar pulse multiplier for a moment in time.
    *
    * @param timeSec      wall-clock seconds
    * @param speedHz      oscillation speed in hertz
    * @param clusterPhase stable per-cluster phase offset (radians)
    * @param barIndex     index of the bar inside the cluster
    * @return multiplier in [2*floor-1, 1]; below zero makes a bar shrink
    *         under its base height, which reads as visible vibration
    */
   public static float pulse(float timeSec, float speedHz, float clusterPhase, int barIndex) {
      float phase = clusterPhase + (float)barIndex * BAR_PHASE_STEP;
      double t = (double)timeSec * (double)Math.max(0.0F, speedHz);
      double wave = Math.sin(2.0 * Math.PI * t + (double)phase);
      return (float)(PULSE_FLOOR + (1.0 - (double)PULSE_FLOOR) * wave);
   }

   /**
    * Stable per-cluster phase derived from the bearing so neighbouring
    * clusters do not oscillate in lockstep.
    */
   public static float clusterPhase(float bearingDeg) {
      return (float)Math.toRadians((double)bearingDeg) * 3.0F;
   }

   /**
    * Extra alpha for stacked co-located sources: more sources = more opaque.
    *
    * @param baseAlpha       base cluster alpha
    * @param sourceCount     sources merged into the cluster
    * @param stackAlphaGain  opacity gained per additional source (0..1)
    */
   public static float stackedAlpha(float baseAlpha, int sourceCount, float stackAlphaGain) {
      float extra = Math.max(0, sourceCount - 1) * Math.max(0.0F, stackAlphaGain);
      return SoundPrintEnvelope.clamp(baseAlpha + extra, 0.0F, 1.0F);
   }
}
