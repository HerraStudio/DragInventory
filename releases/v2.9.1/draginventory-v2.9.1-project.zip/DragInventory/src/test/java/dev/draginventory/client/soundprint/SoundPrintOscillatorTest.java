package dev.draginventory.client.soundprint;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class SoundPrintOscillatorTest {
   private static final float EPS = 1.0E-4F;

   @Test
   void amplitudeScalesWithEnergy() {
      float near = SoundPrintOscillator.amplitude(1.0F, 1.0F, 1, 0.0F, 1.0F, 9.0F);
      float weak = SoundPrintOscillator.amplitude(0.25F, 1.0F, 1, 0.0F, 1.0F, 9.0F);
      assertEquals(9.0F, near, EPS);
      assertEquals(1.0F + (9.0F - 1.0F) * 0.25F, weak, EPS);
   }

   @Test
   void amplitudeFallsWithDistance() {
      float closeBy = SoundPrintOscillator.amplitude(1.0F, 1.0F, 1, 0.0F, 1.0F, 9.0F);
      float farAway = SoundPrintOscillator.amplitude(1.0F, 0.3F, 1, 0.0F, 1.0F, 9.0F);
      assertTrue(closeBy > farAway);
      assertEquals(1.0F + (9.0F - 1.0F) * 0.3F, farAway, EPS);
   }

   @Test
   void stackedSourcesBoostAmplitude() {
      float single = SoundPrintOscillator.amplitude(0.4F, 1.0F, 1, 0.5F, 1.0F, 9.0F);
      float triple = SoundPrintOscillator.amplitude(0.4F, 1.0F, 3, 0.5F, 1.0F, 9.0F);
      // boost = 1 + 2*0.5 = 2 -> intensity = 0.8 (clamped below 1)
      assertEquals(1.0F + (9.0F - 1.0F) * 0.8F, triple, EPS);
      assertTrue(triple > single);
   }

   @Test
   void amplitudeClampsAtMax() {
      float boosted = SoundPrintOscillator.amplitude(0.5F, 1.0F, 10, 1.0F, 1.0F, 9.0F);
      assertEquals(9.0F, boosted, EPS);
   }

   @Test
   void amplitudeClampsAtMin() {
      float zeroEnergy = SoundPrintOscillator.amplitude(0.0F, 1.0F, 1, 0.0F, 1.5F, 9.0F);
      assertEquals(1.5F, zeroEnergy, EPS);
   }

   @Test
   void pulseStaysInWaveRange() {
      for (int i = 0; i < 20; i++) {
         for (long t = 0L; t < 2000L; t += 37L) {
            float p = SoundPrintOscillator.pulse(t / 1000.0F, 3.5F, 0.0F, i);
            assertTrue(p <= 1.0F + EPS, "pulse above 1: " + p);
            assertTrue(p >= 2.0F * SoundPrintOscillator.PULSE_FLOOR - 1.0F - EPS, "pulse below floor: " + p);
         }
      }
   }

   @Test
   void adjacentBarsDifferInPhase() {
      float t = 0.42F;
      float p0 = SoundPrintOscillator.pulse(t, 3.5F, 0.0F, 0);
      float p1 = SoundPrintOscillator.pulse(t, 3.5F, 0.0F, 1);
      assertTrue(Math.abs(p0 - p1) > 0.01F, "adjacent bars should be out of step");
   }

   @Test
   void pulsePeriodMatchesSpeed() {
      // at speed 2 Hz a full period is 0.5 s; same bar must repeat after one period
      float a = SoundPrintOscillator.pulse(0.10F, 2.0F, 0.0F, 3);
      float b = SoundPrintOscillator.pulse(0.60F, 2.0F, 0.0F, 3);
      assertEquals(a, b, 0.01F);
   }

   @Test
   void clusterPhaseVariesByBearing() {
      assertTrue(Math.abs(SoundPrintOscillator.clusterPhase(10.0F) - SoundPrintOscillator.clusterPhase(120.0F)) > 0.1F);
   }

   @Test
   void stackedAlphaGrowsButClamps() {
      float base = 0.5F;
      assertEquals(0.5F, SoundPrintOscillator.stackedAlpha(base, 1, 0.25F), EPS);
      assertEquals(0.75F, SoundPrintOscillator.stackedAlpha(base, 2, 0.25F), EPS);
      assertEquals(1.0F, SoundPrintOscillator.stackedAlpha(base, 8, 0.25F), EPS);
   }

   @Test
   void stackedAlphaIgnoresNegativeGain() {
      assertEquals(0.5F, SoundPrintOscillator.stackedAlpha(0.5F, 5, -1.0F), EPS);
   }
}
