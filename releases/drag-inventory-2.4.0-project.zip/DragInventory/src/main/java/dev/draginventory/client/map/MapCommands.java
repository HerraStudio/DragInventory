package dev.draginventory.client.map;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * 游戏内指令 /herramap（别名 /map，快捷 /m）：战术地图的全部可调项均可指令化。
 * <ul>
 *   <li>不带参数：打开地图设置界面（阶段5起与地图工具栏 settings 按钮同入口；
 *       /m 一个字母即可唤出，M 键仍直接开图）</li>
 *   <li>toggle / on / off：总开关（ENABLED 本期为预留配置项，不控制 M 键）</li>
 *   <li>gui：同不带参数，打开地图设置界面</li>
 *   <li>floor：无参显示当前楼层模式；floor auto 切回自动；
 *       floor &lt;y&gt; 手动指定楼层 Y（-2032~2031）；floor up / down 按层高跨度步进
 *       （写入 MANUAL_FLOOR_Y 并关闭自动楼层，已打开的地图实时跟随）</li>
 *   <li>span &lt;1..16&gt;：层高跨度（玩家 Y ± 该格数视为同一层）</li>
 *   <li>layer list：8 个语义图层开关汇总一条消息；layer &lt;id&gt; &lt;on|off&gt; 单独开关
 *       （id：walls / floor / water / stairs / doors / decor / upper / lower，未知 id 报错列合法值）</li>
 *   <li>opacity / contrast / brightness / saturation：战术滤镜四参数（0.3~1.0 / 0.5~2.0 / -0.5~0.5 / 0~2.0）</li>
 *   <li>grid &lt;on|off&gt;：网格线</li>
 *   <li>radius &lt;64..512&gt;：楼层扫描半径（格）</li>
 *   <li>zoom min &lt;0.2~1.0&gt; / zoom max &lt;2.0~16.0&gt; / zoom reset：缩放范围（reset 回默认 0.25 / 8.0）</li>
 *   <li>follow &lt;on|off&gt;：打开地图时居中玩家</li>
 *   <li>marker style &lt;tactical|minimal&gt;：标点风格（未知报错列合法值）；
 *       marker distance / marker countdown &lt;on|off&gt;：距离标注与倒计时</li>
 *   <li>reset：全部恢复默认；info：一条消息汇总当前配置</li>
 * </ul>
 * 数值参数由对应 ArgumentType 限定范围（越界在解析期即报错）；
 * 字符串参数 tab 补全合法值，非法值 sendFailure 并列出全部可选项。
 * 所有指令均为客户端指令（地图与配置均在客户端），无需权限。
 */
public final class MapCommands {

    /** 语言键前缀。 */
    private static final String K = "draginventory.map.cmd.";

    /** 手动楼层 Y 的合法范围，与 MapConfig.MANUAL_FLOOR_Y 一致（覆盖 1.21.1 全部合法 Y）。 */
    private static final int FLOOR_MIN = -2032;
    private static final int FLOOR_MAX = 2031;

    /** 标点风格合法值（与 MapConfig.MARKER_STYLE 约定一致）。 */
    private static final List<String> MARKER_STYLES = List.of("tactical", "minimal");

    /** 指令 id → 图层开关配置 + 本地化名称键。 */
    private record LayerDef(String id, ModConfigSpec.BooleanValue value, String nameKey) {}

    private static final List<LayerDef> LAYERS = List.of(
            new LayerDef("walls", MapConfig.SHOW_WALLS, "draginventory.map.layer_walls"),
            new LayerDef("floor", MapConfig.SHOW_FLOOR, "draginventory.map.layer_floor"),
            new LayerDef("water", MapConfig.SHOW_WATER, "draginventory.map.layer_water"),
            new LayerDef("stairs", MapConfig.SHOW_STAIRS, "draginventory.map.layer_stairs"),
            new LayerDef("doors", MapConfig.SHOW_DOORS, "draginventory.map.layer_doors"),
            new LayerDef("decor", MapConfig.SHOW_DECOR, "draginventory.map.layer_decor"),
            new LayerDef("upper", MapConfig.SHOW_UPPER, "draginventory.map.layer_upper"),
            new LayerDef("lower", MapConfig.SHOW_LOWER, "draginventory.map.layer_lower"));

    private static final String LAYER_IDS = LAYERS.stream().map(LayerDef::id).collect(Collectors.joining(", "));

    private MapCommands() {}

    /**
     * 由 {@code MapClientEvents} 在 RegisterClientCommandsEvent 时调用。
     * 三个根完全独立注册：/herramap、/map 为完整子树，/m 为快捷别名（只开图）。
     */
    public static List<LiteralArgumentBuilder<CommandSourceStack>> buildRoots() {
        List<LiteralArgumentBuilder<CommandSourceStack>> roots = new ArrayList<>(3);
        roots.add(build("herramap"));
        roots.add(build("map"));
        // 快捷别名：一个字母直接唤出战术地图（对齐 /com 的快捷定位）。
        roots.add(Commands.literal("m").executes(ctx -> {
            openMap(ctx, K + "opened");
            return 1;
        }));
        return roots;
    }

    private static LiteralArgumentBuilder<CommandSourceStack> build(String name) {
        return Commands.literal(name)
                .executes(ctx -> {
                    openMap(ctx, K + "opened");
                    return 1;
                })
                // ENABLED 本期为预留配置项（不控制 M 键），仅存储开关状态，反馈照常。
                .then(Commands.literal("toggle").executes(ctx -> {
                    boolean enabled = !MapConfig.ENABLED.get();
                    MapConfig.set(MapConfig.ENABLED, enabled);
                    feedback(ctx, enabled ? K + "enabled" : K + "disabled");
                    return 1;
                }))
                .then(Commands.literal("on").executes(ctx -> setEnabled(ctx, true)))
                .then(Commands.literal("off").executes(ctx -> setEnabled(ctx, false)))
                .then(Commands.literal("gui").executes(ctx -> {
                    openMap(ctx, K + "gui");
                    return 1;
                }))
                .then(buildFloor())
                .then(Commands.literal("span")
                        .then(Commands.argument("value", IntegerArgumentType.integer(1, 16))
                                .executes(ctx -> {
                                    int v = IntegerArgumentType.getInteger(ctx, "value");
                                    MapConfig.set(MapConfig.LAYER_SPAN, v);
                                    feedback(ctx, K + "span", Component.literal(String.valueOf(v)));
                                    return 1;
                                })))
                .then(Commands.literal("layer")
                        .then(Commands.literal("list").executes(ctx -> {
                            feedback(ctx, K + "layer_list", layerSummary());
                            return 1;
                        }))
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(
                                        LAYERS.stream().map(LayerDef::id), builder))
                                .then(Commands.literal("on").executes(ctx -> setLayer(ctx, true)))
                                .then(Commands.literal("off").executes(ctx -> setLayer(ctx, false)))))
                .then(Commands.literal("opacity")
                        .then(Commands.argument("value", DoubleArgumentType.doubleArg(0.3, 1.0))
                                .executes(ctx -> setDouble(ctx, MapConfig.OPACITY, K + "opacity"))))
                .then(Commands.literal("contrast")
                        .then(Commands.argument("value", DoubleArgumentType.doubleArg(0.5, 2.0))
                                .executes(ctx -> setDouble(ctx, MapConfig.CONTRAST, K + "contrast"))))
                .then(Commands.literal("brightness")
                        .then(Commands.argument("value", DoubleArgumentType.doubleArg(-0.5, 0.5))
                                .executes(ctx -> setDouble(ctx, MapConfig.BRIGHTNESS, K + "brightness"))))
                .then(Commands.literal("saturation")
                        .then(Commands.argument("value", DoubleArgumentType.doubleArg(0.0, 2.0))
                                .executes(ctx -> setDouble(ctx, MapConfig.SATURATION, K + "saturation"))))
                .then(Commands.literal("grid")
                        .then(Commands.literal("on").executes(ctx -> {
                            MapConfig.set(MapConfig.GRID, true);
                            feedback(ctx, K + "grid_on");
                            return 1;
                        }))
                        .then(Commands.literal("off").executes(ctx -> {
                            MapConfig.set(MapConfig.GRID, false);
                            feedback(ctx, K + "grid_off");
                            return 1;
                        })))
                .then(Commands.literal("radius")
                        .then(Commands.argument("blocks", IntegerArgumentType.integer(64, 512))
                                .executes(ctx -> {
                                    int v = IntegerArgumentType.getInteger(ctx, "blocks");
                                    MapConfig.set(MapConfig.SCAN_RADIUS, v);
                                    feedback(ctx, K + "radius", Component.literal(String.valueOf(v)));
                                    return 1;
                                })))
                .then(Commands.literal("zoom")
                        .then(Commands.literal("min")
                                .then(Commands.argument("value", DoubleArgumentType.doubleArg(0.2, 1.0))
                                        .executes(ctx -> setDouble(ctx, MapConfig.ZOOM_MIN, K + "zoom_min"))))
                        .then(Commands.literal("max")
                                .then(Commands.argument("value", DoubleArgumentType.doubleArg(2.0, 16.0))
                                        .executes(ctx -> setDouble(ctx, MapConfig.ZOOM_MAX, K + "zoom_max"))))
                        .then(Commands.literal("reset").executes(ctx -> {
                            // 两值回默认（0.25 / 8.0）：从配置默认值读取，不硬编码。
                            MapConfig.set(MapConfig.ZOOM_MIN, MapConfig.ZOOM_MIN.getDefault());
                            MapConfig.set(MapConfig.ZOOM_MAX, MapConfig.ZOOM_MAX.getDefault());
                            feedback(ctx, K + "zoom_reset",
                                    Component.literal(fmt(MapConfig.ZOOM_MIN.get())),
                                    Component.literal(fmt(MapConfig.ZOOM_MAX.get())));
                            return 1;
                        })))
                .then(Commands.literal("follow")
                        .then(Commands.literal("on").executes(ctx ->
                                setFlag(ctx, MapConfig.FOLLOW_PLAYER, K + "follow", true)))
                        .then(Commands.literal("off").executes(ctx ->
                                setFlag(ctx, MapConfig.FOLLOW_PLAYER, K + "follow", false))))
                .then(Commands.literal("marker")
                        .then(Commands.literal("style")
                                .then(Commands.argument("id", StringArgumentType.word())
                                        .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(
                                                MARKER_STYLES, builder))
                                        .executes(ctx -> {
                                            String id = StringArgumentType.getString(ctx, "id");
                                            if (!MARKER_STYLES.contains(id)) {
                                                // 未知风格直接报错并列出合法值，不静默回退。
                                                ctx.getSource().sendFailure(Component.translatable(K + "unknown_style",
                                                        Component.literal(id),
                                                        Component.literal(String.join(", ", MARKER_STYLES))));
                                                return 0;
                                            }
                                            MapConfig.set(MapConfig.MARKER_STYLE, id);
                                            feedback(ctx, K + "style", Component.literal(id));
                                            return 1;
                                        })))
                        .then(Commands.literal("distance")
                                .then(Commands.literal("on").executes(ctx ->
                                        setFlag(ctx, MapConfig.SHOW_DISTANCES, K + "distance", true)))
                                .then(Commands.literal("off").executes(ctx ->
                                        setFlag(ctx, MapConfig.SHOW_DISTANCES, K + "distance", false))))
                        .then(Commands.literal("countdown")
                                .then(Commands.literal("on").executes(ctx ->
                                        setFlag(ctx, MapConfig.SHOW_COUNTDOWN, K + "countdown", true)))
                                .then(Commands.literal("off").executes(ctx ->
                                        setFlag(ctx, MapConfig.SHOW_COUNTDOWN, K + "countdown", false)))))
                .then(Commands.literal("reset").executes(ctx -> {
                    MapConfig.resetToDefaults();
                    feedback(ctx, K + "reset");
                    return 1;
                }))
                .then(Commands.literal("info").executes(ctx -> {
                    boolean auto = MapConfig.AUTO_FLOOR.get();
                    // 自动楼层的实际楼面由地图会话动态解析，配置层不可知 → 显示 "-"。
                    Component floor = auto ? Component.literal("-")
                            : Component.literal("Y " + MapConfig.MANUAL_FLOOR_Y.get());
                    // 占位符与实参严格一一对应：本键 9 个 %s，下方恰好传 9 个参数（v1.5.4 教训）。
                    feedback(ctx, K + "info",
                            Component.translatable(auto
                                    ? "draginventory.map.floor_auto" : "draginventory.map.floor_manual"),
                            floor,
                            Component.literal(fmt(MapConfig.OPACITY.get())),
                            Component.literal(fmt(MapConfig.CONTRAST.get())),
                            Component.literal(fmt(MapConfig.BRIGHTNESS.get())),
                            Component.literal(fmt(MapConfig.SATURATION.get())),
                            layerSummary(),
                            Component.literal(fmt(MapConfig.ZOOM_MIN.get()) + " ~ " + fmt(MapConfig.ZOOM_MAX.get())),
                            Component.literal(String.valueOf(MapConfig.SCAN_RADIUS.get())));
                    return 1;
                }));
    }

    /** floor 子树：无参显示模式 / auto / &lt;y&gt; / up / down。 */
    private static LiteralArgumentBuilder<CommandSourceStack> buildFloor() {
        return Commands.literal("floor")
                // 无参：显示当前楼层模式（自动 或 手动 Y xx）。
                .executes(ctx -> {
                    reportFloorMode(ctx);
                    return 1;
                })
                .then(Commands.literal("auto").executes(ctx -> {
                    MapConfig.set(MapConfig.AUTO_FLOOR, true);
                    feedback(ctx, K + "floor_auto");
                    return 1;
                }))
                .then(Commands.argument("y", IntegerArgumentType.integer(FLOOR_MIN, FLOOR_MAX))
                        .executes(ctx -> {
                            int y = IntegerArgumentType.getInteger(ctx, "y");
                            MapConfig.set(MapConfig.AUTO_FLOOR, false);
                            MapConfig.set(MapConfig.MANUAL_FLOOR_Y, y);
                            feedback(ctx, K + "floor_manual", Component.literal(String.valueOf(y)));
                            return 1;
                        }))
                // up/down：拿不到已打开地图的会话引用（无静态入口），简化为手动楼层 ± 层高跨度。
                .then(Commands.literal("up").executes(ctx -> stepFloor(ctx, 1)))
                .then(Commands.literal("down").executes(ctx -> stepFloor(ctx, -1)));
    }

    private static void reportFloorMode(CommandContext<CommandSourceStack> ctx) {
        if (MapConfig.AUTO_FLOOR.get()) {
            feedback(ctx, K + "floor_auto");
        } else {
            feedback(ctx, K + "floor_manual", Component.literal(String.valueOf(MapConfig.MANUAL_FLOOR_Y.get())));
        }
    }

    /** 手动楼层按层高跨度步进（夹在合法 Y 范围内），并关闭自动楼层，反馈新值。 */
    private static int stepFloor(CommandContext<CommandSourceStack> ctx, int direction) {
        int next = Mth.clamp(MapConfig.MANUAL_FLOOR_Y.get() + direction * MapConfig.LAYER_SPAN.get(),
                FLOOR_MIN, FLOOR_MAX);
        MapConfig.set(MapConfig.AUTO_FLOOR, false);
        MapConfig.set(MapConfig.MANUAL_FLOOR_Y, next);
        feedback(ctx, K + "floor_step", Component.literal(String.valueOf(next)));
        return 1;
    }

    private static int setEnabled(CommandContext<CommandSourceStack> ctx, boolean value) {
        MapConfig.set(MapConfig.ENABLED, value);
        feedback(ctx, value ? K + "enabled" : K + "disabled");
        return 1;
    }

    private static int setLayer(CommandContext<CommandSourceStack> ctx, boolean on) {
        String id = StringArgumentType.getString(ctx, "id");
        LayerDef def = LAYERS.stream().filter(l -> l.id().equals(id)).findFirst().orElse(null);
        if (def == null) {
            // 未知图层直接报错并列出全部合法值，不静默忽略。
            ctx.getSource().sendFailure(Component.translatable(K + "unknown_layer",
                    Component.literal(id), Component.literal(LAYER_IDS)));
            return 0;
        }
        MapConfig.set(def.value(), on);
        feedback(ctx, K + "layer_set",
                Component.translatable(def.nameKey()), Component.literal(on ? "on" : "off"));
        return 1;
    }

    private static int setDouble(CommandContext<CommandSourceStack> ctx,
            ModConfigSpec.DoubleValue value, String key) {
        double v = DoubleArgumentType.getDouble(ctx, "value");
        MapConfig.set(value, v);
        feedback(ctx, key, Component.literal(fmt(v)));
        return 1;
    }

    private static int setFlag(CommandContext<CommandSourceStack> ctx,
            ModConfigSpec.BooleanValue value, String key, boolean on) {
        MapConfig.set(value, on);
        feedback(ctx, key, Component.literal(on ? "on" : "off"));
        return 1;
    }

    /** 8 个图层开关汇总为一个本地化组件：墙体✓ · 地面✓ · ……（复用图层名称键，✓/✗ 中立语言符号）。 */
    private static Component layerSummary() {
        MutableComponent summary = Component.empty();
        for (int i = 0; i < LAYERS.size(); i++) {
            LayerDef def = LAYERS.get(i);
            if (i > 0) {
                summary.append(" · ");
            }
            summary.append(Component.translatable(def.nameKey()))
                    .append(def.value().get() ? "\u2713" : "\u2717");
        }
        return summary;
    }

    /**
     * 打开地图设置界面并反馈（阶段5起：无参 / gui 子命令从直接开图改为唤出设置 GUI，
     * 与地图工具栏 settings 按钮同一入口；指令名与反馈键保持不变）。
     */
    private static void openMap(CommandContext<CommandSourceStack> ctx, String feedbackKey) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> mc.setScreen(MapSettingsScreen.create()));
        feedback(ctx, feedbackKey);
    }

    private static void feedback(CommandContext<CommandSourceStack> ctx, String key, Component... args) {
        ctx.getSource().sendSuccess(() -> Component.translatable(key, (Object[]) args), false);
    }

    private static String fmt(double v) {
        return String.format(Locale.ROOT, "%.2f", v);
    }
}
