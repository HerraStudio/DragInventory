package dev.draginventory.client.map;

import net.minecraft.util.Mth;

/**
 * 战术色板与滤镜管线："像素风底图套现代战术滤镜"。
 *
 * <p>底图结构保持方块像素（1 方块 = 1 纹素），色调对标《三角洲行动》地图工具参考图：
 * 深色去饱和地形、浅白建筑、深蓝黑水体。语义基础色在烘焙时经亮度 LUT（对比度/亮度）
 * 与饱和度混合得到最终颜色；参数变化只需重建 LUT，256 个瓦片全量重烤也不产生逐像素
 * 乘除的 GC 与 CPU 压力。</p>
 */
public final class FactoryMapPalette {
    private final int[] lut = new int[256];
    private double contrast = 1.25, brightness = -0.06, saturation = 0.80;
    private boolean dirty = true;

    /** 语义 → 基础色（未滤镜）。UI 图例、标点配色与烘焙共用一套源头。 */
    public int color(MapSemantics s) {
        return switch (s) {
            case VOID -> 0xFF0D141A;
            case WALL -> 0xFFD5DCE0;   // 浅白建筑——参考图中建筑以白色块呈现
            case FLOOR -> 0xFF39424A;
            case EDGE -> 0xFF7F939B;
            case STAIR -> 0xFFC9A45C;  // 暖金楼梯
            case DOOR -> 0xFF3FBF9A;   // 青绿主题色（与 HERRA HUD 统一）
            case WATER -> 0xFF17303F;  // 深蓝黑水体
            case BLOCKED -> 0xFF161F26;
            case DECOR -> 0xFF2A3A31;
        };
    }

    /** 语义 → 滤镜后烘焙色。LUT 缓存亮度变换，饱和度用灰度插值。 */
    public int bake(MapSemantics s) {
        int argb = color(s);
        if (dirty) rebuildLut();
        int r = lut[argb >>> 16 & 255], g = lut[argb >>> 8 & 255], b = lut[argb & 255];
        int gray = (int) (r * 0.299 + g * 0.587 + b * 0.114);
        r = Mth.clamp((int) (gray + (r - gray) * saturation), 0, 255);
        g = Mth.clamp((int) (gray + (g - gray) * saturation), 0, 255);
        b = Mth.clamp((int) (gray + (b - gray) * saturation), 0, 255);
        return 0xFF000000 | r << 16 | g << 8 | b;
    }

    /** 上下层叠加时的透明度（alpha 字节值）：上层墙体轮廓、下层地面淡显。 */
    public int overlayAlpha(MapSemantics s) {
        return switch (s) {
            case WALL -> 0x2E;
            case FLOOR, EDGE, DOOR, STAIR -> 0x18;
            default -> 0;
        };
    }

    /** 更新滤镜参数；任一变化即置脏，下次烘焙前重建 LUT。 */
    public void setFilter(double contrast, double brightness, double saturation) {
        double c = Mth.clamp(contrast, 0.5, 2.0);
        double b = Mth.clamp(brightness, -0.5, 0.5);
        double s = Mth.clamp(saturation, 0.0, 2.0);
        if (c != this.contrast || b != this.brightness || s != this.saturation) {
            this.contrast = c; this.brightness = b; this.saturation = s;
            dirty = true;
        }
    }

    /** 标记全部瓦片需重烤（滤镜或图层开关变化时由渲染器调用）。 */
    public void markDirty() { dirty = true; }

    private void rebuildLut() {
        for (int v = 0; v < 256; v++) {
            double d = (v / 255.0 - 0.5) * contrast + 0.5 + brightness;
            lut[v] = Mth.clamp((int) Math.round(d * 255.0), 0, 255);
        }
        dirty = false;
    }
}
