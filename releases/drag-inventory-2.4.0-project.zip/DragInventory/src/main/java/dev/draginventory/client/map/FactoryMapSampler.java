package dev.draginventory.client.map;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;

/**
 * 将不可变的工厂几何采样为战术俯视图的语义分类。
 *
 * <p>地图从预渲染固定范围改为动态瓦片绘制后，采样器不再直接产出颜色：
 * 每个格子被归为一种 {@link MapSemantics}，着色统一交给 {@link FactoryMapPalette}
 * （"像素风底图套战术滤镜"）。分类按固定优先级从高到低判定：
 * 未加载/越界 {@link MapSemantics#VOID} → 门 {@link MapSemantics#DOOR} →
 * 墙体 {@link MapSemantics#WALL} → 水体 {@link MapSemantics#WATER} →
 * 不可通行 {@link MapSemantics#BLOCKED} → 楼梯 {@link MapSemantics#STAIR} →
 * 地面装饰 {@link MapSemantics#DECOR} → 边缘 {@link MapSemantics#EDGE} →
 * 可通行地面 {@link MapSemantics#FLOOR}。</p>
 *
 * <p>分类结果以 {@link CellKey}(x, y, z) 为键做访问序 LRU 缓存（上限
 * {@code MAX_CACHED_CELLS} = 120,000 格）：本项目刻意不支持玩家建造/破坏，
 * 方块不会动态变化，因此同一格子跨瓦片、跨帧的重复采样均为 O(1) 查表。
 * 缓存仅在 {@link #prepare} 检测到 ClientLevel 实例变化（切换世界）时清空；
 * 未加载区块返回 VOID 且不写缓存，待区块加载后自然重新分类。</p>
 */
public final class FactoryMapSampler {
    /** 访问序 LRU 缓存的容量上限（格子数）。 */
    private static final int MAX_CACHED_CELLS = 120_000;

    private ClientLevel cachedLevel;
    private final Map<CellKey, MapSemantics> semantics = new LinkedHashMap<>(4096, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<CellKey, MapSemantics> eldest) {
            return size() > MAX_CACHED_CELLS;
        }
    };

    /** 切换世界（ClientLevel 实例变化）时清空语义缓存。 */
    public void prepare(ClientLevel level) {
        if (cachedLevel != level) {
            cachedLevel = level;
            semantics.clear();
        }
    }

    /**
     * 主分类入口：带 LRU 缓存的语义采样。
     * 区块未加载时直接返回 {@link MapSemantics#VOID}（不写缓存，避免加载后读到陈旧结果）。
     */
    public MapSemantics sample(ClientLevel level, int x, int z, int layerY) {
        prepare(level);
        if (!level.hasChunkAt(new BlockPos(x, layerY, z))) return MapSemantics.VOID;
        CellKey key = new CellKey(x, layerY, z);
        MapSemantics cached = semantics.get(key);
        if (cached != null) return cached;

        MapSemantics result = classify(level, x, z, layerY);
        semantics.put(key, result);
        return result;
    }

    /**
     * 私有静态分类逻辑（不缓存），按优先级从高到低判定：
     * VOID → DOOR → WALL → WATER → BLOCKED → STAIR → DECOR → EDGE → FLOOR。
     */
    private static MapSemantics classify(ClientLevel level, int x, int z, int layerY) {
        int y = Mth.clamp(layerY, level.getMinBuildHeight(), level.getMaxBuildHeight() - 1);
        BlockPos probe = new BlockPos(x, y, z);
        if (!level.hasChunkAt(probe)) return MapSemantics.VOID;

        // 门与活板门虽占据行走平面，但属于战术出入点：脚部/头部空间方块名含 "door" 即判为门，优先于墙体。
        if (doorAt(level, x, y + 1, z) || doorAt(level, x, y + 2, z)) return MapSemantics.DOOR;

        // 在选定的行走平面上，脚部/头部空间有碰撞体即为墙体。
        if (solidAt(level, x, y + 1, z) || solidAt(level, x, y + 2, z)) return MapSemantics.WALL;

        // 行走平面上下数格内存在流体则视为水体。
        for (int fy = Math.max(level.getMinBuildHeight(), y - 2);
             fy <= Math.min(level.getMaxBuildHeight() - 1, y + 3); fy++) {
            var state = level.getBlockState(new BlockPos(x, fy, z));
            if (!state.getFluidState().isEmpty()) return MapSemantics.WATER;
        }

        // 无有效地板（地板无碰撞或上方两格受阻）则为不可通行区域。
        BlockPos floor = new BlockPos(x, y, z);
        if (!FactoryMapLayerResolver.isWalkableFloor(level, floor)) return MapSemantics.BLOCKED;

        // 楼梯、梯子、脚手架：层间的垂直连接。
        var floorState = level.getBlockState(floor);
        String blockName = floorState.getBlock().builtInRegistryHolder().key().location().getPath();
        if (blockName.contains("stairs") || blockName.contains("ladder") || blockName.contains("scaffold")) return MapSemantics.STAIR;

        // 地板上方一格若是无碰撞的植物（花/草/蕨/树苗/蘑菇），仅作地面装饰，不影响通行判定。
        BlockPos above = floor.above();
        var aboveState = level.getBlockState(above);
        String aboveName = aboveState.getBlock().builtInRegistryHolder().key().location().getPath();
        boolean plant = aboveName.contains("flower") || aboveName.contains("grass") || aboveName.contains("fern")
                || aboveName.contains("sapling") || aboveName.contains("mushroom");
        if (plant && aboveState.getCollisionShape(level, above).isEmpty()) return MapSemantics.DECOR;

        // 任一水平邻格不可行走即为边缘（描边提升可读性），其余为普通可通行地面。
        boolean edge = !isWalkable(level, x + 1, y, z) || !isWalkable(level, x - 1, y, z)
                || !isWalkable(level, x, y, z + 1) || !isWalkable(level, x, y, z - 1);
        return edge ? MapSemantics.EDGE : MapSemantics.FLOOR;
    }

    private static boolean solidAt(ClientLevel level, int x, int y, int z) {
        if (y < level.getMinBuildHeight() || y >= level.getMaxBuildHeight()) return false;
        BlockPos pos = new BlockPos(x, y, z);
        return !level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
    }

    /** 方块注册路径名含 "door"（涵盖门与活板门），用于 DOOR 语义检测。 */
    private static boolean doorAt(ClientLevel level, int x, int y, int z) {
        if (y < level.getMinBuildHeight() || y >= level.getMaxBuildHeight()) return false;
        BlockPos pos = new BlockPos(x, y, z);
        return level.getBlockState(pos).getBlock().builtInRegistryHolder().key().location().getPath().contains("door");
    }

    private static boolean isWalkable(ClientLevel level, int x, int y, int z) {
        return level.hasChunkAt(new BlockPos(x, y, z))
                && FactoryMapLayerResolver.isWalkableFloor(level, new BlockPos(x, y, z));
    }

    private record CellKey(int x, int y, int z) {}
}
