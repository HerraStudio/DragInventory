package dev.draginventory.client.map;

import static dev.draginventory.client.map.FactoryMapUI.*;

import dev.draginventory.client.TacticalMarker;
import dev.draginventory.client.TacticalMarkerLogic;
import dev.draginventory.client.TacticalMarkerManager;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

/**
 * Full-screen operational map with genuine world data and local ping controls.
 *
 * <p>三角洲风格 HUD 布局（逻辑坐标 = canvas 空间，由 {@code uiScale} 统一缩放）：
 * <ul>
 *   <li>左侧全高战术面板：展开 {@link #panelW}（理想 {@link #PANEL_W}，小屏按画布宽
 *       22% 收窄）/ 折叠 {@link #PANEL_COLLAPSED_W}——标题栏、标点列表、类型筛选、
 *       POI 占位分区（对局系统未实装，空间不足自动隐藏）、
 *       图层开关（锚定面板底部）与清除按钮；</li>
 *   <li>顶部状态条（y 0..28）：当前楼层 Y + 楼层模式徽标 + 楼层标签组（最多 6 枚）
 *       + 北向指示 + 关闭按钮；</li>
 *   <li>右侧图标工具栏（{@link #toolbarX}，5 枚，26px 间距）与右下角缩放按钮、
 *       比例尺、坐标读数；</li>
 *   <li>底部提示条（y &gt; canvasH-34）：本地情报说明（左）与操作提示（右）。</li>
 * </ul>
 * 面板绘制拆分为 {@link #drawLeftPanel} / {@link #drawTopBar} / {@link #drawToolbar} /
 * {@link #drawBottomRight} / {@link #drawFooter}，由 {@link #drawChrome} 统一调度。</p>
 */
public final class FactoryMapScreen extends Screen {
    /** 左面板理想宽度（逻辑像素）；小屏时在 init 里按画布宽 22% 收窄为 {@link #panelW}。 */
    private static final int PANEL_W = 198;
    /** 左面板折叠态宽度：仅容纳一枚 24px 图标按钮 + 竖排楼层读数。 */
    private static final int PANEL_COLLAPSED_W = 26;
    private final FactoryMapSession session;
    private final FactoryMapTiles terrain = new FactoryMapTiles();
    private final EnumSet<TacticalMarker.Type> visible = EnumSet.allOf(TacticalMarker.Type.class);
    private boolean dragging;
    private boolean panelCollapsed;
    private float uiScale;
    private int canvasW, canvasH, panelW, toolbarX;
    private final long opened = Util.getMillis();

    private FactoryMapScreen(FactoryMapSession session) {
        super(Component.translatable("draginventory.map.title")); this.session = session;
    }
    public static FactoryMapScreen create() { return new FactoryMapScreen(new FactoryMapSession(Minecraft.getInstance())); }

    /** 只算布局，不挂任何 vanilla widget——按钮全部由 drawChrome 自绘。 */
    @Override protected void init() {
        uiScale = Math.min(1f, Math.min(width / 640f, height / 360f));
        canvasW = Math.round(width / uiScale); canvasH = Math.round(height / uiScale);
        panelW = Math.min(PANEL_W, canvasW * 22 / 100);
        toolbarX = canvasW - 32; // 24px 图标 + 8px 右边距
        dragging = false;
    }
    @Override public void tick() {
        if (minecraft.level == null || minecraft.player == null || !minecraft.player.isAlive()) { onClose(); return; }
        session.tick(minecraft);
    }
    private void center() { if (minecraft.player != null) session.centerOnPlayer(minecraft.player); }
    private MapCoordinateTransform transform() { return session.transform(0, 0, canvasW, canvasH); }
    /** 地图可视区左边界（逻辑像素）：面板折叠时只占 26px。 */
    private int mapLeft() { return panelCollapsed ? PANEL_COLLAPSED_W : panelW; }

    /** UI 遮挡判定：顶部状态条 / 底部提示条 / 左面板 / 右侧整条留白（工具栏 + 缩放 + 读数）。 */
    private boolean overPanel(double x, double y) {
        return y < 30 || y > canvasH - 34 || x < mapLeft() || x >= canvasW - 38 && y >= 36;
    }
    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        if (minecraft.level == null || minecraft.player == null) return;
        int mx = (int) (mouseX / uiScale), my = (int) (mouseY / uiScale);
        g.pose().pushPose(); g.pose().scale(uiScale, uiScale, 1);
        g.fill(0, 0, canvasW, canvasH, 0xFF09151B);
        var t = transform();
        g.enableScissor(0, 0, canvasW, canvasH);
        terrain.draw(g, minecraft, t, session);
        var active = session.activeLayer();
        if (active != null) drawConnectors(g, t, active.connectors());
        drawGrid(g, t);
        g.disableScissor();
        g.fillGradient(0, 0, canvasW, 70, 0xF209141A, 0x0009141A);
        g.fillGradient(0, canvasH - 75, canvasW, canvasH, 0x0009141A, 0xF209141A);
        for (int i = 0; i < 24; i++) {
            int alpha = (int) (130 * Math.pow(1 - i / 24.0, 2));
            g.fill(i * 4, 30, i * 4 + 4, canvasH - 34, alpha << 24 | 0x0A2029);
            g.fill(canvasW - i * 4 - 4, 30, canvasW - i * 4, canvasH - 34, alpha << 24 | 0x081319);
        }
        var markers = TacticalMarkerManager.snapshot(partial).stream()
                .filter(marker -> session.activeLayer() != null
                        && Math.abs(marker.position(partial).y - 1 - session.selectedFloorY()) <= 3)
                .toList();
        drawMarkers(g, t, markers, partial);
        int px = Mth.floor(t.worldToScreenX(minecraft.player.getX())), py = Mth.floor(t.worldToScreenY(minecraft.player.getZ()));
        if (px > mapLeft() && px < canvasW - 40 && py > 30 && py < canvasH - 36
                && session.activeLayer() != null && session.activeLayer().contains(Mth.floor(minecraft.player.getX()), Mth.floor(minecraft.player.getZ()))) {
            box(g, px - 10, py - 10, 21, 21, 0x6035D8A0); player(g, px, py, minecraft.player.getYRot());
        }
        if (!overPanel(mx, my)) {
            var world = t.screenToWorld(mx, my); session.setHover(world.x(), world.z());
            g.fill(mx - 7, my, mx - 2, my + 1, 0x8899B7B4); g.fill(mx + 3, my, mx + 8, my + 1, 0x8899B7B4);
            g.fill(mx, my - 7, mx + 1, my - 2, 0x8899B7B4); g.fill(mx, my + 3, mx + 1, my + 8, 0x8899B7B4);
        }
        drawChrome(g, markers, partial, mx, my);
        long layerFlash = Util.getMillis() - session.layerChangedAt();
        if (session.layerChangedAt() > 0 && layerFlash < 1600) {
            int alpha = (int) (220 * (1.0 - layerFlash / 1600.0));
            String notice = tr("layer_changed") + "  " + session.layerStatus();
            int nw = font.width(notice) + 24;
            int nx = (canvasW - nw) / 2;
            g.fill(nx, 48, nx + nw, 72, alpha << 24 | 0x102C32);
            box(g, nx, 48, nw, 24, alpha << 24 | GREEN);
            text(g, notice, nx + 12, 56, alpha << 24 | TEXT);
        }
        super.render(g, mx, my, partial);
        float fade = 1 - (float) Math.clamp((Util.getMillis() - opened) / 220.0, 0, 1);
        if (fade > 0) g.fill(0, 0, canvasW, canvasH, (int) (fade * fade * 210) << 24 | 0x081217);
        g.pose().popPose();
    }
    private void drawGrid(GuiGraphics g, MapCoordinateTransform t) {
        if (!MapConfig.GRID.get()) return;
        int spacing = 16; while (spacing * t.zoom() < 64) spacing *= 2;
        var min = t.screenToWorld(0, 0); var max = t.screenToWorld(canvasW, canvasH);
        for (int x = Math.floorDiv(Mth.floor(min.x()), spacing) * spacing; x < max.x(); x += spacing) {
            int sx = Mth.floor(t.worldToScreenX(x)); g.fill(sx, 30, sx + 1, canvasH - 34, 0x123F6B70);
            if (sx > mapLeft() && sx < canvasW - 60) text(g, Integer.toString(x), sx + 3, 32, 0xFF58716F);
        }
        for (int z = Math.floorDiv(Mth.floor(min.z()), spacing) * spacing; z < max.z(); z += spacing) {
            int sy = Mth.floor(t.worldToScreenY(z)); g.fill(mapLeft(), sy, canvasW - 38, sy + 1, 0x123F6B70);
        }
    }
    // Inter-floor connectors of the active layer: gold box = STAIR, cyan box = ELEVATOR
    // (dark backing ring + colored 7×7 frame + dark core, inlined from the retired FactoryMapTexture).
    private void drawConnectors(GuiGraphics g, MapCoordinateTransform t, List<FactoryMapLayerResolver.Connector> connectors) {
        for (var connector : connectors) {
            int x = Mth.floor(t.worldToScreenX(connector.x()));
            int y = Mth.floor(t.worldToScreenY(connector.z()));
            int color = connector.kind() == FactoryMapLayerResolver.Connector.Kind.STAIR ? 0xFFE9B75A : 0xFF62D8C6;
            g.fill(x - 3, y - 3, x + 4, y + 4, 0xAA0A1519);
            g.fill(x - 2, y - 2, x + 3, y + 3, color);
            g.fill(x - 1, y - 1, x + 2, y + 2, 0xFF0B171B);
        }
    }
    private void drawMarkers(GuiGraphics g, MapCoordinateTransform t, List<TacticalMarker> markers, float partial) {
        int index = 0;
        for (var marker : markers) {
            index++; if (!visible.contains(marker.type())) continue;
            Vec3 pos = marker.position(partial);
            if (session.activeLayer() == null || Math.abs(pos.y - 1 - session.selectedFloorY()) > 3) continue;
            int x = Mth.floor(t.worldToScreenX(pos.x)), y = Mth.floor(t.worldToScreenY(pos.z()));
            if (x < mapLeft() + 8 || x > canvasW - 46 || y < 54 || y > canvasH - 60) continue;
            int color = color(marker.type());
            var animation = TacticalMarkerLogic.appearance(Util.getMillis() - marker.createdAt());
            g.pose().pushPose(); g.pose().translate(x, y, 0); g.pose().scale(animation.scale(), animation.scale(), 1);
            glyph(g, 0, 0, marker.type(), color); g.pose().popPose();
            text(g, String.format(java.util.Locale.ROOT, "%02d", index), x + 9, y - 6, color);
            String d = meters(pos) + "m"; text(g, d, x - font.width(d) / 2, y + 12, TEXT);
        }
    }
    private int meters(Vec3 p) { return (int) Math.floor(p.distanceTo(minecraft.player.position())); }

    // ==================== HUD 面板群（三角洲风格） ====================

    private void drawChrome(GuiGraphics g, List<TacticalMarker> markers, float partial, int mx, int my) {
        drawLeftPanel(g, markers, partial, mx, my);
        drawTopBar(g, mx, my);
        drawToolbar(g, mx, my);
        drawBottomRight(g, mx, my);
        drawFooter(g);
    }

    /** 左侧全高面板：折叠态只留展开按钮 + 竖排楼层读数；展开态为标点列表 + 图层开关 + 清除。 */
    private void drawLeftPanel(GuiGraphics g, List<TacticalMarker> markers, float partial, int mx, int my) {
        if (panelCollapsed) {
            tacticalPanel(g, 0, 0, PANEL_COLLAPSED_W, canvasH, false);
            iconButton(g, 1, 1, 2, mx, my, "expand", false);
            // 楼层读数竖排：chip 无法旋转，逐字符下移画在面板中线上。
            String floor = "Y" + session.selectedFloorY();
            int y = canvasH / 2 - floor.length() * 5;
            for (int i = 0; i < floor.length(); i++) {
                String c = floor.substring(i, i + 1);
                text(g, c, (PANEL_COLLAPSED_W - font.width(c)) / 2, y, ACCENT);
                y += 10;
            }
            g.fill(PANEL_COLLAPSED_W / 2 - 2, canvasH - 16, PANEL_COLLAPSED_W / 2 + 2, canvasH - 12, ACCENT); // 底部提示点
            return;
        }
        tacticalPanel(g, 0, 0, panelW, canvasH, true);
        // 标题栏（y 0..26）：折叠按钮 + 任务标识。
        iconButton(g, 1, 4, 2, mx, my, "collapse", false);
        text(g, "HERRA / " + tr("title"), 32, 9, ACCENT);
        g.fill(8, 26, panelW - 8, 27, LINE);
        // 标点区块：分区头 + 类型筛选 + 标点行（y=48+i*20，最多 5 行）。
        sectionHeader(g, 12, 34, "operations", markers.size() + "/5");
        drawTypeFilter(g);
        if (markers.isEmpty()) {
            text(g, tr("empty"), 12, 54, TEXT);
            text(g, tr("empty_hint"), 12, 68, DIM);
        } else {
            for (int i = 0; i < Math.min(5, markers.size()); i++) {
                var marker = markers.get(i);
                int y = 48 + i * 20;
                if (rowHit(mx, my, 12, y, panelW - 24, 20)) g.fill(12, y, panelW - 12, y + 20, HOVER);
                glyph(g, 24, y + 10, marker.type(), color(marker.type()));
                text(g, String.format(java.util.Locale.ROOT, "%02d ", i + 1)
                        + tr(marker.type().name().toLowerCase(java.util.Locale.ROOT)), 36, y + 1, TEXT);
                String meta = "";
                if (MapConfig.SHOW_DISTANCES.get()) meta = meters(marker.position(partial)) + "m";
                if (MapConfig.SHOW_COUNTDOWN.get()) {
                    long seconds = Math.max(0, 60 - (Util.getMillis() - marker.createdAt()) / 1000);
                    meta = meta.isEmpty() ? seconds + "s" : meta + " / " + seconds + "s";
                }
                if (!meta.isEmpty()) text(g, meta, 36, y + 11, DIM);
            }
        }
        // POI 占位分区（对局系统未实装，见 MapPoiProvider）：分区头 + 空态文案。
        // 仅当标点区块（至 y=148）与图层区块（自 canvasH-206 起）之间留有 >30px 空隙时绘制；
        // 小画布（如最小 640×360 时 canvasH=360，canvasH-206-156=-2）放不下则整体跳过，避免与图层区块重叠。
        if (canvasH - 206 - 156 > 30) {
            sectionHeader(g, 12, 156, "poi_section", null);
            text(g, tr("poi_empty"), 12, 170, DIM);
        }
        // 图层区块（锚定面板底部）+ 清除按钮。
        sectionHeader(g, 12, canvasH - 206, "layers", null);
        drawLayerToggles(g, mx, my);
        strokeButton(g, 12, canvasH - 30, panelW - 24, 20, tr("clear_short"), mx, my);
    }

    /** 类型筛选小格（12×12、间隔 16，位于标点分区头同行右端）：off=DIM、on=类型色；命中切换见 {@link #clickChrome}。 */
    private void drawTypeFilter(GuiGraphics g) {
        TacticalMarker.Type[] types = TacticalMarker.Type.values();
        for (int i = 0; i < types.length && i < 3; i++) {
            TacticalMarker.Type type = types[i];
            int x = panelW - 58 + i * 16, y = 32;
            boolean on = visible.contains(type);
            box(g, x, y, 12, 12, on ? color(type) : STROKE_DIM);
            g.pose().pushPose();
            g.pose().translate(x + 6, y + 6, 0);
            g.pose().scale(.75f, .75f, 1);
            glyph(g, 0, 0, type, on ? color(type) : DIM);
            g.pose().popPose();
        }
    }

    /** 8 行图层开关（walls/floor/water/stairs/doors/decor/upper/lower），直读 MapConfig。 */
    private void drawLayerToggles(GuiGraphics g, int mx, int my) {
        int y = canvasH - 190, w = panelW - 24;
        toggleRow(g, 12, y, w, tr("layer_walls"), MapConfig.SHOW_WALLS.get(), mx, my, ACCENT);
        toggleRow(g, 12, y + 16, w, tr("layer_floor"), MapConfig.SHOW_FLOOR.get(), mx, my, ACCENT);
        toggleRow(g, 12, y + 32, w, tr("layer_water"), MapConfig.SHOW_WATER.get(), mx, my, ACCENT);
        toggleRow(g, 12, y + 48, w, tr("layer_stairs"), MapConfig.SHOW_STAIRS.get(), mx, my, ACCENT);
        toggleRow(g, 12, y + 64, w, tr("layer_doors"), MapConfig.SHOW_DOORS.get(), mx, my, ACCENT);
        toggleRow(g, 12, y + 80, w, tr("layer_decor"), MapConfig.SHOW_DECOR.get(), mx, my, ACCENT);
        toggleRow(g, 12, y + 96, w, tr("layer_upper"), MapConfig.SHOW_UPPER.get(), mx, my, ACCENT);
        toggleRow(g, 12, y + 112, w, tr("layer_lower"), MapConfig.SHOW_LOWER.get(), mx, my, ACCENT);
    }

    /** 顶部状态条（y 0..28）：楼层 Y + 模式徽标 + 楼层标签组（最多 6 枚）+ 北向指示 + 关闭按钮。 */
    private void drawTopBar(GuiGraphics g, int mx, int my) {
        int x = mapLeft() + 14;
        String floor = "Y " + session.selectedFloorY();
        text(g, floor, x, 10, ACCENT);
        x += font.width(floor) + 2;
        String mode = tr(session.isManualFloor() ? "floor_manual" : "floor_auto");
        chip(g, x, 8, mode, session.isManualFloor() ? ACCENT : DIM);
        x += font.width(mode) + 18;
        var catalog = session.catalog();
        if (catalog != null) {
            int activeFloorY = session.activeLayer() == null ? Integer.MIN_VALUE : session.activeLayer().floorY();
            int shown = 0;
            for (var layer : catalog.layers()) {
                if (shown++ == 6) break;
                String label = "Y" + layer.floorY();
                if (layer.floorY() == activeFloorY) chip(g, x, 8, label, ACCENT);
                else text(g, label, x + 4, 10, DIM);
                x += font.width(label) + 10; // chip 宽（文字+8）+ 间隔 2
            }
        }
        int cx = (mapLeft() + canvasW - 38) / 2;
        text(g, "N", cx - 2, 8, GREEN);
        g.fill(cx - 1, 17, cx, 23, GREEN);
        strokeButton(g, canvasW - 46, 4, 38, 20, tr("close"), mx, my);
    }

    /** 右侧图标工具栏：图层（折叠开关）/ 定位 / 上层 / 下层 / 设置。 */
    private void drawToolbar(GuiGraphics g, int mx, int my) {
        iconButton(g, 1, toolbarX, 40, mx, my, "layers", panelCollapsed);
        iconButton(g, 2, toolbarX, 66, mx, my, "center", false);
        iconButton(g, 3, toolbarX, 92, mx, my, "floor_up", false);
        iconButton(g, 4, toolbarX, 118, mx, my, "floor_down", false);
        iconButton(g, 5, toolbarX, 144, mx, my, "settings", false);
    }

    /** 右下角：缩放按钮对 + 比例尺（右对齐至 canvasW-44）+ 坐标读数。 */
    private void drawBottomRight(GuiGraphics g, int mx, int my) {
        iconButton(g, 6, toolbarX, canvasH - 118, mx, my, "zoom_in", false);
        iconButton(g, 7, toolbarX, canvasH - 92, mx, my, "zoom_out", false);
        int blocks = 16;
        while (blocks * session.zoom() < 36) blocks *= 2;
        while (blocks * session.zoom() > 95 && blocks > 1) blocks /= 2;
        int pixels = (int) (blocks * session.zoom()), right = canvasW - 44, by = canvasH - 58;
        g.fill(right - pixels, by, right, by + 1, DIM);
        g.fill(right - pixels, by - 3, right - pixels + 1, by + 2, DIM);
        g.fill(right - 1, by - 3, right, by + 2, DIM);
        text(g, blocks + "m", right - font.width(blocks + "m"), by - 12, TEXT);
        String coords = "X " + formatCoord(session.hoverBlockX()) + "  Z " + formatCoord(session.hoverBlockZ())
                + "  ·  " + Math.round(session.zoom() / 1.5 * 100) + "%";
        text(g, coords, canvasW - 44 - font.width(coords), canvasH - 44, DIM);
    }

    /** 底部提示条：左 = 本地情报说明；右 = 操作提示（右对齐至 canvasW-44）。 */
    private void drawFooter(GuiGraphics g) {
        text(g, tr("loaded_only"), mapLeft() + 14, canvasH - 16, DIM);
        String hints = tr("controls");
        text(g, hints, canvasW - 44 - font.width(hints), canvasH - 16, TEXT);
    }

    // ==================== 交互（HUD 控件命中 + 地图拖动/标点） ====================

    @Override public boolean mouseClicked(double x, double y, int button) {
        x /= uiScale; y /= uiScale;
        if (super.mouseClicked(x, y, button)) return true;
        if (button == 0 && clickChrome(x, y)) return true;
        // 标点行点击（y=48+i*20，i<5）：定位到该标点。
        if (button == 0 && !panelCollapsed && x >= 12 && x < panelW - 12 && y >= 48 && y < 148) {
            var markers = TacticalMarkerManager.snapshot(1); int i = (int) ((y - 48) / 20);
            if (i < 5 && i < markers.size()) { Vec3 p = markers.get(i).position(1); session.centerOn(p.x, p.z); } return true;
        }
        if (overPanel(x, y)) return false;
        if (button == 0) { dragging = true; return true; }
        if (button == 1 || button == 2) { placeMapPing(transform(), x, y); return true; }
        return false;
    }

    /**
     * HUD 自绘控件左键命中分发（canvas 逻辑坐标；矩形与 drawChrome 各组件逐一对齐）。
     * 优先级：关闭 → 面板折叠/展开 → 工具栏 5 键 → 缩放对 → 类型筛选 → 图层 8 行 → 清除。
     * 命中并处理返回 true，否则交还地图交互（拖动 / 右键标点）。
     */
    private boolean clickChrome(double x, double y) {
        int mx = (int) x, my = (int) y;
        if (rowHit(mx, my, canvasW - 46, 4, 38, 20)) { onClose(); return true; } // a) 顶栏关闭
        if (!panelCollapsed) { // b) 展开态标题栏折叠按钮
            if (rowHit(mx, my, 4, 2, 24, 24)) { panelCollapsed = true; return true; }
        } else if (rowHit(mx, my, 0, 0, PANEL_COLLAPSED_W, canvasH)) { // c) 折叠态整条窄条（含顶部 expand 键）展开
            panelCollapsed = false; return true;
        }
        if (rowHit(mx, my, toolbarX, 40, 24, 24)) { panelCollapsed = !panelCollapsed; return true; } // d) layers
        if (rowHit(mx, my, toolbarX, 66, 24, 24)) { center(); return true; } // d) center
        if (rowHit(mx, my, toolbarX, 92, 24, 24)) { session.cycleFloorUp(); return true; } // d) floor_up
        if (rowHit(mx, my, toolbarX, 118, 24, 24)) { session.cycleFloorDown(); return true; } // d) floor_down
        if (rowHit(mx, my, toolbarX, 144, 24, 24)) { // d) settings：打开地图设置 GUI（与 /map /m 无参同入口）
            minecraft.setScreen(MapSettingsScreen.create()); return true;
        }
        if (rowHit(mx, my, toolbarX, canvasH - 118, 24, 24)) { // e) zoom_in：以画布中心为锚
            session.zoomAt(canvasW / 2.0, canvasH / 2.0, 1.5, 0, 0, canvasW, canvasH); return true;
        }
        if (rowHit(mx, my, toolbarX, canvasH - 92, 24, 24)) { // e) zoom_out
            session.zoomAt(canvasW / 2.0, canvasH / 2.0, 1 / 1.5, 0, 0, canvasW, canvasH); return true;
        }
        if (panelCollapsed) return false;
        TacticalMarker.Type[] types = TacticalMarker.Type.values(); // f) 类型筛选小格（12×12、间隔 16）
        for (int i = 0; i < types.length && i < 3; i++) {
            if (rowHit(mx, my, panelW - 58 + i * 16, 32, 12, 12)) {
                if (visible.contains(types[i])) visible.remove(types[i]); else visible.add(types[i]);
                return true;
            }
        }
        if (rowHit(mx, my, 12, canvasH - 190, panelW - 24, 128)) { // g) 图层 8 行（16×8）
            toggleLayer((int) ((my - (canvasH - 190)) / 16)); return true;
        }
        if (rowHit(mx, my, 12, canvasH - 30, panelW - 24, 20)) { // h) 底部清除
            TacticalMarkerManager.clearLocationMarkers(); return true;
        }
        return false;
    }

    /** 图层开关反写配置（行序 walls/floor/water/stairs/doors/decor/upper/lower）。 */
    private static void toggleLayer(int row) {
        switch (row) {
            case 0 -> MapConfig.set(MapConfig.SHOW_WALLS, !MapConfig.SHOW_WALLS.get());
            case 1 -> MapConfig.set(MapConfig.SHOW_FLOOR, !MapConfig.SHOW_FLOOR.get());
            case 2 -> MapConfig.set(MapConfig.SHOW_WATER, !MapConfig.SHOW_WATER.get());
            case 3 -> MapConfig.set(MapConfig.SHOW_STAIRS, !MapConfig.SHOW_STAIRS.get());
            case 4 -> MapConfig.set(MapConfig.SHOW_DOORS, !MapConfig.SHOW_DOORS.get());
            case 5 -> MapConfig.set(MapConfig.SHOW_DECOR, !MapConfig.SHOW_DECOR.get());
            case 6 -> MapConfig.set(MapConfig.SHOW_UPPER, !MapConfig.SHOW_UPPER.get());
            case 7 -> MapConfig.set(MapConfig.SHOW_LOWER, !MapConfig.SHOW_LOWER.get());
            default -> { }
        }
    }
    @Override public boolean mouseReleased(double x, double y, int button) {
        if (button == 0 && dragging) { dragging = false; return true; }
        return super.mouseReleased(x / uiScale, y / uiScale, button);
    }
    @Override public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
        if (button == 0 && dragging) { session.panPixels(dx / uiScale, dy / uiScale); return true; }
        return super.mouseDragged(x / uiScale, y / uiScale, button, dx / uiScale, dy / uiScale);
    }
    @Override public boolean mouseScrolled(double x, double y, double sx, double sy) {
        x /= uiScale; y /= uiScale;
        if (!overPanel(x, y) && sy != 0) { session.zoomAt(x, y, Math.pow(1.18, sy), 0, 0, canvasW, canvasH); return true; }
        return super.mouseScrolled(x, y, sx, sy);
    }
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (FactoryMapKeyBindings.OPEN_MAP.matches(key, scan)) { onClose(); return true; }
        if (key == GLFW.GLFW_KEY_SPACE) { center(); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_UP) { session.cycleFloorUp(); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_DOWN) { session.cycleFloorDown(); return true; }
        if (key == GLFW.GLFW_KEY_HOME) { session.setAutoFloor(true); return true; }
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT) { panelCollapsed = !panelCollapsed; return true; }
        return super.keyPressed(key, scan, modifiers);
    }
    private void placeMapPing(MapCoordinateTransform t, double x, double y) {
        var world = t.screenToWorld(x, y); int wx = Mth.floor(world.x()), wz = Mth.floor(world.z());
        if (!minecraft.level.hasChunkAt(new BlockPos(wx, 0, wz))) return;
        int floor = session.selectedFloorY();
        if (floor == FactoryMapLayerResolver.NO_FLOOR || floor < minecraft.level.getMinBuildHeight()) return;
        TacticalMarkerManager.placeMapLocation(new Vec3(world.x(), floor + 1.05, world.z()));
    }
    @Override public boolean isPauseScreen() { return false; }
    // The map owns its backdrop; vanilla's menu blur would blur the map and labels just drawn.
    @Override public void renderBackground(GuiGraphics g, int x, int y, float delta) {}
    @Override public void removed() { terrain.close(); super.removed(); }
}
