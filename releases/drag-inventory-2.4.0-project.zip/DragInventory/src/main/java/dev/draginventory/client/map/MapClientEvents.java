package dev.draginventory.client.map;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;

/**
 * 战术地图客户端事件（Forge 总线）：
 * <ul>
 *   <li>注册游戏内指令（/herramap /map /m 三根，见 {@link MapCommands}）</li>
 *   <li>client tick 驱动配置防抖落盘（指令/界面连续修改静默 500ms 后统一写盘）</li>
 *   <li>退出世界时立即落盘兜底，避免 500ms 静默窗口内的调整丢失</li>
 * </ul>
 * 与 M 键轮询（{@link FactoryMapClientEvents}）、配置对账
 * （{@link MapConfigEvents}，MOD 总线）分属不同事件通道，各管各的。
 */
@EventBusSubscriber(modid = "draginventory", value = Dist.CLIENT)
public final class MapClientEvents {

    private MapClientEvents() {}

    @SubscribeEvent
    public static void onRegisterClientCommands(RegisterClientCommandsEvent event) {
        for (var root : MapCommands.buildRoots()) {
            event.getDispatcher().register(root);
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        MapConfig.tickSave();
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        MapConfig.flush();
    }
}
