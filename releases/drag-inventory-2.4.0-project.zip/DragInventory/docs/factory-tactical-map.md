# 战术地图

全屏动态战术地图，视觉参考三角洲行动的深色俯视 HUD：实时瓦片底图、左侧全高战术面板、顶部楼层状态条、右侧图标工具栏。底图不再预渲染、不再绑定固定工厂范围——任意已加载地形都能即时成图。

## 动态绘制架构

- **瓦片化**：世界按 64×64 格切成瓦片（4×4 区块），每张瓦片一张 64×64 纹理（1 方块 = 1 纹素，保留像素结构）。只烘焙覆盖视口的瓦片（外扩一圈），视野拉多远都不受固定范围限制。
- **分帧渐进烘焙**：每瓦片每帧推进 16 行（4 帧烤完一张）；活动层每帧最多烘焙 3 张、上下叠加层各 1 张，每帧采样上限约 4k 格（旧全图方案为 65536 格/帧），未烤区域先显示深色底，画面随烘焙渐进清晰。
- **LRU 瓦片池**：各楼层共用 256 张容量（约 4MB 显存）的访问序缓存，超限淘汰并释放纹理。瓦片键含楼层 Y，切层不主动失效——切回旧层立即命中。
- **语义 9 类**：每格分类为 未知/墙体/地面/边界/楼梯/房门/水体/阻挡/装饰，按固定优先级判定；图层开关直接决定哪些语义参与烘焙。颜色统一由色板 LUT 烘焙，滤镜（对比度/亮度/饱和度）改的是 LUT 而非逐像素计算。
- **动态楼层扫描**：每 40 tick、或玩家水平移动超过 32 格时重建楼层目录（半径 `behavior.scan_radius`，默认 256 格）；相近楼面按 |ΔY| ≤ 3 合并，最多 16 层。
- **楼层模式**：默认自动跟随玩家所在楼面；手动模式（PgUp/PgDn、设置 GUI、`/map floor`）在目录层间循环或锁定指定 Y，Home 回自动。视野中心被钳制在目录范围 ±96 格内，允许略微出界平移。

## 布局说明

- **左侧全高战术面板**：展开约 198px（小屏按画布宽 22% 收窄），折叠仅 26px。展开态含标题栏、标点列表（最多 5 行，点击定位）、类型筛选小格、POI 预设点位占位分区（对局系统未实装，画布空间不足时自动隐藏）、8 个图层开关与清除按钮；折叠态保留展开按钮与竖排楼层读数。
- **顶部状态条**：当前楼层 Y + 自动/手动徽标 + 楼层标签组（最多 6 枚，活动层高亮）+ 北向指示 + 关闭按钮。
- **右侧图标工具栏**（5 枚）：面板折叠开关、定位（回玩家）、上层、下层、设置（打开地图设置 GUI）。
- **右下角**：缩放按钮对、按当前缩放自适应的比例尺、悬停坐标与缩放百分比读数。
- **地图设置 GUI**：五页签（楼层/图层/视觉/行为/标点）单屏收纳全部选项，顶部为实时预览——左侧迷你地图（独立坐标变换，不污染地图会话）+ 右侧九语义色样例（对应图层关闭的语义画未知色并加红色小斜杠）+ 底部滤镜读数。改动经防抖落盘，关屏兜底立即写盘。
- 窗口变小或 GUI 比例提高时，整套界面按画布等比缩小，命中区域与显示像素一一对应（小于 640×360 时整体缩小）。

## 操作

- `M` 打开或关闭，`Esc` 关闭；不暂停游戏。
- 左键拖动平移；滚轮以鼠标位置为锚缩放；空格或「定位」回到玩家。
- 右键或中键在已加载地形上添加地点标记，与世界 HUD 共用 5 个名额、60 秒生命周期；点击面板标点行将地图移到该标点；「清除」只清除地点标记。
- `PgUp` / `PgDn` 手动切换楼层，`Home` 回到自动楼层；切换有顶部闪烁提示。
- `Shift` 折叠/展开左面板（折叠后地图可视区更宽）。
- 地形外观由当前世界决定；未加载区域保持深色且不能添加标记。截图里的工厂是隔离测试场景，未随模组添加到玩家世界。

## 指令参考

`/herramap` 与 `/map` 为等价完整子树，`/m` 为快捷别名（一个字母直接唤出设置界面）。全部为客户端指令，无需权限；非法参数直接报错并列出合法值。

| 指令 | 说明 |
| --- | --- |
| `/m`、`/map`、`/herramap`（无参） | 打开地图设置界面（与地图工具栏设置按钮同入口） |
| `/map gui` | 同无参，打开地图设置界面 |
| `/map toggle` / `on` / `off` | 总开关（预留配置项，不控制 M 键） |
| `/map floor` | 显示当前楼层模式（自动 / 手动 Y xx） |
| `/map floor auto` | 切回自动楼层 |
| `/map floor <y>` | 手动锁定楼层 Y（-2032 ~ 2031） |
| `/map floor up` / `down` | 手动楼层按层高跨度步进 |
| `/map span <1..16>` | 层高跨度（玩家 Y ± 该格数视为同一层） |
| `/map layer list` | 汇总显示 8 个图层开关状态 |
| `/map layer <id> <on\|off>` | 单独开关图层（id：walls / floor / water / stairs / doors / decor / upper / lower） |
| `/map opacity <0.3..1.0>` | 地图整体不透明度 |
| `/map contrast <0.5..2.0>` | 滤镜对比度 |
| `/map brightness <-0.5..0.5>` | 滤镜亮度 |
| `/map saturation <0..2.0>` | 滤镜饱和度 |
| `/map grid <on\|off>` | 网格线 |
| `/map radius <64..512>` | 楼层扫描半径（格） |
| `/map zoom min <0.2..1.0>` | 最小缩放 |
| `/map zoom max <2.0..16.0>` | 最大缩放 |
| `/map zoom reset` | 缩放范围回默认（0.25 / 8.0） |
| `/map follow <on\|off>` | 打开地图时居中玩家 |
| `/map marker style <tactical\|minimal>` | 标点风格 |
| `/map marker distance <on\|off>` | 标点距离标注 |
| `/map marker countdown <on\|off>` | 标点倒计时 |
| `/map reset` | 全部恢复默认 |
| `/map info` | 一条消息汇总当前配置 |

## 配置文件

客户端配置 `config/draginventory-map-client.toml`，修改后立即生效，外部编辑由 NeoForge 自动热重载；指令与设置 GUI 的改动经 500ms 防抖落盘（写前日志对抗保存竞态，退出世界时兜底写盘）。

| 组 | 键 | 默认 | 说明 |
| --- | --- | --- | --- |
| general | `enabled` | true | 总开关（预留项，不控制 M 键） |
| general | `auto_floor` | true | 自动楼层（跟随玩家） |
| general | `manual_floor_y` | 0 | 手动楼层 Y（-2032~2031，仅 auto_floor=false 生效） |
| general | `layer_span` | 4 | 层高跨度（1~16） |
| layers | `show_walls` / `show_floor` / `show_water` / `show_stairs` / `show_doors` | true | 墙体/地面/水体/楼梯/房门图层 |
| layers | `show_decor` | false | 地面装饰（信息量低，默认关） |
| layers | `show_upper` / `show_lower` | true | 上层墙体轮廓叠加 / 下层地面淡显 |
| vision | `opacity` | 0.95 | 整体不透明度（0.3~1.0） |
| vision | `contrast` / `brightness` / `saturation` | 1.25 / -0.06 / 0.80 | 战术滤镜三参数（驱动色板烘焙） |
| vision | `grid` | true | 网格线 |
| behavior | `scan_radius` | 256 | 楼层扫描半径（64~512 格） |
| behavior | `zoom_min` / `zoom_max` | 0.25 / 8.0 | 缩放范围 |
| behavior | `follow_player` | true | 打开时居中玩家 |
| markers | `marker_style` | tactical | 标点风格（tactical / minimal） |
| markers | `show_distances` / `show_countdown` | true | 距离标注 / 倒计时 |

## 开发验证

```powershell
.\gradlew.bat test build
.\gradlew.bat runClient -PmapSmoke -PweaponGameDir=run-map-redesign
.\gradlew.bat clean test build
```

`mapSmoke` 仅用于隔离验证，自动创建测试世界并生成工厂建筑，检查自动楼层发现、动态瓦片渲染、拖动与缩放锚点、面板输入隔离、地图标点、手动楼层循环、Shift 面板折叠、GUI 缩放命中与关闭重开。正式构建不要传入此参数。

源码：`src/main/java/dev/draginventory/client/map/`。中文与英文文字位于各语言 JSON；绘制词汇集中在 `FactoryMapUI`，采样、瓦片与色板分别在 `FactoryMapSampler`、`FactoryMapTiles`、`FactoryMapPalette`，坐标变换在 `MapCoordinateTransform`，配置在 `MapConfig`。
