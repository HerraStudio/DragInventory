package dev.draginventory.client.map;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import java.io.IOException;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.MipmapGenerator;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;

/**
 * 玩家导航箭头纹理（v2.5.8）：用户提供的 玩家位置图标.svg 原图——纯 #32CD32 平面导航
 * 箭头（单色填充 + 同色描边，无任何明暗层次）——离线栅格化为 256×256 抗锯齿 PNG（
 * {@code src/main/resources/assets/draginventory/textures/gui/player_marker.png}），
 * 运行时上传 GPU 并生成 alpha 感知的 mipmap 链（{@link MipmapGenerator} 盒滤波，
 * 透明边缘不发黑），统一以 LINEAR + LINEAR_MIPMAP_LINEAR 过滤——任意 GUI 缩放、
 * 呼吸、拉伸下边缘平滑如矢量（SVG 本来的观感），取代 v2.5.6/v2.5.7 的几何三角
 * 绘制（无抗锯齿管线的硬边锯齿、左半压暗立体感、中脊白缝）。
 *
 * <p>实现要点：{@code NativeImage.upload} 每次调用会把纹理过滤重置为 NEAREST，
 * 因此必须先上传全部 mip 层、最后统一 {@link #setFilter}。加载失败由
 * {@code TextureManager} 回退缺失纹理（紫黑棋盘），游戏内一眼可定位。
 */
final class PlayerMarkerTexture extends AbstractTexture {
    /** 纹理资源路径（jar 内 assets/draginventory/textures/gui/player_marker.png）。 */
    static final ResourceLocation ID =
            ResourceLocation.fromNamespaceAndPath("draginventory", "textures/gui/player_marker.png");

    /**
     * 纹理画布边长（GUI px）：SVG 画布 200×200 等比映射；形状（含同色描边 miter，
     * 高约 161/200 画布）最终显示 ≈12.5px——与 v2.5.7 视觉尺寸一致，不再变大。
     */
    static final float CANVAS = 15.5f;

    /** mipmap 最大层数（256→8px；覆盖 GUI scale 1 时呼吸缩小的采样需求）。 */
    private static final int MAX_MIP = 5;

    @Override
    public void load(ResourceManager manager) throws IOException {
        NativeImage image;
        var resource = manager.getResourceOrThrow(ID);
        try (var in = resource.open()) {
            image = NativeImage.read(in);
        }
        NativeImage[] levels = MipmapGenerator.generateMipLevels(new NativeImage[]{image}, MAX_MIP);
        try {
            TextureUtil.prepareImage(this.getId(), MAX_MIP, image.getWidth(), image.getHeight());
            RenderSystem.bindTexture(this.getId());
            for (int i = 0; i < levels.length; i++) {
                levels[i].upload(i, 0, 0, false);
            }
            // upload 会把过滤重置为 NEAREST——全部层上传完毕后统一启用线性 + mipmap。
            this.setFilter(true, true);
        } finally {
            for (NativeImage level : levels) {
                if (level != null) level.close();
            }
        }
    }
}
